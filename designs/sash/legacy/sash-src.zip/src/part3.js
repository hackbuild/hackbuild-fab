/* part3.js: exports, viewer, UI, boot. Depends on Orca3MF, RasterMesh, THREE, JSZip and part2.js. */
'use strict';

// ------------------------------------------------------------ part list and plate layout
function partKeys() { return MODEL.parts ? Object.keys(MODEL.parts) : []; }
function partBox(key) { const g = MODEL.parts[key].grid; return { w: g.W * g.px, h: g.H * g.px }; }
function plateLayout() {
  if (!MODEL.parts) return { positions: {}, fits: true, group: { w: 0, h: 0 } };
  const gap = 5, keys = partKeys();
  const boxes = {}; for (const k of keys) boxes[k] = partBox(k);
  // one copy: shell and cover side by side on top, slides in a row below
  const local = {};
  const topW = boxes.shell.w + gap + boxes.cover.w, topH = Math.max(boxes.shell.h, boxes.cover.h);
  local.shell = [boxes.shell.w / 2, topH / 2];
  local.cover = [boxes.shell.w + gap + boxes.cover.w / 2, topH / 2];
  let x = 0, rowH = 0;
  for (const k of keys) if (k.startsWith('slide')) { local[k] = [x + boxes[k].w / 2, topH + gap + boxes[k].h / 2]; x += boxes[k].w + gap; rowH = Math.max(rowH, boxes[k].h); }
  const gw = Math.max(topW, x - gap), gh = topH + (rowH ? gap + rowH : 0);
  const n = ST.plate.count, cols = Math.max(1, Math.floor((ST.plate.bedW + gap) / (gw + gap))), rows = Math.ceil(n / cols);
  const positions = {}; for (const k of keys) positions[k] = [];
  const totW = Math.min(n, cols) * (gw + gap) - gap, totH = rows * (gh + gap) - gap;
  for (let i = 0; i < n; i++) {
    const c = i % cols, r = Math.floor(i / cols);
    const ox = ST.plate.bedW / 2 - totW / 2 + c * (gw + gap), oy = ST.plate.bedD / 2 + totH / 2 - r * (gh + gap) - gh;
    for (const k of keys) positions[k].push([ox + local[k][0], oy + gh - local[k][1], 0]);
  }
  return { positions, fits: totW <= ST.plate.bedW && totH <= ST.plate.bedD, group: { w: gw, h: gh }, local, boxes };
}

// ------------------------------------------------------------ exports
function partName(key) { return key === 'shell' ? 'shell' : key === 'cover' ? 'cover' : 'slide-' + (+key.slice(5) + 1) + '-' + (ST.lanes[+key.slice(5)].name || '').replace(/[^a-z0-9]+/gi, '-'); }
function pkgConfig() {
  ensureMesh();
  const lay = plateLayout();
  const objects = [];
  for (const key of partKeys()) {
    const meshes = MODEL.parts[key].meshes, parts = [];
    for (const s of Object.keys(meshes).map(Number).sort((a, b) => a - b)) {
      const sl = ST.colour.slots[s - 1];
      parts.push({ name: (sl.name || ('slot' + s)) + '-' + s, slot: s, positions: meshes[s].positions, indices: meshes[s].indices });
    }
    objects.push({ name: partName(key), positions: lay.positions[key], parts });
  }
  return {
    filaments: ST.colour.slots.slice(0, ST.colour.n),
    printer: { printer_settings_id: ST.print.printer, print_settings_id: ST.print.process },
    presetPattern: ST.print.pattern, writeFilaments: ST.print.writeFilaments, layerHeight: ST.print.layer,
    title: 'sash', objects
  };
}
function printCardText(cfg) {
  const d = MODEL.dims, C = MODEL.check, G = MODEL.G;
  const L = [Orca3MF.printCard(cfg), 'SASH', '========================================',
    'badge     : ' + d.Wo.toFixed(1) + ' x ' + d.Ho.toFixed(1) + ' x ' + d.T.toFixed(2) + ' mm assembled',
    'shell     : front plate ' + d.tf.toFixed(2) + ' (' + Math.round(d.tf / ST.print.layer) + ' layers, inlay ' + d.inl.toFixed(2) + '), walls ' + d.hc.toFixed(2) + ' tall. prints FRONT FACE DOWN.',
    'slides    : ' + d.ts.toFixed(2) + ' thick, inlay ' + d.inls.toFixed(2) + '. print ART FACE DOWN, tab and bump in plane, no supports.',
    'cover     : ' + d.tc.toFixed(2) + ' thick, pegs ' + ST.cover.pegD + ' x ' + d.pegL.toFixed(2) + ' into ' + ST.cover.holeD + ' holes, keeper rib ' + d.ribH.toFixed(2) + ' tall over each tab slot. prints BACK FACE DOWN, pegs and rib up.',
    'tab       : ' + d.tabT.toFixed(2) + ' thick (art side of the slide), rides under the rib. the rib holds the slide body by ' + d.keep.toFixed(2) + ' mm so it cannot lift out through the slot.', ''];
  for (const l of C.lanes) L.push('lane ' + (l.i + 1) + ' ' + l.name + ': ' + l.N + ' positions at ' + l.p + ' mm, slide ' + l.Ls + ' x ' + l.Ws + ', travel ' + l.travel + ', click about ' + l.push + ' N (beam ' + l.beam + ' mm, deflection ' + l.defl + ', notch slack ' + l.slack + ')');
  L.push('');
  if (ST.magnets.mode === 'glue') L.push('magnets   : ' + ST.magnets.n + ' x ' + ST.magnets.d + ' x ' + ST.magnets.t + ' mm, pockets open on the back, glue them in flush after printing.');
  if (ST.magnets.mode === 'sealed') L.push('magnets   : ' + ST.magnets.n + ' x ' + ST.magnets.d + ' x ' + ST.magnets.t + ' mm sealed in the cover. PAUSE the cover before layer ' + C.magnet.pause + ' (z ' + (C.magnet.pause * ST.print.layer).toFixed(2) + ') and drop them in, matching poles.');
  L.push('', 'assembly  : 1 drop each slide into its cavity art face down, tab through the wall gap, bump toward the notched rail.',
    '            2 press the cover onto the end wall pegs, rib into the tab slot (glue if it walks). 3 click through every position. the first click is the stiffest.',
    'fits      : sides ' + ST.fit.cy + ', depth ' + ST.fit.cz + ' each side, ends ' + ST.fit.cx + ', peg press about ' + C.peg.printed + ' after FDM shrink. loosen or tighten in the FIT step and reprint only the part that binds.', '');
  for (const w of MODEL.warnings) L.push('warning   : ' + w);
  return L.join('\n') + '\n';
}
async function export3mf() { VIEW.paused = true; try { const pkg = Orca3MF.build(pkgConfig()); return await pkg.zip(); } finally { VIEW.paused = false; } }
async function exportStlZip() {
  VIEW.paused = true;
  try {
    const cfg = pkgConfig();
    const z = new JSZip();
    for (const o of cfg.objects) for (const p of o.parts) z.file('sash-' + o.name + '-' + p.name + '.stl', Orca3MF.stl(p));
    z.file('print-card.txt', printCardText(cfg));
    z.file('design.json', designJson());
    return await z.generateAsync({ type: 'blob', compression: 'DEFLATE' });
  } finally { VIEW.paused = false; }
}
function designJson() { return JSON.stringify({ app: 'sash-bench', v: 1, state: designSlice() }, null, 1); }
function loadDesign(txt) {
  const o = JSON.parse(txt), s = o.state || o, fresh = blankState();
  for (const k of DESIGN_KEYS) if (s[k] !== undefined) fresh[k] = k === 'print' ? Object.assign(fresh.print, s.print) : s[k];
  ST = fresh;
  ST.sim.k = ST.lanes.map(startK);
  UI.refreshAll(); commit();
}
function gridToCanvas(grid, labels) {
  const cv = document.createElement('canvas'); cv.width = grid.W; cv.height = grid.H;
  const ctx = cv.getContext('2d'), im = ctx.createImageData(grid.W, grid.H);
  for (let j = 0; j < grid.H; j++) for (let i = 0; i < grid.W; i++) {
    const v = labels[j * grid.W + i], q = ((grid.H - 1 - j) * grid.W + i) * 4;
    if (!v) { im.data[q + 3] = 0; continue; }
    const c = ST.colour.slots[v - 1].color;
    im.data[q] = parseInt(c.slice(1, 3), 16); im.data[q + 1] = parseInt(c.slice(3, 5), 16); im.data[q + 2] = parseInt(c.slice(5, 7), 16); im.data[q + 3] = 255;
  }
  ctx.putImageData(im, 0, 0);
  return cv;
}
function facesPng() {
  ensureMesh();
  const gs = MODEL.grids, items = [['shell', compositeLabels(gs.shell, gs, MODEL.G, ST.sim.k)]];
  for (const k of partKeys()) if (k.startsWith('slide')) items.push([k, gs[k].labels]);
  items.push(['cover', gs.cover.labels]);
  const cvs = items.map(([k, l]) => gridToCanvas(gs[k], l));
  const W = cvs.reduce((a, c) => a + c.width + 10, 10), H = Math.max(...cvs.map(c => c.height)) + 20;
  const out = document.createElement('canvas'); out.width = W; out.height = H;
  const ctx = out.getContext('2d'); ctx.fillStyle = '#0a0a0a'; ctx.fillRect(0, 0, W, H);
  let x = 10; for (const c of cvs) { ctx.drawImage(c, x, 10); x += c.width + 10; }
  return out;
}
function download(blob, name) { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000); }
BENCH.exportBytes = async kind => {
  let blob;
  if (kind === '3mf') blob = await export3mf();
  else if (kind === 'stl') blob = await exportStlZip();
  else if (kind === 'card') blob = new Blob([printCardText(pkgConfig())]);
  else if (kind === 'json') blob = new Blob([designJson()]);
  const buf = new Uint8Array(await blob.arrayBuffer());
  let s = ''; for (let i = 0; i < buf.length; i += 0x8000) s += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  return btoa(s);
};

// ------------------------------------------------------------ worn composite: shell front with the slides showing through the windows
function compositeLabels(shell, grids, G, ks) {
  const { W, H, px, x0, y0 } = shell, out = shell.labels.slice(), floor = ST.colour.roles.cover;
  for (const g of G.lanes) {
    const sg = grids['slide' + g.i]; if (!sg) continue;
    const k = ks[g.i] || 0;
    const ox = g.xLeft(k) + g.Ls / 2, oy = g.slideY + g.dir * g.Ws / 2;
    for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
      const p = j * W + i; if (!shell.winMask[p]) continue;
      const x = x0 + (i + 0.5) * px - ox, y = y0 + (j + 0.5) * px - oy;
      const ii = Math.floor((x - sg.x0) / sg.px), jj = Math.floor((y - sg.y0) / sg.px);
      let v = 0;
      if (ii >= 0 && jj >= 0 && ii < sg.W && jj < sg.H) v = sg.labels[jj * sg.W + ii];
      if (out[p] === 0 && v) out[p] = v;
    }
  }
  for (let p = 0; p < W * H; p++) if (shell.winMask[p] && out[p] === 0) out[p] = floor;
  return out;
}

// ------------------------------------------------------------ three viewer
const VIEW = {};
(function () {
  const cv = document.querySelector('#stage canvas.three');
  const renderer = new THREE.WebGLRenderer({ canvas: cv, antialias: true, alpha: true, preserveDrawingBuffer: true });
  renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
  const scene = new THREE.Scene();
  const cam = new THREE.PerspectiveCamera(32, 1, 1, 3000);
  scene.add(new THREE.AmbientLight(0xffffff, 0.6));
  const key = new THREE.DirectionalLight(0xffffff, 0.85); key.position.set(60, -80, 140); scene.add(key);
  const fill = new THREE.DirectionalLight(0xffe0f0, 0.35); fill.position.set(-80, 60, 60); scene.add(fill);
  const rim = new THREE.DirectionalLight(0xffffff, 0.35); rim.position.set(0, 0, -120); scene.add(rim);
  const group = new THREE.Group(); scene.add(group);
  const plate = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ color: 0x1a1a1a, transparent: true, opacity: 0.55, side: THREE.DoubleSide }));
  plate.position.z = -0.05; scene.add(plate);
  const orbit = { theta: -0.9, phi: 0.95, dist: 150, target: new THREE.Vector3(0, 0, 2) };
  function applyCam() {
    const t = orbit.target;
    cam.position.set(t.x + orbit.dist * Math.cos(orbit.phi) * Math.cos(orbit.theta), t.y + orbit.dist * Math.cos(orbit.phi) * Math.sin(orbit.theta), t.z + orbit.dist * Math.sin(orbit.phi));
    cam.up.set(0, 0, 1); cam.lookAt(t);
  }
  const presets = { iso: [-0.9, 0.95], top: [-Math.PI / 2, Math.PI / 2 - 0.001], front: [-Math.PI / 2, 0.12], under: [-0.9, -0.95] };
  VIEW.preset = k => { const p = presets[k]; if (p) { orbit.theta = p[0]; orbit.phi = p[1]; applyCam(); } };
  let drag = null;
  cv.addEventListener('pointerdown', e => { drag = { x: e.clientX, y: e.clientY, b: e.button }; cv.setPointerCapture(e.pointerId); });
  cv.addEventListener('pointermove', e => {
    if (!drag) return;
    const dx = e.clientX - drag.x, dy = e.clientY - drag.y; drag.x = e.clientX; drag.y = e.clientY;
    if (drag.b === 0) { orbit.theta -= dx * 0.008; orbit.phi = Math.max(-1.5, Math.min(1.5, orbit.phi + dy * 0.008)); }
    else { const r = new THREE.Vector3().subVectors(cam.position, orbit.target); const right = new THREE.Vector3().crossVectors(r, cam.up).normalize(); const up = new THREE.Vector3().crossVectors(right, r).normalize(); orbit.target.addScaledVector(right, dx * orbit.dist * 0.0015).addScaledVector(up, -dy * orbit.dist * 0.0015); }
    applyCam();
  });
  cv.addEventListener('pointerup', () => drag = null);
  cv.addEventListener('contextmenu', e => e.preventDefault());
  cv.addEventListener('wheel', e => { e.preventDefault(); orbit.dist = Math.max(20, Math.min(1200, orbit.dist * (e.deltaY > 0 ? 1.1 : 0.9))); applyCam(); }, { passive: false });
  function refit() {
    const T = MODEL.dims ? MODEL.dims.T : 5, Wo = MODEL.dims ? MODEL.dims.Wo : 60;
    if (ST.ui.view === 'plate') { orbit.target.set(0, 0, 0); orbit.dist = Math.max(120, Math.max(ST.plate.bedW, ST.plate.bedD) * 1.4); }
    else if (ST.ui.view === 'exploded') { orbit.target.set(0, 0, (3 * T + 16) / 2); orbit.dist = Math.max(60, Wo * 2.2); if (orbit.phi > 0.7) orbit.phi = 0.45; }
    else { orbit.target.set(0, 0, T / 2); orbit.dist = Math.max(60, Wo * 2.2); }
    applyCam();
  }
  cv.addEventListener('dblclick', refit);
  function resize() { const w = cv.clientWidth || 600, h = cv.clientHeight || 400; renderer.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); }
  new ResizeObserver(resize).observe(cv);
  const NODES = {};                                   // key -> THREE.Group of slot meshes
  let magNodes = [];
  function matFor(col, ghost) {
    let c = col; if (c.toUpperCase() === '#FFFFFF') c = '#F4F1EA';
    return new THREE.MeshStandardMaterial({ color: new THREE.Color(c), roughness: 0.55, metalness: 0.05, flatShading: true, transparent: !!ghost, opacity: ghost ? 0.28 : 1, depthWrite: !ghost });
  }
  VIEW.update = function () {
    while (group.children.length) { const n = group.children.pop(); n.traverse(m => { if (m.geometry) m.geometry.dispose(); if (m.material) m.material.dispose(); }); }
    for (const k in NODES) delete NODES[k];
    magNodes = [];
    if (!MODEL.parts) return;
    for (const key of partKeys()) {
      const node = new THREE.Group(); node.name = key;
      const meshes = MODEL.parts[key].meshes;
      for (const s in meshes) {
        const g = new THREE.BufferGeometry();
        g.setAttribute('position', new THREE.BufferAttribute(meshes[s].positions, 3));
        g.setIndex(new THREE.BufferAttribute(meshes[s].indices, 1));
        g.computeVertexNormals();
        const m = new THREE.Mesh(g, matFor(ST.colour.slots[s - 1].color, false)); m.userData.slot = +s;
        node.add(m);
      }
      NODES[key] = node; group.add(node);
    }
    // magnets as grey cylinders (not exported)
    const M = ST.magnets;
    if (M.mode !== 'off') for (const [mx, my] of MODEL.G.mags) {
      const cyl = new THREE.Mesh(new THREE.CylinderGeometry(M.d / 2, M.d / 2, M.t, 40), new THREE.MeshStandardMaterial({ color: 0x8a8f96, roughness: 0.3, metalness: 0.8 }));
      cyl.rotation.x = Math.PI / 2; cyl.userData.pos = [mx, my]; magNodes.push(cyl); group.add(cyl);
    }
    VIEW.pose(); VIEW.legend();
  };
  // place every part for the current view mode, slide positions from ST.sim.k
  VIEW.pose = function () {
    if (!MODEL.parts) return;
    const d = MODEL.dims, G = MODEL.G, mode = ST.ui.view, show = ST.ui.show;
    const ex = mode === 'exploded' ? 1 : 0;
    const lay = mode === 'plate' ? plateLayout() : null;
    for (const key of partKeys()) {
      const n = NODES[key]; if (!n) continue;
      const vis = show[key] || 'solid';
      n.visible = vis !== 'off';
      n.traverse(m => { if (m.material) { m.material.transparent = vis === 'ghost'; m.material.opacity = vis === 'ghost' ? 0.28 : 1; m.material.depthWrite = vis !== 'ghost'; m.material.needsUpdate = true; } });
      n.rotation.set(0, 0, 0);
      if (lay) { const p = lay.positions[key][0]; n.position.set(p[0] - ST.plate.bedW / 2, p[1] - ST.plate.bedD / 2, 0); continue; }
      if (key === 'shell') n.position.set(0, 0, 0);
      else if (key === 'cover') { n.rotation.y = Math.PI; n.position.set(0, 0, d.tf + d.hc + d.tc + ex * (2 * d.T + 16)); }
      else {
        const g = G.lanes.find(l => 'slide' + l.i === key), k = ST.sim.k[g.i] || 0;
        n.position.set(-(g.xLeft(k) + g.Ls / 2), g.slideY + g.dir * g.Ws / 2, d.tf + ST.fit.cz + ex * (d.T + 8));
      }
    }
    const M = ST.magnets, zc = d.tf + d.hc + d.tc + ex * (2 * d.T + 16);
    for (const cyl of magNodes) {
      cyl.visible = mode !== 'plate' && (show.magnets || 'solid') !== 'off';
      const [mx, my] = cyl.userData.pos;
      const zTop = M.mode === 'glue' ? zc : zc - 0.72;
      cyl.position.set(-mx, my, zTop - M.t / 2);
      cyl.material.transparent = show.magnets === 'ghost'; cyl.material.opacity = show.magnets === 'ghost' ? 0.3 : 1;
    }
    if (mode === 'plate') { group.rotation.set(0, 0, 0); group.position.set(0, 0, 0); plate.scale.set(ST.plate.bedW, ST.plate.bedD, 1); plate.position.set(0, 0, -0.05); }
    else { group.rotation.set(0, Math.PI, 0); group.position.set(0, 0, d.T + ex * (2 * d.T + 16)); plate.scale.set(d.Wo * 1.5, d.Ho * 2.2, 1); plate.position.set(0, 0, -0.05); }
  };
  VIEW.recolour = function () { for (const key in NODES) NODES[key].traverse(m => { if (m.userData.slot) { let c = ST.colour.slots[m.userData.slot - 1].color; if (c.toUpperCase() === '#FFFFFF') c = '#F4F1EA'; m.material.color.set(c); } }); VIEW.legend(); };
  VIEW.legend = function () {
    const el = document.getElementById('legend');
    el.innerHTML = ST.colour.slots.slice(0, ST.colour.n).map((sl, i) => '<div><i style="background:' + sl.color + '"></i>' + (i + 1) + ' ' + (sl.name || sl.type) + '</div>').join('');
  };
  VIEW.paused = false;
  VIEW.refit = refit;
  function loop() { if (!VIEW.paused) renderer.render(scene, cam); requestAnimationFrame(loop); }
  resize(); applyCam(); loop();
  VIEW.snapshot = () => cv.toDataURL('image/png');
})();

// ------------------------------------------------------------ UI
const UI = {};
(function () {
  const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
  const GUIDES = [
    ['STEP 1 LAYOUT', 'pick a preset, then say what each lane does: how many positions, how far apart, which rows show through the front. the face view shows the badge as worn; scrub positions in the bar above.'],
    ['STEP 2 ART', 'pick a surface, then a station, and lay faces, icons and text on it. drag on the canvas. the shell front shows what the windows reveal at the current position.'],
    ['STEP 3 FIT', 'shape, clearances, the detent click, cover pegs, magnets. ghost parts in the bar above to look inside; CHECK sweeps each slide through its cavity.'],
    ['STEP 4 COLOUR', 'say how many filaments you will load and which slot is each body. art already points at slot numbers.'],
    ['STEP 5 PRINT', 'layer height, print hygiene, plate copies. export the 3MF project with the filaments set up, or STLs as a fallback.']
  ];
  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;'); }
  // display position 1..N for internal k (count up lanes read from the left)
  const posOf = (l, k) => l.startLeft ? l.N - Math.round(k) : Math.round(k) + 1;
  const kOfPos = (l, d) => l.startLeft ? l.N - d : d - 1;
  const endLabel = (l, k) => k === 0 ? (l.startLeft ? 'all lit' : 'full') : k === l.N - 1 ? (l.startLeft ? 'start' : 'empty') : '';
  // ---- steps
  function go(step) {
    ST.ui.step = step; ST.ui.visited[step] = true;
    $$('#steps button').forEach(b => { const s = +b.dataset.step; b.classList.toggle('on', s === step); b.classList.toggle('done', ST.ui.visited[s] && s !== step); });
    $$('.pane').forEach(p => p.classList.toggle('on', +p.dataset.pane === step));
    $('#guide b').textContent = GUIDES[step][0]; $('#guideText').textContent = GUIDES[step][1];
    $('#stage').classList.toggle('art', step <= 1);
    // the print step wants the plate, everything else wants the badge
    if (step === 4 && ST.ui.view === 'assembled') { ST.ui.view = 'plate'; $$('#bar [data-view]').forEach(x => x.classList.toggle('on', x.dataset.view === 'plate')); VIEW.pose(); VIEW.refit(); }
    else if (step < 4 && ST.ui.view === 'plate') { ST.ui.view = 'assembled'; $$('#bar [data-view]').forEach(x => x.classList.toggle('on', x.dataset.view === 'assembled')); VIEW.pose(); VIEW.refit(); }
    if (step === 0 && ST.ui.surface !== 'shell') { ST.ui.surface = 'shell'; ST.ui.sel = null; }
    if (step <= 1) UI.preview(0);
  }
  $$('#steps button').forEach(b => b.onclick = () => go(+b.dataset.step));
  $$('[data-go]').forEach(b => b.onclick = () => go(+b.dataset.go));
  $$('#cams button').forEach(b => b.onclick = () => { $$('#cams button').forEach(x => x.classList.toggle('on', x === b)); VIEW.preset(b.dataset.cam); });
  // ---- generic bindings (idempotent): every [data-p] input reads/writes ST; range = touch on input, commit on change
  function bindAll(root) {
    (root ? [...root.querySelectorAll('[data-p]')] : $$('[data-p]')).forEach(el => {
      if (el._bound) return; el._bound = true;
      const p = el.dataset.p;
      const read = () => { const v = getP(p); if (el.type === 'checkbox') el.checked = !!v; else el.value = v; };
      read(); el._read = read;
      const write = () => { let v; if (el.type === 'checkbox') v = el.checked; else if (el.type === 'number' || el.type === 'range') v = +el.value; else if (el.tagName === 'SELECT' && el.value !== '' && !isNaN(+el.value)) v = +el.value; else v = el.value; setP(p, v); $$('[data-p="' + p + '"]').forEach(o => { if (o !== el && o._read) o._read(); }); };
      if (el.type === 'range') { el.addEventListener('input', () => { write(); touch(); }); el.addEventListener('change', () => { write(); afterP(p); commit(); }); }
      else el.addEventListener('change', () => { write(); afterP(p); commit(); });
    });
  }
  function afterP(p) {                                // structural changes re-render dependent UI
    if (p.startsWith('lanes.')) { const i = +p.split('.')[1]; fixLane(i); if (/\.(N|on|startLeft)$/.test(p) || p.endsWith('gauge.on') || p.endsWith('station.on')) { if (p.endsWith('startLeft')) ST.sim.k[i] = startK(ST.lanes[i]); renderLanes(); renderDetents(); renderSurfaces(); renderStations(); renderLayers(); renderProps(); } if (p.endsWith('.name')) { renderSurfaces(); renderPose(); } }
    if (p === 'colour.n') renderSlots();
    if (p.startsWith('magnets.')) renderMag();
    renderPose();
  }
  function fixLane(i) {
    const l = ST.lanes[i]; l.N = Math.max(2, Math.min(12, Math.round(l.N)));
    while (l.stations.length < l.N) l.stations.push({ layers: [] });
    while (l.gauge.cells.length < l.N - 1) l.gauge.cells.push(l.gauge.cells[l.gauge.cells.length - 1] || 3);
    if (ST.sim.k[i] > l.N - 1) ST.sim.k[i] = l.N - 1;
    if (!ST.lanes[0].on) ST.lanes[0].on = true;
  }
  // ---- LAYOUT: presets and lanes
  function renderPresets() {
    const host = $('#presets'); host.innerHTML = '';
    for (const k in PRESETS) { const d = document.createElement('div'); d.className = 'preset'; d.innerHTML = '<b>' + esc(PRESETS[k].name) + '</b><p>' + esc(PRESETS[k].note) + '</p>'; d.onclick = () => loadPreset(k); host.appendChild(d); }
    const w = $('#wPresets'); w.innerHTML = '';
    for (const k in PRESETS) { const d = document.createElement('div'); d.className = 'preset'; d.innerHTML = '<b>' + esc(PRESETS[k].name) + '</b><p>' + esc(PRESETS[k].note) + '</p>'; d.onclick = () => { loadPreset(k, true); $('#welcome').classList.add('hide'); }; w.appendChild(d); }
  }
  function hasArt() { return ST.art.shell.length + ST.art.cover.length + ST.lanes.reduce((a, l) => a + l.stations.reduce((b, s) => b + s.layers.length, 0), 0) > 0; }
  function loadPreset(k, force) {
    if (!force && hasArt() && !confirm('load the ' + PRESETS[k].name + ' preset? the current design is replaced (undo brings it back).')) return;
    ST = PRESETS[k].make(); ST.sim.k = ST.lanes.map(startK);
    UI.refreshAll(); commit();
  }
  function laneHtml(i) {
    const l = ST.lanes[i], P = 'lanes.' + i + '.';
    const num = (k, lab, min, max, step, unit) => '<div class="row"><label>' + lab + '</label><input type="range" data-p="' + P + k + '" min="' + min + '" max="' + max + '" step="' + step + '"><input type="number" data-p="' + P + k + '" step="' + step + '"><span class="u">' + (unit || '') + '</span></div>';
    const sel = (k, lab, opts) => '<div class="row"><label>' + lab + '</label><select data-p="' + P + k + '">' + opts.map(o => '<option value="' + o[0] + '">' + o[1] + '</option>').join('') + '</select></div>';
    const chk = (k, lab) => '<div class="row"><label>' + lab + '</label><input type="checkbox" data-p="' + P + k + '"><span class="u"></span></div>';
    return '<div class="row"><label>name</label><input type="text" data-p="' + P + 'name"></div>' +
      num('N', 'positions', 2, 12, 1) + num('p', 'pitch', 4, 16, 0.5, 'mm') +
      (ST.lanes[0].on && ST.lanes[1].on ? '<div class="row"><label>tab side</label><span class="note" style="margin:0">' + (i === 0 ? 'top edge (lane 1 of two)' : 'bottom edge (lane 2 of two)') + '</span></div>' : sel('tab.side', 'tab side', [['top', 'top edge'], ['bottom', 'bottom edge']])) +
      sel('tab.at', 'tab rides', [['block', 'the last lit cell'], ['end', 'the slide end'], ['centre', 'the slide centre']]) + chk('startLeft', 'counts up') +
      '<div class="note">counts up: the tab starts at the left and each push right lights a cell. position 1 is then the left end.</div>' +
      '<details class="fold"><summary>gauge row</summary>' + chk('gauge.on', 'cells') + num('gauge.h', 'row height', 2, 12, 0.5, 'mm') + num('gauge.mullion', 'mullion', 0.6, 3, 0.1, 'mm') + num('gauge.inset', 'window inset', 0.2, 2, 0.1, 'mm') +
      '<div class="note">cell colours, left to right at full. the last cell goes first.</div><div class="cells" id="cells' + i + '"></div></details>' +
      '<details class="fold" open><summary>station row</summary>' + chk('station.on', 'station window') + num('station.h', 'row height', 3, 16, 0.5, 'mm') + sel('station.win', 'window', WIN_SHAPES.map(s => [s, s])) + num('station.mullion', 'side hide', 0.6, 3, 0.1, 'mm') + num('station.inset', 'window inset', 0.2, 2, 0.1, 'mm') + num('station.offset', 'offset', 0, 3, 1, 'stations') + '</details>' +
      '<details class="fold"><summary>tab</summary>' + num('tab.w', 'width', 3, 12, 0.5, 'mm') + num('tab.h', 'stands proud', 1, 5, 0.1, 'mm') + '</details>' +
      '<div class="note" id="laneNote' + i + '"></div>';
  }
  function renderLanes() {
    for (const i of [0, 1]) {
      const host = $('#lane' + i); host.innerHTML = laneHtml(i); bindAll(host);
      host.style.display = ST.lanes[i].on || i === 0 ? '' : 'none';
      renderCells(i);
    }
    laneNotes();
  }
  function laneNotes() {
    for (const i of [0, 1]) { if (!ST.lanes[i].on) continue; const g = laneGeom(i); const el = $('#laneNote' + i); if (el) el.textContent = 'slide ' + g.Ls.toFixed(1) + ' x ' + g.Ws.toFixed(1) + ' mm, cavity ' + g.Lc.toFixed(1) + ' long, travel ' + ((g.N - 1) * g.p).toFixed(1) + ' mm. a linear slide is (2N-1) x pitch long: fewer positions or a tighter pitch is the way to a smaller badge.'; }
  }
  function renderCells(i) {
    const host = $('#cells' + i); if (!host) return; host.innerHTML = '';
    const l = ST.lanes[i]; fixLane(i);
    for (let c = 0; c < l.N - 1; c++) {
      const b = document.createElement('button'); const s = l.gauge.cells[c] || 3;
      b.innerHTML = '<i style="background:' + ST.colour.slots[s - 1].color + '"></i>' + (c + 1);
      b.title = 'cell ' + (c + 1) + ' slot ' + s + ', click to cycle';
      b.onclick = () => { l.gauge.cells[c] = (s % ST.colour.n) + 1; renderCells(i); commit(); };
      host.appendChild(b);
    }
  }
  // ---- FIT: shapes, detents, magnets, check
  function renderShapes() { const host = $('#shapes'); host.innerHTML = SHAPES_LIST.map(s => '<button class="chip' + (s === ST.shell.shape ? ' on' : '') + '" data-shape="' + s + '">' + s + '</button>').join(''); host.querySelectorAll('.chip').forEach(b => b.onclick = () => { ST.shell.shape = b.dataset.shape; renderShapes(); commit(); }); }
  function renderDetents() {
    const host = $('#detents'); host.innerHTML = '';
    ST.lanes.forEach((l, i) => {
      if (!l.on) return;
      const P = 'lanes.' + i + '.flex.';
      const num = (k, lab, min, max, step, unit) => '<div class="row"><label>' + lab + '</label><input type="range" data-p="' + P + k + '" min="' + min + '" max="' + max + '" step="' + step + '"><input type="number" data-p="' + P + k + '" step="' + step + '"><span class="u">' + (unit || '') + '</span></div>';
      const d = document.createElement('div'); d.className = 'panel';
      d.innerHTML = '<h3>DETENT ' + (i + 1) + ' <span class="sw">' + esc(l.name) + '</span></h3><div class="bd">' + num('L', 'beam length', 4, 20, 0.5, 'mm') + num('t', 'beam', 0.6, 2, 0.1, 'mm') + num('gap', 'slot', 0.35, 1.2, 0.05, 'mm') + num('bump', 'bump', 0.2, 1, 0.05, 'mm') + num('notch', 'notch', 0.1, 1, 0.05, 'mm') +
        '<div class="note">a cantilever cut into the slide edge, printed flat so it flexes along the layers. the bump rides over the rail between notches (deflection = bump minus side clearance) and drops into a notch at each position.</div><div class="readout" id="detRead' + i + '"></div></div>';
      host.appendChild(d); bindAll(d);
    });
    readDetents();
  }
  function readDetents() {
    if (!MODEL.check) return;
    for (const l of MODEL.check.lanes) { const el = $('#detRead' + l.i); if (el) el.innerHTML = '<div>click <span>' + l.push + ' N</span></div><div>normal <span>' + l.Fn + ' N</span></div><div>deflection <span>' + l.defl + ' mm</span></div><div>strain <span>' + l.strain + ' %</span></div><div>notch slack <span>' + l.slack + ' mm</span></div><div>beam <span>' + l.beam + ' mm</span></div>'; }
  }
  function renderMag() { $$('#magMode .chip').forEach(b => b.classList.toggle('on', b.dataset.mag === ST.magnets.mode)); }
  $$('#magMode .chip').forEach(b => b.onclick = () => { ST.magnets.mode = b.dataset.mag; renderMag(); commit(); });
  UI.readCheck = function () {
    readDetents();
    const C = MODEL.check, d = MODEL.dims; if (!C) return;
    const rows = [];
    rows.push('<div class="w">badge <span>' + d.Wo.toFixed(1) + ' x ' + d.Ho.toFixed(1) + ' x ' + d.T.toFixed(2) + '</span> mm</div>');
    for (const l of C.lanes) {
      rows.push('<div class="w">lane ' + (l.i + 1) + ' slide <span>' + l.Ls + ' x ' + l.Ws + '</span> in a <span>' + l.Lc + ' x ' + l.Hc + '</span> cavity</div>');
      rows.push('<div>sweep ' + (l.i + 1) + ' <span class="' + (l.overlapCells ? 'bad' : '') + '">' + (l.overlapCells ? l.overlapCells + ' cells hit at ' + l.overlapK : 'clear at every position') + '</span></div>');
      rows.push('<div>depth play <span>' + l.zClear + '</span> mm</div>');
      if (l.win !== null) rows.push('<div>window ' + (l.i + 1) + ' <span>' + l.win + '</span> mm, hides <span>' + l.winMargin + '</span></div>');
      rows.push('<div>tab reach <span>' + l.tabReach + '</span> mm</div>');
    }
    rows.push('<div class="w">keeper: tab <span>' + C.keeper.tabT + '</span> thick, rib <span class="' + (C.keeper.ribH ? '' : 'bad') + '">' + C.keeper.ribH + '</span> tall, holds the slide by <span class="' + (C.keeper.keep < 0.24 ? 'bad' : '') + '">' + C.keeper.keep + '</span> mm, tab room <span>' + C.keeper.tabZ + '</span></div>');
    rows.push('<div>peg press <span class="' + (C.peg.printed < 0 || C.peg.printed > 0.35 ? 'bad' : '') + '">' + C.peg.printed + '</span> mm after FDM</div>');
    rows.push('<div>peg nominal <span>' + C.peg.nominal + '</span> mm</div>');
    if (C.magnet) rows.push('<div>pocket <span>' + C.magnet.pocket + '</span> mm, floor <span>' + C.magnet.floor + '</span></div>');
    if (C.magnet && C.magnet.pause) rows.push('<div>pause before layer <span>' + C.magnet.pause + '</span></div>');
    if (C.midWall !== null) rows.push('<div>mid wall at notches <span class="' + (C.midWall < 0.8 ? 'bad' : '') + '">' + C.midWall + '</span> mm</div>');
    for (const w of C.warnings) rows.push('<div class="w bad">' + esc(w) + '</div>');
    $('#check').innerHTML = rows.join('');
  };
  // ---- COLOUR
  $$('#nslots .chip').forEach(b => b.onclick = () => { ST.colour.n = +b.dataset.n; clampSlots(); renderSlots(); renderRoles(); commit(); });
  function clampSlots() {
    const n = ST.colour.n, R = ST.colour.roles;
    R.shell = Math.min(R.shell, n); R.cover = Math.min(R.cover, n); R.slide = R.slide.map(s => Math.min(s, n));
    const fix = L => { if (L.slot > n) L.slot = n; if (L.slot2 > n) L.slot2 = n; };
    ST.art.shell.forEach(fix); ST.art.cover.forEach(fix);
    for (const l of ST.lanes) { l.stations.forEach(s => s.layers.forEach(fix)); l.gauge.cells = l.gauge.cells.map(c => Math.min(c, n)); }
  }
  function renderSlots() {
    $$('#nslots .chip').forEach(x => x.classList.toggle('on', +x.dataset.n === ST.colour.n));
    const host = $('#slots'); host.innerHTML = '';
    for (let i = 0; i < ST.colour.n; i++) {
      const sl = ST.colour.slots[i];
      const row = document.createElement('div'); row.className = 'slot';
      row.innerHTML = '<span class="n">' + (i + 1) + '</span><input type="color" value="' + sl.color + '"><input type="text" value="' + esc(sl.name) + '" placeholder="name"><select>' + Object.keys(Orca3MF.MATERIALS).map(m => '<option' + (m === sl.type ? ' selected' : '') + '>' + m + '</option>').join('') + '</select><span class="role">' + roleOf(i + 1) + '</span>';
      const [c, t, s] = row.querySelectorAll('input,select');
      c.addEventListener('input', () => { sl.color = c.value.toUpperCase(); VIEW.recolour(); UI.preview(0); renderCells(0); renderCells(1); });
      c.addEventListener('change', () => snapshot());
      t.addEventListener('change', () => { sl.name = t.value; snapshot(); VIEW.legend(); renderRoles(); });
      s.addEventListener('change', () => { sl.type = s.value; snapshot(); });
      host.appendChild(row);
    }
    renderRoles();
  }
  function roleOf(s) { const R = ST.colour.roles, r = []; if (R.shell === s) r.push('shell'); ST.lanes.forEach((l, i) => { if (l.on && R.slide[i] === s) r.push('slide ' + (i + 1)); }); if (R.cover === s) r.push('cover'); return r.join(' + '); }
  function renderRoles() {
    const host = $('#roles'); const opts = v => { let o = ''; for (let i = 1; i <= ST.colour.n; i++) o += '<option value="' + i + '"' + (i === v ? ' selected' : '') + '>' + i + ' ' + esc(ST.colour.slots[i - 1].name || '') + '</option>'; return o; };
    let h = '<div class="row"><label>shell body</label><select data-role="shell">' + opts(ST.colour.roles.shell) + '</select></div>';
    ST.lanes.forEach((l, i) => { if (l.on) h += '<div class="row"><label>slide ' + (i + 1) + ' body</label><select data-role="slide' + i + '">' + opts(ST.colour.roles.slide[i]) + '</select></div>'; });
    h += '<div class="row"><label>cover body</label><select data-role="cover">' + opts(ST.colour.roles.cover) + '</select></div>';
    h += '<div class="note">drained cells show the cover colour: the slide carries one blank cell in it and the cover floor does the rest. station art usually wants the shell colour so the faces match the front.</div>';
    host.innerHTML = h;
    host.querySelectorAll('[data-role]').forEach(s => s.onchange = () => { const r = s.dataset.role, v = +s.value; if (r === 'shell') ST.colour.roles.shell = v; else if (r === 'cover') ST.colour.roles.cover = v; else ST.colour.roles.slide[+r.slice(5)] = v; renderSlots(); commit(); });
  }
  // ---- ART: surfaces, stations, layers, props
  function renderSurfaces() {
    const host = $('#surfaces'); host.innerHTML = '';
    const list = surfaceList();
    if (!list.some(s => s.key === ST.ui.surface)) ST.ui.surface = 'shell';
    for (const s of list) { const b = document.createElement('button'); b.className = 'chip' + (s.key === ST.ui.surface ? ' on' : ''); b.textContent = s.label; b.onclick = () => { ST.ui.surface = s.key; ST.ui.sel = null; ST.ui.station = 0; renderSurfaces(); renderStations(); renderLayers(); renderProps(); UI.preview(0); }; host.appendChild(b); }
    const note = $('#surfNote');
    note.textContent = ST.ui.surface === 'shell' ? 'the front plate around the windows. bed face, mirrored on export so it reads right; it looks backwards in the slicer, that is correct. a cut layer is an extra window.'
      : ST.ui.surface === 'cover' ? 'the back of the badge, as read from behind. a credit, a name, a logo. kept clear of the pegs, the keeper rib and magnet pockets.'
        : 'the moving slide. each station is what the window shows at that position; art is clipped to its station and the window crops it, so art can be bigger than the window. features under 0.8 mm do not print.';
  }
  function renderStations() {
    const host = $('#stationRow'); host.innerHTML = '';
    if (!ST.ui.surface.startsWith('slide')) return;
    const i = +ST.ui.surface.slice(5), l = ST.lanes[i]; fixLane(i);
    if (ST.ui.station == null || ST.ui.station >= l.N) ST.ui.station = startK(l);
    const row = document.createElement('div'); row.className = 'chips'; row.style.marginTop = '8px';
    for (let d = 1; d <= l.N; d++) { const k = kOfPos(l, d); const b = document.createElement('button'); b.className = 'chip sm' + (k === ST.ui.station ? ' on pink' : ''); b.textContent = 'pos ' + d; b.onclick = () => { ST.ui.station = k; ST.ui.sel = null; ST.sim.k[i] = k; renderStations(); renderLayers(); renderProps(); renderPose(); VIEW.pose(); UI.preview(0); }; row.appendChild(b); }
    host.appendChild(row);
  }
  function layers() { return surfaceLayers(ST.ui.surface, ST.ui.station); }
  function sel() { return layers().find(x => x.id === ST.ui.sel) || null; }
  function layerTitle(Lr) { return Lr.kind === 'text' ? Lr.text : Lr.kind === 'shape' ? Lr.shape + ' ' + Lr.w + 'x' + Lr.h : Lr.kind === 'glyph' ? (Lr.glyph === 'face' ? 'face ' + Lr.face : Lr.glyph) : 'image'; }
  function layerFlag(Lr) {
    const g = MODEL.grids && MODEL.grids[ST.ui.surface]; if (!g || !g.stats || !g.stats[Lr.id]) return '';
    const s = g.stats[Lr.id]; if (!s.raw) return 'nothing lands';
    if (s.kept < s.raw * 0.55) return 'too thin'; if (s.kept < s.raw * 0.85) return 'losing detail'; return '';
  }
  function renderLayers() {
    const host = $('#layerList'); host.innerHTML = '';
    layers().slice().reverse().forEach(Lr => {
      const d = document.createElement('div'); d.className = 'layer' + (Lr.id === ST.ui.sel ? ' on' : '') + (Lr.mute ? ' mute' : '');
      const f = layerFlag(Lr);
      d.innerHTML = '<span class="k">' + (Lr.cut ? 'cut' : Lr.kind) + '</span><span class="t" id="t-' + Lr.id + '">' + esc(layerTitle(Lr)) + '</span>' + (f ? '<span class="f">' + f + '</span>' : '') + '<span class="k">s' + Lr.slot + '</span><button class="x" title="delete">x</button>';
      d.onclick = e => { if (e.target.classList.contains('x')) { del(Lr.id); return; } ST.ui.sel = Lr.id; renderLayers(); renderProps(); UI.preview(0); };
      host.appendChild(d);
    });
  }
  function del(id) { const a = layers(); const i = a.findIndex(x => x.id === id); if (i >= 0) a.splice(i, 1); if (ST.ui.sel === id) ST.ui.sel = null; renderLayers(); renderProps(); commit(); }
  function inkSlot() { const R = ST.colour.roles; if (ST.ui.surface.startsWith('slide')) return R.shell !== R.slide[+ST.ui.surface.slice(5)] ? R.shell : (R.slide[+ST.ui.surface.slice(5)] === 1 ? 2 : 1); return R.shell === 2 ? 1 : 2; }
  function add(kind, extra) {
    const onSlide = ST.ui.surface.startsWith('slide');
    const base = { id: newId(), kind, dx: 0, dy: 0, rot: 0, slot: inkSlot(), cut: false, mute: false };
    let Lr;
    if (kind === 'text') Lr = Object.assign(base, { text: 'TEXT', font: onSlide ? 'vt' : 'marker', size: onSlide ? 3 : 5, slot2: base.slot, splitGap: 0.6, arc: 0, ls: 0 });
    else if (kind === 'shape') Lr = Object.assign(base, { shape: 'ring', w: onSlide ? 4 : 12, h: onSlide ? 4 : 12, t: 0.8 });
    else if (kind === 'glyph') Lr = Object.assign(base, { glyph: 'face', face: 'smile', eyes: 'auto', mouth: 'auto', brows: 'auto', head: onSlide ? 'none' : 'ring', size: onSlide ? 4.6 : 8, stroke: strokeFor(onSlide ? 4.6 : 8), fill: 0.75, n: 3 });
    else Lr = Object.assign(base, { w: onSlide ? 4 : 16, mode: 'mono', thr: 0.5, invert: false, src: '' }, extra || {});
    layers().push(Lr); ST.ui.sel = Lr.id; renderLayers(); renderProps(); commit();
  }
  $$('[data-add]').forEach(b => b.onclick = () => { if (b.dataset.add === 'image') $('#drop').click(); else add(b.dataset.add); });
  function renderProps() {
    const host = $('#props'); const Lr = sel();
    if (!Lr) { host.innerHTML = '<div class="note">select or add a layer</div>'; return; }
    const onSlide = ST.ui.surface.startsWith('slide');
    const slotOpts = s => { let o = ''; for (let i = 1; i <= ST.colour.n; i++) o += '<option value="' + i + '"' + (i === s ? ' selected' : '') + '>' + i + ' ' + esc(ST.colour.slots[i - 1].name || '') + '</option>'; return o; };
    const rows = [];
    const num = (k, lab, min, max, step, unit) => rows.push('<div class="row"><label>' + lab + '</label><input type="range" data-k="' + k + '" min="' + min + '" max="' + max + '" step="' + step + '" value="' + Lr[k] + '"><input type="number" data-k="' + k + '" step="' + step + '" value="' + Lr[k] + '"><span class="u">' + (unit || '') + '</span></div>');
    const selRow = (k, lab, opts) => rows.push('<div class="row"><label>' + lab + '</label><select data-k="' + k + '">' + opts.map(o => '<option value="' + o + '"' + (o === Lr[k] ? ' selected' : '') + '>' + o + '</option>').join('') + '</select></div>');
    if (Lr.kind === 'glyph') {
      selRow('glyph', 'glyph', ICON_LIST);
      if (Lr.glyph === 'face') { selRow('face', 'face', Object.keys(FACES)); selRow('eyes', 'eyes', ['auto', ...EYES]); selRow('mouth', 'mouth', ['auto', ...MOUTHS]); selRow('brows', 'brows', ['auto', ...BROWS]); selRow('head', 'head', ['ring', 'none', 'fill']); }
      if (Lr.glyph === 'battery') num('fill', 'fill', 0, 1, 0.05, '');
      if (Lr.glyph === 'tally') num('n', 'count', 0, 9, 1, '');
      num('size', 'size', 1.5, 40, 0.1, 'mm'); num('stroke', 'stroke', 0.4, 2.5, 0.05, 'mm');
    } else if (Lr.kind === 'text') {
      rows.push('<div class="row"><label>text</label><input type="text" data-k="text" value="' + esc(Lr.text) + '"></div>');
      rows.push('<div class="note">a | splits the text into two slots, e.g. hack|.build</div>');
      rows.push('<div class="row"><label>font</label><select data-k="font">' + Object.keys(FONTS).map(f => '<option value="' + f + '"' + (f === Lr.font ? ' selected' : '') + '>' + FONTS[f] + '</option>').join('') + '</select></div>');
      num('size', 'size', 1.5, 30, 0.1, 'mm'); num('ls', 'spacing', -1, 3, 0.1, 'mm'); num('arc', 'arc radius', -40, 40, 0.5, 'mm'); num('splitGap', 'split gap', 0, 4, 0.1, 'mm');
      rows.push('<div class="row"><label>slot after |</label><select data-k="slot2">' + slotOpts(Lr.slot2) + '</select></div>');
    } else if (Lr.kind === 'shape') {
      selRow('shape', 'shape', ['ring', 'rect', 'ellipse', 'frame', 'diamond', 'chevrons', 'line', 'ticks']);
      num('w', 'width', 0.5, 120, 0.5, 'mm'); num('h', 'height', 0.5, 120, 0.5, 'mm'); num('t', 'stroke', 0.4, 20, 0.1, 'mm');
    } else {
      rows.push('<div class="row"><label>mode</label><select data-k="mode"><option value="mono"' + (Lr.mode === 'mono' ? ' selected' : '') + '>mono threshold</option><option value="silhouette"' + (Lr.mode === 'silhouette' ? ' selected' : '') + '>silhouette</option></select></div>');
      num('w', 'width', 1, 120, 0.5, 'mm'); num('thr', 'threshold', 0.05, 0.95, 0.05, '');
      rows.push('<div class="row"><label>invert</label><input type="checkbox" data-k="invert"' + (Lr.invert ? ' checked' : '') + '><span class="u"></span></div>');
    }
    num('dx', 'x', -60, 60, 0.25, 'mm'); num('dy', 'y', -40, 40, 0.25, 'mm'); num('rot', 'rotate', -180, 180, 1, 'deg');
    rows.push('<div class="row"><label>slot</label><select data-k="slot">' + slotOpts(Lr.slot) + '</select></div>');
    if (!onSlide) rows.push('<div class="row"><label>cut through</label><input type="checkbox" data-k="cut"' + (Lr.cut ? ' checked' : '') + '><span class="u"></span></div>');
    rows.push('<div class="row"><label>mute</label><input type="checkbox" data-k="mute"' + (Lr.mute ? ' checked' : '') + '><span class="u"></span></div>');
    rows.push('<div class="btns"><button class="ghost" data-act="dup">duplicate</button><button class="ghost" data-act="up">raise</button><button class="ghost" data-act="down">lower</button>' + (onSlide ? '<button class="ghost" data-act="all">copy to all stations</button>' : '<button class="ghost" data-act="other">copy to the other face</button>') + '</div>');
    host.innerHTML = rows.join('');
    host.querySelectorAll('[data-k]').forEach(el => {
      const k = el.dataset.k;
      const write = () => { let v; if (el.type === 'checkbox') v = el.checked; else if (el.type === 'number' || el.type === 'range') v = +el.value; else if (el.tagName === 'SELECT' && el.value !== '' && !isNaN(+el.value)) v = +el.value; else v = el.value; Lr[k] = v; host.querySelectorAll('[data-k="' + k + '"]').forEach(o => { if (o !== el && o.type !== 'checkbox') o.value = v; }); const t = document.getElementById('t-' + Lr.id); if (t) t.textContent = layerTitle(Lr); };
      if (el.type === 'range') { el.addEventListener('input', () => { write(); touch(); }); el.addEventListener('change', () => { write(); commit(); }); }
      else if (el.type === 'text') { el.addEventListener('input', () => { write(); touch(240); }); el.addEventListener('change', () => { write(); commit(); }); }
      else el.addEventListener('change', () => { write(); if (k === 'glyph' || k === 'face') renderProps(); renderLayers(); commit(); });
    });
    host.querySelectorAll('[data-act]').forEach(b => b.onclick = () => {
      const a = layers(), i = a.indexOf(Lr);
      if (b.dataset.act === 'dup') { const c = JSON.parse(JSON.stringify(Lr)); c.id = newId(); c.dx += 1; c.dy -= 1; a.splice(i + 1, 0, c); ST.ui.sel = c.id; }
      if (b.dataset.act === 'up' && i < a.length - 1) { a.splice(i, 1); a.splice(i + 1, 0, Lr); }
      if (b.dataset.act === 'down' && i > 0) { a.splice(i, 1); a.splice(i - 1, 0, Lr); }
      if (b.dataset.act === 'other') { const c = JSON.parse(JSON.stringify(Lr)); c.id = newId(); ST.art[ST.ui.surface === 'shell' ? 'cover' : 'shell'].push(c); }
      if (b.dataset.act === 'all') { const l = ST.lanes[+ST.ui.surface.slice(5)]; l.stations.forEach((s, k) => { if (k === ST.ui.station) return; const c = JSON.parse(JSON.stringify(Lr)); c.id = newId(); s.layers.push(c); }); }
      renderLayers(); renderProps(); commit();
    });
  }
  // ---- image drop
  const drop = $('#drop');
  const fileIn = document.createElement('input'); fileIn.type = 'file'; fileIn.accept = 'image/*';
  drop.onclick = () => fileIn.click();
  fileIn.onchange = () => { if (fileIn.files[0]) loadImage(fileIn.files[0]); fileIn.value = ''; };
  ['dragenter', 'dragover'].forEach(ev => document.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(ev => document.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
  document.addEventListener('drop', e => { const f = e.dataTransfer.files[0]; if (!f) return; if (/\.json$/i.test(f.name)) f.text().then(loadDesign); else if (f.type.startsWith('image/') || /\.svg$/i.test(f.name)) loadImage(f); });
  function loadImage(file) { const r = new FileReader(); r.onload = () => { if (ST.ui.step !== 1) go(1); add('image', { src: r.result }); }; r.readAsDataURL(file); }
  // ---- stage bar: view, part chips, pose sliders
  $$('#bar [data-view]').forEach(b => b.onclick = () => { ST.ui.view = b.dataset.view; $$('#bar [data-view]').forEach(x => x.classList.toggle('on', x === b)); VIEW.pose(); VIEW.refit(); });
  const PART_LABEL = { shell: 'shell', slide0: 'slide 1', slide1: 'slide 2', cover: 'cover', magnets: 'magnets' };
  function renderParts() {
    const host = $('#partChips'); host.querySelectorAll('button').forEach(b => b.remove());
    const keys = ['shell', 'slide0']; if (ST.lanes[1].on) keys.push('slide1'); keys.push('cover'); if (ST.magnets.mode !== 'off') keys.push('magnets');
    for (const k of keys) {
      const b = document.createElement('button'); const v = ST.ui.show[k] || 'solid';
      b.textContent = PART_LABEL[k] + (v === 'ghost' ? ' (ghost)' : v === 'off' ? ' (off)' : '');
      b.className = v === 'ghost' ? 'ghosted' : v === 'off' ? 'off' : '';
      b.title = 'click: solid, ghost, off';
      b.onclick = () => { ST.ui.show[k] = v === 'solid' ? 'ghost' : v === 'ghost' ? 'off' : 'solid'; renderParts(); VIEW.pose(); };
      host.appendChild(b);
    }
  }
  let anim = null;
  function renderPose() {
    const host = $('#poseChips'); host.innerHTML = '';
    ST.lanes.forEach((l, i) => {
      if (!l.on) return;
      const wrap = document.createElement('div'); wrap.className = 'grp';
      const toV = k => l.startLeft ? l.N - 1 - k : k;
      wrap.innerHTML = '<span class="lab">' + esc(l.name) + '</span><button data-step="-1">&lt;</button><input type="range" min="0" max="' + (l.N - 1) + '" step="0.02" value="' + toV(ST.sim.k[i] || 0) + '"><button data-step="1">&gt;</button><span class="k">pos ' + posOf(l, ST.sim.k[i] || 0) + '</span>';
      const r = wrap.querySelector('input'), kk = wrap.querySelector('.k');
      const set = k => { ST.sim.k[i] = Math.max(0, Math.min(l.N - 1, k)); r.value = toV(ST.sim.k[i]); kk.textContent = 'pos ' + posOf(l, ST.sim.k[i]) + (Math.abs(ST.sim.k[i] - Math.round(ST.sim.k[i])) > 0.1 ? ' (between)' : ''); VIEW.pose(); UI.preview(0); };
      r.addEventListener('input', () => set(toV(+r.value)));
      r.addEventListener('change', () => set(toV(Math.round(+r.value))));
      wrap.querySelectorAll('button[data-step]').forEach(b => b.onclick = () => set(Math.round(ST.sim.k[i]) + (l.startLeft ? -1 : 1) * (+b.dataset.step)));
      host.appendChild(wrap);
    });
    const play = document.createElement('button'); play.textContent = anim ? 'stop' : 'sweep'; play.className = anim ? 'on' : '';
    play.onclick = () => { if (anim) { cancelAnimationFrame(anim); anim = null; renderPose(); return; } const t0 = performance.now(); const step = () => { const t = (performance.now() - t0) / 1000; ST.lanes.forEach((l, i) => { if (!l.on) return; const T = 1.2 * (l.N - 1); const ph = (t % (2 * T)) / T; ST.sim.k[i] = (ph < 1 ? ph : 2 - ph) * (l.N - 1); }); VIEW.pose(); UI.preview(0); host.querySelectorAll('input').forEach((r, j) => { const idx = ST.lanes.map((l, i) => l.on ? i : -1).filter(i => i >= 0)[j]; const l = ST.lanes[idx]; r.value = l.startLeft ? l.N - 1 - ST.sim.k[idx] : ST.sim.k[idx]; }); anim = requestAnimationFrame(step); }; anim = requestAnimationFrame(step); renderPose(); };
    host.appendChild(play);
  }
  // ---- face editor
  const fcv = $('#face canvas'), fctx = fcv.getContext('2d');
  const FE = { base: 1, zoom: 1, panX: 0, panY: 0, scale: 1, ox: 0, oy: 0, drag: null, handles: null, cache: new Map() };
  const HANDLE = 5, ROT_STEM = 26, HIT = 9;
  UI.FE = FE;
  const mm2px = (x, y) => [FE.ox + x * FE.scale, FE.oy - y * FE.scale];
  const px2mm = (px, py) => [(px - FE.ox) / FE.scale, -(py - FE.oy) / FE.scale];
  let prevTimer = null;
  UI.preview = function (delay) { clearTimeout(prevTimer); prevTimer = setTimeout(drawPreview, delay || 0); };
  function origin(Lr) { return ST.ui.surface.startsWith('slide') ? stationOrigin(ST.ui.surface, ST.ui.station) : [0, 0]; }
  function layerBBox(Lr) {
    const sig = JSON.stringify(Object.assign({}, Lr, { dx: 0, dy: 0, rot: 0, id: 0, slot: 0, slot2: 0, cut: 0, mute: 0 }));
    if (FE.cache.has(sig)) return FE.cache.get(sig);
    const res = 3, ext = Math.max(20, 2 * ((Lr.w || 0) + Math.abs(Lr.arc || 0) + (Lr.size || 0) + (Lr.kind === 'text' ? String(Lr.text || '').length * (Lr.size || 3) * 0.4 : 0)) + 8);
    const W = Math.ceil(ext * res), cv = document.createElement('canvas'); cv.width = W; cv.height = W;
    const ctx = cv.getContext('2d', { willReadFrequently: true });
    const parts = (Lr.kind === 'text' && String(Lr.text).includes('|') && !Lr.arc) ? 2 : 1;
    let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    for (let part = 0; part < parts; part++) {
      ctx.clearRect(0, 0, W, W);
      paintLayer(ctx, Object.assign({}, Lr, { dx: 0, dy: 0, rot: 0 }), res, [0, 0], part);
      const d = ctx.getImageData(0, 0, W, W).data;
      for (let j = 0; j < W; j++) for (let i = 0; i < W; i++) if (d[(j * W + i) * 4 + 3] > 127) { const x = (i + 0.5 - W / 2) / res, y = (W / 2 - j - 0.5) / res; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    }
    const bb = x0 > x1 ? null : { x0: x0 - 0.4, y0: y0 - 0.4, x1: x1 + 0.4, y1: y1 + 0.4 };
    FE.cache.set(sig, bb); if (FE.cache.size > 200) FE.cache.delete(FE.cache.keys().next().value);
    return bb;
  }
  function layerHandles(Lr) {
    const bb = layerBBox(Lr); if (!bb) return null;
    const o = origin(Lr), r = (Lr.rot || 0) * Math.PI / 180, c = Math.cos(r), sn = Math.sin(r);
    const cx = o[0] + Lr.dx, cy = o[1] + Lr.dy;
    const loc = [[bb.x0, bb.y0], [bb.x1, bb.y0], [bb.x1, bb.y1], [bb.x0, bb.y1]];
    const corners = loc.map(([x, y]) => mm2px(cx + x * c - y * sn, cy + x * sn + y * c));
    const top = [(bb.x0 + bb.x1) / 2, bb.y1];
    const topPx = mm2px(cx + top[0] * c - top[1] * sn, cy + top[0] * sn + top[1] * c);
    const ux = -sn, uy = -c;
    return { bb, corners, top: topPx, dot: [topPx[0] + ux * ROT_STEM, topPx[1] + uy * ROT_STEM], centre: mm2px(cx, cy), cx, cy };
  }
  function insideBox(h, px, py) { const q = h.corners; let s = 0; for (let i = 0; i < 4; i++) { const a = q[i], b = q[(i + 1) % 4]; const cr = (b[0] - a[0]) * (py - a[1]) - (b[1] - a[1]) * (px - a[0]); if (i === 0) s = Math.sign(cr); else if (Math.sign(cr) !== s && cr !== 0) return false; } return true; }
  function hitTest(px, py) {
    const Lr = sel();
    if (Lr) { const h = layerHandles(Lr); if (h) { if (Math.hypot(px - h.dot[0], py - h.dot[1]) <= HIT) return { mode: 'rotate', L: Lr }; for (let i = 0; i < 4; i++) if (Math.hypot(px - h.corners[i][0], py - h.corners[i][1]) <= HIT) return { mode: 'scale', L: Lr, corner: i }; if (insideBox(h, px, py)) return { mode: 'move', L: Lr }; } }
    const a = layers();
    for (let i = a.length - 1; i >= 0; i--) { const h = layerHandles(a[i]); if (h && insideBox(h, px, py)) return { mode: 'select', L: a[i] }; }
    // on a slide: clicking a station frame selects that station
    if (ST.ui.surface.startsWith('slide')) { const [mx] = px2mm(px, py); const g = laneGeom(+ST.ui.surface.slice(5)); const k = Math.floor((mx + g.Ls / 2) / g.p) - g.m; if (k >= 0 && k < g.N && k !== ST.ui.station) return { mode: 'station', k }; }
    return { mode: 'none' };
  }
  // the grid to draw: exact after a build, quick 4 px/mm otherwise; shell shows the worn composite
  function previewGrid() {
    const key = ST.ui.surface;
    const exact = !FE.drag && MODEL.grids && !MODEL.dirty && !MODEL.building && MODEL.grids[key];
    if (exact) {
      const g = MODEL.grids[key];
      return { grid: g, labels: key === 'shell' ? compositeLabels(g, MODEL.grids, MODEL.G, ST.sim.k) : g.labels, exact: true };
    }
    const G = shellGeom();
    if (key === 'shell') {
      const sh = composeShell(4, G), grids = { shell: sh };
      for (const g of G.lanes) grids['slide' + g.i] = composeSlide(g.i, 4, G);
      return { grid: sh, labels: compositeLabels(sh, grids, G, ST.sim.k), exact: false };
    }
    const g = composeSurface(key, 4, G);
    return { grid: g, labels: g.labels, exact: false };
  }
  function drawPreview() {
    if (ST.ui.step > 1) return;
    const w = fcv.clientWidth || 400, h = fcv.clientHeight || 400;
    if (fcv.width !== w || fcv.height !== h) { fcv.width = w; fcv.height = h; }
    const pv = previewGrid(), f = pv.grid;
    const strip = ST.ui.surface === 'shell' && ST.ui.step === 0;
    const areaH = strip ? h * 0.7 : h;
    FE.base = Math.min(w / (f.W * f.px), areaH / (f.H * f.px)) * 0.86;
    FE.scale = FE.base * FE.zoom; FE.ox = w / 2 + FE.panX; FE.oy = areaH / 2 + FE.panY;
    fctx.clearRect(0, 0, w, h);
    const tmp = gridToCanvas(f, pv.labels);
    fctx.imageSmoothingEnabled = false;
    const px = f.px * FE.scale, ox = FE.ox - f.W * px / 2, oy = FE.oy - f.H * px / 2;
    fctx.drawImage(tmp, ox, oy, f.W * px, f.H * px);
    // overlays
    const key = ST.ui.surface;
    if (key.startsWith('slide')) {
      const g = laneGeom(+key.slice(5)), dir = g.dir;
      fctx.lineWidth = 1; fctx.setLineDash([4, 3]);
      if (g.stationOn) for (let k = 0; k < g.N; k++) {
        const r = g.rowY.station, x0 = (g.m + k) * g.p - g.Ls / 2, x1 = x0 + g.p, ya = dir * (r.y0 - g.Ws / 2), yb = dir * (r.y1 - g.Ws / 2);
        const [ax, ay] = mm2px(x0, Math.max(ya, yb)), [bx, by] = mm2px(x1, Math.min(ya, yb));
        fctx.strokeStyle = k === ST.ui.station ? '#a6e22e' : 'rgba(154,145,132,.7)';
        fctx.strokeRect(ax, ay, bx - ax, by - ay);
        fctx.fillStyle = k === ST.ui.station ? '#a6e22e' : '#9a9184'; fctx.font = '14px VT323'; fctx.fillText('pos ' + posOf(ST.lanes[g.i], k), ax + 3, ay + 13);
      }
      fctx.setLineDash([]);
    }
    if (key === 'shell' && MODEL.G) {
      // tab positions at the current pose
      fctx.strokeStyle = 'rgba(166,226,46,.6)'; fctx.setLineDash([3, 3]); fctx.lineWidth = 1;
      for (const g of MODEL.G.lanes) { const k = ST.sim.k[g.i] || 0; const x = g.xLeft(k) + g.xt, ey = g.tabTop ? MODEL.G.Ho / 2 : -MODEL.G.Ho / 2; const [ax, ay] = mm2px(x - g.tabW / 2, ey + (g.tabTop ? ST.lanes[g.i].tab.h : 0)), [bx, by] = mm2px(x + g.tabW / 2, ey - (g.tabTop ? 0 : ST.lanes[g.i].tab.h)); fctx.strokeRect(ax, ay, bx - ax, by - ay); }
      fctx.setLineDash([]);
    }
    if (FE.drag && FE.drag.mode === 'move' && FE.drag.snapped) {
      fctx.strokeStyle = 'rgba(166,226,46,.7)'; fctx.setLineDash([3, 3]); fctx.lineWidth = 1;
      const o = origin(FE.drag.L), [cxp, cyp] = mm2px(o[0], o[1]);
      if (FE.drag.snapped.x) { fctx.beginPath(); fctx.moveTo(cxp, 0); fctx.lineTo(cxp, h); fctx.stroke(); }
      if (FE.drag.snapped.y) { fctx.beginPath(); fctx.moveTo(0, cyp); fctx.lineTo(w, cyp); fctx.stroke(); }
      fctx.setLineDash([]);
    }
    const Lr = sel(); FE.handles = null;
    if (Lr) {
      const hd = layerHandles(Lr);
      if (hd) {
        FE.handles = hd;
        fctx.strokeStyle = '#FE0386'; fctx.lineWidth = 1.5; fctx.setLineDash([6, 4]);
        fctx.beginPath(); hd.corners.forEach((c, i) => i ? fctx.lineTo(c[0], c[1]) : fctx.moveTo(c[0], c[1])); fctx.closePath(); fctx.stroke();
        fctx.setLineDash([]);
        fctx.beginPath(); fctx.moveTo(hd.top[0], hd.top[1]); fctx.lineTo(hd.dot[0], hd.dot[1]); fctx.stroke();
        fctx.fillStyle = '#FE0386';
        for (const c of hd.corners) fctx.fillRect(c[0] - HANDLE, c[1] - HANDLE, HANDLE * 2, HANDLE * 2);
        fctx.beginPath(); fctx.arc(hd.dot[0], hd.dot[1], HANDLE + 1, 0, Math.PI * 2); fctx.fill();
        fctx.fillStyle = '#0a0a0a'; fctx.beginPath(); fctx.arc(hd.dot[0], hd.dot[1], 2.5, 0, Math.PI * 2); fctx.fill();
        fctx.fillStyle = '#a6e22e'; fctx.font = '15px VT323';
        if (FE.drag && FE.drag.mode === 'rotate') fctx.fillText(Math.round(Lr.rot) + ' deg', hd.dot[0] + 12, hd.dot[1] + 5);
        if (FE.drag && FE.drag.mode === 'scale') fctx.fillText((hd.bb.x1 - hd.bb.x0).toFixed(1) + ' x ' + (hd.bb.y1 - hd.bb.y0).toFixed(1) + ' mm', hd.corners[2][0] + 10, hd.corners[2][1] + 14);
      }
    }
    fctx.fillStyle = '#9a9184'; fctx.font = '15px VT323';
    const lab = key === 'shell' ? 'FRONT as worn' : key === 'cover' ? 'BACK as read from behind' : ('SLIDE ' + (+key.slice(5) + 1) + ' art face');
    fctx.fillText(lab + '  ' + (f.W * f.px).toFixed(0) + ' mm' + (pv.exact ? '  print raster' : '  preview') + (FE.zoom !== 1 ? '  x' + FE.zoom.toFixed(1) : ''), 10, 20);
    if (strip) drawStrip(w, areaH, h - areaH);
  }
  // filmstrip: every position of lane 1 at the bottom of the front view
  function drawStrip(w, y0, sh) {
    if (!MODEL.grids || MODEL.dirty) return;
    const g0 = MODEL.G.lanes[0]; if (!g0) return;
    const N = g0.N, f = MODEL.grids.shell, cw = Math.min((w - 10) / N - 6, 220), scale = Math.min(cw / (f.W * f.px), (sh - 26) / (f.H * f.px));
    fctx.fillStyle = 'rgba(10,10,10,.6)'; fctx.fillRect(0, y0, w, sh);
    const l0 = ST.lanes[0];
    for (let d = 1; d <= N; d++) {
      const k = kOfPos(l0, d);
      const ks = ST.sim.k.slice(); ks[0] = k;
      const labels = compositeLabels(f, MODEL.grids, MODEL.G, ks);
      const cv = gridToCanvas(f, labels);
      const x = 8 + (d - 1) * (cw + 6), yy = y0 + 22;
      fctx.imageSmoothingEnabled = true;
      fctx.drawImage(cv, x, yy, f.W * f.px * scale, f.H * f.px * scale);
      const e = endLabel(l0, k);
      fctx.fillStyle = Math.round(ST.sim.k[0]) === k ? '#FE0386' : '#9a9184'; fctx.font = '14px VT323'; fctx.fillText('pos ' + d + (e ? ' ' + e : ''), x, y0 + 15);
    }
  }
  function localPos(e) { const r = fcv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  fcv.addEventListener('pointerdown', e => {
    const [px, py] = localPos(e);
    fcv.setPointerCapture(e.pointerId);
    if (e.button !== 0) { FE.drag = { mode: 'pan', x: e.clientX, y: e.clientY, panX: FE.panX, panY: FE.panY }; return; }
    if (ST.ui.step === 0) { if (ST.ui.surface === 'shell' && MODEL.G) { const strip = fcv.clientHeight * 0.7; if (py > strip) { const g0 = MODEL.G.lanes[0]; const N = g0.N, cw = Math.min((fcv.clientWidth - 10) / N - 6, 220); const d = Math.floor((px - 8) / (cw + 6)) + 1; if (d >= 1 && d <= N) { ST.sim.k[0] = kOfPos(ST.lanes[0], d); renderPose(); VIEW.pose(); UI.preview(0); } } } FE.drag = null; return; }
    const ht = hitTest(px, py);
    if (ht.mode === 'station') { ST.ui.station = ht.k; ST.ui.sel = null; ST.sim.k[+ST.ui.surface.slice(5)] = ht.k; renderStations(); renderLayers(); renderProps(); renderPose(); VIEW.pose(); FE.drag = null; UI.preview(0); return; }
    if (ht.mode === 'none') { ST.ui.sel = null; renderLayers(); renderProps(); FE.drag = null; UI.preview(0); return; }
    if (ht.mode === 'select') { ST.ui.sel = ht.L.id; renderLayers(); renderProps(); }
    const Lr = ht.L, o = origin(Lr);
    const [mx, my] = px2mm(px, py);
    FE.drag = { mode: ht.mode === 'select' ? 'move' : ht.mode, L: Lr, x: e.clientX, y: e.clientY, dx: Lr.dx, dy: Lr.dy, rot: Lr.rot || 0, size: Lr.size, w: Lr.w, h: Lr.h, t: Lr.t,
      d0: Math.max(0.5, Math.hypot(mx - o[0] - Lr.dx, my - o[1] - Lr.dy)), a0: Math.atan2(my - o[1] - Lr.dy, mx - o[0] - Lr.dx), snapped: null };
    UI.preview(0);
  });
  fcv.addEventListener('pointermove', e => {
    const [px, py] = localPos(e);
    if (!FE.drag) { if (ST.ui.step !== 1) { fcv.style.cursor = 'default'; return; } const ht = hitTest(px, py); fcv.style.cursor = ht.mode === 'rotate' ? 'crosshair' : ht.mode === 'scale' ? 'nwse-resize' : ht.mode === 'move' ? 'grab' : ht.mode === 'select' || ht.mode === 'station' ? 'pointer' : 'default'; return; }
    const D = FE.drag;
    if (D.mode === 'pan') { FE.panX = D.panX + (e.clientX - D.x); FE.panY = D.panY + (e.clientY - D.y); UI.preview(0); return; }
    const Lr = D.L, o = origin(Lr);
    const [mx, my] = px2mm(px, py);
    if (D.mode === 'move') {
      let ddx = (e.clientX - D.x) / FE.scale, ddy = -(e.clientY - D.y) / FE.scale;
      if (e.shiftKey) { if (Math.abs(ddx) > Math.abs(ddy)) ddy = 0; else ddx = 0; }
      let nx = D.dx + ddx, ny = D.dy + ddy;
      D.snapped = { x: false, y: false };
      if (!e.altKey) { if (Math.abs(nx) < 0.6) { nx = 0; D.snapped.x = true; } if (Math.abs(ny) < 0.6) { ny = 0; D.snapped.y = true; } }
      Lr.dx = Math.round(nx * 4) / 4; Lr.dy = Math.round(ny * 4) / 4;
    } else if (D.mode === 'scale') {
      const k = Math.max(0.15, Math.hypot(mx - o[0] - Lr.dx, my - o[1] - Lr.dy) / D.d0);
      if (Lr.kind === 'text' || Lr.kind === 'glyph') Lr.size = Math.max(1.5, Math.round(D.size * k * 10) / 10);
      else if (Lr.kind === 'shape') { Lr.w = Math.max(0.5, Math.round(D.w * k * 10) / 10); Lr.h = Math.max(0.5, Math.round(D.h * k * 10) / 10); if (!e.shiftKey) Lr.t = Math.max(0.4, Math.round(D.t * k * 10) / 10); }
      else Lr.w = Math.max(1, Math.round(D.w * k * 10) / 10);
    } else if (D.mode === 'rotate') {
      let deg = D.rot + (Math.atan2(my - o[1] - Lr.dy, mx - o[0] - Lr.dx) - D.a0) * 180 / Math.PI;
      deg = ((deg + 180) % 360 + 360) % 360 - 180;
      if (e.shiftKey) deg = Math.round(deg / 15) * 15; else if (!e.altKey) { for (const s of [-180, -90, 0, 90, 180]) if (Math.abs(deg - s) < 4) deg = s; }
      Lr.rot = Math.round(deg);
    }
    touch(0);
  });
  const endDrag = () => { if (!FE.drag) return; const m = FE.drag.mode; FE.drag = null; if (m === 'pan') { UI.preview(0); return; } renderProps(); commit(); };
  fcv.addEventListener('pointerup', endDrag); fcv.addEventListener('pointercancel', endDrag);
  fcv.addEventListener('contextmenu', e => e.preventDefault());
  fcv.addEventListener('wheel', e => {
    e.preventDefault();
    const [px, py] = localPos(e), [mx, my] = px2mm(px, py);
    FE.zoom = Math.max(0.5, Math.min(8, FE.zoom * (e.deltaY > 0 ? 0.9 : 1.1)));
    FE.scale = FE.base * FE.zoom;
    const w = fcv.clientWidth, areaH = (ST.ui.surface === 'shell' && ST.ui.step === 0) ? fcv.clientHeight * 0.7 : fcv.clientHeight;
    FE.panX = px - w / 2 - mx * FE.scale; FE.panY = py - areaH / 2 + my * FE.scale;
    UI.preview(0);
  }, { passive: false });
  fcv.addEventListener('dblclick', () => { const Lr = sel(); if (Lr && Lr.kind === 'text') { const t = $('#props input[data-k="text"]'); if (t) { t.focus(); t.select(); } return; } FE.zoom = 1; FE.panX = 0; FE.panY = 0; UI.preview(0); });
  document.addEventListener('keydown', e => {
    if (e.target.matches('input,textarea,select')) return;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); if (e.shiftKey) redo(); else undo(); return; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); return; }
    const Lr = sel(); if (!Lr || ST.ui.step !== 1) return;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'd') { e.preventDefault(); $('#props [data-act="dup"]').click(); return; }
    if (e.key === '[') { $('#props [data-act="down"]').click(); return; }
    if (e.key === ']') { $('#props [data-act="up"]').click(); return; }
    const s = e.shiftKey ? 5 : 0.25;
    if (e.key === 'ArrowLeft') Lr.dx -= s; else if (e.key === 'ArrowRight') Lr.dx += s; else if (e.key === 'ArrowUp') Lr.dy += s; else if (e.key === 'ArrowDown') Lr.dy -= s;
    else if (e.key === 'Delete' || e.key === 'Backspace') { del(Lr.id); return; } else return;
    e.preventDefault(); renderProps(); commit();
  });
  new ResizeObserver(() => UI.preview(0)).observe(fcv);
  // ---- status + readout
  UI.status = function (msg) {
    $('#sDims').textContent = MODEL.dims ? (MODEL.dims.Wo.toFixed(1) + ' x ' + MODEL.dims.Ho.toFixed(1) + ' x ' + MODEL.dims.T.toFixed(2) + ' mm') : '-';
    $('#sTris').textContent = MODEL.tris ? MODEL.tris.toLocaleString() + ' tris' : '-';
    $('#sMs').textContent = msg ? msg : (MODEL.ms ? Math.round(MODEL.ms) + ' ms' : '');
    const chips = [];
    const lay = plateLayout();
    chips.push('<span class="c ' + (lay.fits ? 'ok' : 'err') + '">' + (lay.fits ? 'fits bed' : 'over bed') + '</span>');
    chips.push('<span class="c ' + (MODEL.dirty ? 'warn' : 'ok') + '">' + (MODEL.dirty ? 'mesh stale' : 'mesh current') + '</span>');
    if (MODEL.check && !MODEL.dirty) chips.push('<span class="c ' + (MODEL.check.lanes.some(l => l.overlapCells) ? 'err' : 'ok') + '">' + (MODEL.check.lanes.some(l => l.overlapCells) ? 'slide binds' : 'slides clear') + '</span>');
    for (const w of MODEL.warnings) chips.push('<span class="c warn">' + esc(w) + '</span>');
    $('#sChips').innerHTML = chips.join('');
    if (MODEL.dims) {
      const v = {};
      for (const key of partKeys()) for (const s in MODEL.parts[key].meshes) v[s] = (v[s] || 0) + Orca3MF.signedVolume(MODEL.parts[key].meshes[s]);
      const grams = Object.keys(v).map(s => (s + ': ' + (v[s] / 1000 * Orca3MF.MATERIALS[ST.colour.slots[s - 1].type].density * ST.plate.count).toFixed(1) + ' g')).join('  ');
      const d = MODEL.dims;
      $('#readout').innerHTML = '<div>shell layers <span>' + Math.round((d.tf + d.hc) / ST.print.layer) + '</span></div><div>slide layers <span>' + Math.round(d.ts / ST.print.layer) + '</span></div><div>cover layers <span>' + Math.round((d.tc + d.pegL) / ST.print.layer) + '</span></div><div>copies <span>' + ST.plate.count + '</span></div><div>grid <span>' + d.W + ' x ' + d.H + '</span></div><div>parts <span>' + partKeys().length + '</span></div>' + (MODEL.check && MODEL.check.magnet && MODEL.check.magnet.pause ? '<div class="w">cover pause before layer <span>' + MODEL.check.magnet.pause + '</span></div>' : '') + '<div class="w">' + grams + '</div>';
    }
  };
  // ---- header buttons
  $('#bUndo').onclick = undo; $('#bRedo').onclick = redo;
  $('#bSave').onclick = () => download(new Blob([designJson()], { type: 'application/json' }), 'sash-design.json');
  const jsonIn = document.createElement('input'); jsonIn.type = 'file'; jsonIn.accept = '.json';
  $('#bOpen').onclick = () => jsonIn.click();
  jsonIn.onchange = () => { if (jsonIn.files[0]) jsonIn.files[0].text().then(loadDesign); jsonIn.value = ''; };
  $('#bGuide').onclick = () => $('#welcome').classList.remove('hide');
  $('#wBlank').onclick = () => { ST = blankState(); UI.refreshAll(); $('#welcome').classList.add('hide'); commit(); };
  $('#wExample').onclick = () => { ST = exampleState(); ST.sim.k = ST.lanes.map(startK); UI.refreshAll(); $('#welcome').classList.add('hide'); commit(); };
  $('#bBuild').onclick = () => { MODEL.dirty = true; runBuild(); };
  $('#b3mf').onclick = async () => download(await export3mf(), 'sash.3mf');
  $('#bStl').onclick = async () => download(await exportStlZip(), 'sash-stl.zip');
  $('#bCard').onclick = () => download(new Blob([printCardText(pkgConfig())], { type: 'text/plain' }), 'print-card.txt');
  $('#bPng').onclick = () => { facesPng().toBlob(b => download(b, 'sash-faces.png')); };
  UI.refreshAll = function () {
    fixLane(0); fixLane(1);
    if (!ST.sim.k || ST.sim.k.length < 2) ST.sim.k = [0, 0];
    $$('[data-p]').forEach(el => el._read && el._read());
    renderShapes(); renderLanes(); renderDetents(); renderMag(); renderSlots(); renderSurfaces(); renderStations(); renderLayers(); renderProps(); renderParts(); renderPose();
    $$('#bar [data-view]').forEach(x => x.classList.toggle('on', x.dataset.view === ST.ui.view));
    go(ST.ui.step);
  };
  UI.afterBuild = function () { readDetents(); UI.readCheck(); laneNotes(); renderLayers(); renderParts(); };
  UI.go = go; UI.add = add; UI.renderPose = renderPose;
  renderPresets();
  bindAll();
})();
// hook: refresh check panels after every build
(function () { const orig = UI.readCheck; UI.readCheck = function () { orig(); UI.afterBuild && UI.afterBuild !== UI.readCheck; }; })();

// ------------------------------------------------------------ boot: fonts first, or canvas fillText silently falls back
(async function boot() {
  try { await Promise.all(Object.values(FONTS).map(f => document.fonts.load('16px "' + f + '"'))); } catch (e) { console.warn('fonts', e); }
  UI.FE.cache.clear();
  UI.refreshAll();
  snapshot();
  runBuild();
  BENCH.ready = true;
})();
