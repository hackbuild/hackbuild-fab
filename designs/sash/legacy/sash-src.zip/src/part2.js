/* part2.js: SASH state, presets, geometry, glyph library, surface composer, kernel glue, fit checks.
   Depends on RasterMesh (rastermesh.js). Design frame = as read from the front, x right, y up, mm, origin at the shell centre.
   Every part's print grid is the mirror in X of its design grid (all art faces are bed faces). */
'use strict';
const BENCH = globalThis.BENCH = {};   // test hooks: BENCH.build(), BENCH.exportBytes(kind), BENCH.state(), BENCH.model(), BENCH.check()

// ------------------------------------------------------------ state
const FONTS = { marker: 'Permanent Marker', plex: 'IBM Plex Mono', elite: 'Special Elite', vt: 'VT323' };
const SHAPES_LIST = ['battery', 'rrect', 'stadium', 'tag', 'hex', 'ticket'];
const WIN_SHAPES = ['round', 'rrect', 'rect'];

function laneDefault(o) {
  return Object.assign({
    on: true, name: 'battery', N: 5, p: 6.5, startLeft: false,
    tab: { side: 'top', w: 6, h: 2.2, at: 'block' },
    gauge: { on: true, h: 4.5, mullion: 1.0, inset: 0.5, cells: [3, 3, 3, 3] },
    station: { on: true, h: 9, mullion: 0.9, inset: 0.5, win: 'rrect', offset: 0 },
    flex: { L: 9, t: 1.0, gap: 0.5, bump: 0.5, notch: 0.35 },
    stations: []
  }, o || {});
}
function blankState() {
  return {
    rev: 1,
    shell: { shape: 'battery', rc: 3, wall: 1.6, wallEnd: 3.2, midWall: 1.6, tf: 1.92, inlay: 1.2, nub: 2.5, keep: 0.5 },
    slide: { ts: 1.68, inlay: 0.72, margin: 0.6, rowGap: 0.6, tabT: 0.96 },
    fit: { cx: 0.25, cy: 0.2, cz: 0.2, tabSlack: 0.3, tabZ: 0.2 },
    cover: { tc: 1.2, inlay: 0.48, pegN: 2, pegD: 1.8, holeD: 1.9, pegL: 1.2 },
    magnets: { mode: 'off', n: 2, d: 6, t: 2, fit: 0.15 },
    lanes: [laneDefault(), laneDefault({ on: false, name: 'flag', N: 2, p: 10, tab: { side: 'bottom', w: 6, h: 2.2, at: 'block' }, gauge: { on: false, h: 4.5, mullion: 1.0, inset: 0.5, cells: [3] }, station: { on: true, h: 8, mullion: 0.9, inset: 0.5, win: 'rrect', offset: 0 } })],
    art: { shell: [], cover: [] },
    colour: { n: 4, roles: { shell: 1, slide: [2, 2], cover: 1 },
      slots: [{ color: '#1A1A1A', type: 'PETG', name: 'black' }, { color: '#FFFFFF', type: 'PETG', name: 'white' },
              { color: '#FE0386', type: 'PETG', name: 'pink' }, { color: '#F5F0E6', type: 'PETG', name: 'cream' }] },
    print: { layer: 0.24, minF: 0.6, boost: 0.15, gap: 0, despeckle: true, res: 10, auto: true, writeFilaments: true,
      pattern: 'Generic {TYPE} @FF C5P', printer: 'Flashforge Creator 5 Pro 0.4 nozzle', process: '0.24mm Standard @FF C5' },
    plate: { count: 1, bedW: 256, bedD: 256 },
    sim: { k: [0, 0] },
    ui: { surface: 'shell', station: 0, sel: null, step: 0, visited: [true, false, false, false, false], cam: 'iso', view: 'assembled',
      show: { shell: 'solid', slide0: 'solid', slide1: 'solid', cover: 'solid', magnets: 'solid' } }
  };
}
let uid = 10;
const newId = () => 'L' + (uid++);
function L(o) { return Object.assign({ id: newId(), dx: 0, dy: 0, rot: 0, slot: 1, cut: false, mute: false }, o); }
function strokeFor(size) { return Math.min(1.4, Math.max(0.8, Math.round(size * 0.12 * 20) / 20)); }
function face(name, size, slot, o) { return L(Object.assign({ kind: 'glyph', glyph: 'face', face: name, size, slot, stroke: strokeFor(size), head: 'none', eyes: 'auto', mouth: 'auto', brows: 'auto' }, o || {})); }
// geometry of a preset while it is still being built (laneGeom reads ST)
function withState(s, fn) { const prev = ST; ST = s; try { return fn(); } finally { ST = prev; } }
function icon(name, size, slot, o) { return L(Object.assign({ kind: 'glyph', glyph: name, size, slot, stroke: strokeFor(size) }, o || {})); }
function txt(text, font, size, slot, o) { return L(Object.assign({ kind: 'text', text, font, size, slot, slot2: slot, splitGap: 0, arc: 0, ls: 0 }, o || {})); }

// ------------------------------------------------------------ presets (each starts from blankState so nothing leaks)
const PRESETS = {
  battery: {
    name: 'social battery', note: '5 positions, 4 pink cells, a face that gets tired as it drains',
    make() {
      const s = blankState();
      s.lanes[0].stations = ['grin', 'smile', 'meh', 'tired', 'dead'].map(f => ({ layers: [face(f, 8, 1)] }));
      const c = withState(s, () => { const g = shellGeom().lanes[0]; return { x0: g.cells[0].x0, x1: g.cells[g.cells.length - 1].x1, y: g.win.cy }; });
      s.art.shell = [txt('SOCIAL', 'marker', 5.4, 2, { dx: -21, dy: 3.4 }), txt('BATTERY', 'marker', 5.4, 3, { dx: -21, dy: -3.6 }),
        txt('full', 'vt', 3.8, 2, { dx: c.x1 - 3.4, dy: c.y }), txt('empty', 'vt', 3.8, 2, { dx: c.x0 + 11.2, dy: c.y })];
      return s;
    }
  },
  flag: {
    name: 'battery + flag', note: 'the battery lane plus a two position HI or NO flag underneath',
    make() {
      const s = PRESETS.battery.make();
      s.lanes[1].on = true;
      s.lanes[1].stations = [{ layers: [txt('HI', 'vt', 6.5, 1)] }, { layers: [txt('NO', 'vt', 6.5, 1)] }];
      const w = withState(s, () => shellGeom().lanes.find(g => g.i === 1).win);
      s.art.shell.push(txt('say hi?', 'vt', 3.8, 2, { dx: w.cx + w.w / 2 + 7, dy: w.cy }));
      s.art.shell[0].dy = 5.8; s.art.shell[1].dy = -1;
      return s;
    }
  },
  availability: {
    name: 'availability', note: 'three positions, one big word in the window, no gauge',
    make() {
      const s = blankState();
      const l = s.lanes[0];
      Object.assign(l, { name: 'availability', N: 3, p: 12 });
      l.gauge.on = false; l.gauge.cells = [3, 3];
      Object.assign(l.station, { h: 10, win: 'rrect', mullion: 0.9 });
      l.tab.at = 'centre';
      l.stations = [{ layers: [txt('HI', 'vt', 7.5, 1)] }, { layers: [txt('ASK', 'vt', 7.5, 1)] }, { layers: [txt('NO', 'vt', 7.5, 1)] }];
      s.shell.shape = 'tag';
      s.art.shell = [txt('today', 'marker', 5.6, 3, { dx: -21, dy: 1 }), txt('i am', 'vt', 4.2, 2, { dx: -21, dy: -4 }), icon('wave', 7, 2, { dx: 13, dy: 0, rot: -10 })];
      return s;
    }
  },
  spoons: {
    name: 'spoons', note: 'six positions of spoons left: the cells count down and the number shows in the window',
    make() {
      const s = blankState();
      const l = s.lanes[0];
      Object.assign(l, { name: 'spoons', N: 6, p: 5.5 });
      l.gauge.cells = [3, 3, 3, 3, 3];
      Object.assign(l.station, { h: 9, win: 'rrect' });
      l.stations = [5, 4, 3, 2, 1, 0].map(n => ({ layers: [txt(String(n), 'vt', 7.5, 1, { dy: 0.2 })] }));
      s.shell.wall = 2.4;
      s.shell.shape = 'rrect';
      const w = withState(s, () => shellGeom().lanes[0].win);
      s.art.shell = [txt('SPOONS', 'marker', 5.2, 2, { dx: -18, dy: 2.8 }), txt('left', 'vt', 4, 3, { dx: -18, dy: -3.4 }), icon('spoon', 6.5, 2, { dx: w.cx + w.w / 2 + 4.2, dy: w.cy, rot: -20 })];
      return s;
    }
  },
  drinks: {
    name: 'drink tally', note: 'the tab starts left and each push lights a cell, the face gets wobbly, a water flag underneath',
    make() {
      const s = blankState();
      const l = s.lanes[0];
      Object.assign(l, { name: 'drinks', N: 6, p: 6.5, startLeft: true });
      l.gauge.cells = [3, 3, 3, 3, 3];
      Object.assign(l.station, { h: 9, win: 'rrect' });
      // the tab starts at the left and each push right lights a cell: station 5 is zero drinks, station 0 is five
      const faces = ['dead', 'dizzy', 'dizzy', 'smile', 'smile', 'grin'];
      l.stations = faces.map(f => ({ layers: [face(f, 8, 1)] }));
      const f = s.lanes[1];
      f.on = true; f.name = 'water'; f.N = 2; f.p = 10;
      f.stations = [{ layers: [icon('check', 6, 1)] }, { layers: [icon('cross', 6, 1)] }];
      s.shell.shape = 'rrect'; s.shell.rc = 4;
      const w = withState(s, () => shellGeom().lanes.find(g => g.i === 1).win);
      s.art.shell = [txt('DRINK', 'marker', 5.2, 3, { dx: -19, dy: 4.8 }), txt('TALLY', 'marker', 5.2, 2, { dx: -19, dy: -1.6 }), icon('drop', 5.5, 2, { dx: w.cx - w.w / 2 - 4.2, dy: w.cy }), txt('water?', 'vt', 3.8, 2, { dx: w.cx + w.w / 2 + 6.2, dy: w.cy })];
      return s;
    }
  }
};
function exampleState() { return PRESETS.battery.make(); }
let ST = blankState();

function getP(path) { return path.split('.').reduce((o, k) => o[k], ST); }
function setP(path, v) { const ks = path.split('.'); const o = ks.slice(0, -1).reduce((o, k) => o[k], ST); o[ks[ks.length - 1]] = v; }
const DESIGN_KEYS = ['shell', 'slide', 'fit', 'cover', 'magnets', 'lanes', 'art', 'colour', 'print', 'plate'];
function designSlice() { const o = {}; for (const k of DESIGN_KEYS) o[k] = ST[k]; return o; }

// ------------------------------------------------------------ history
const HIST = { stack: [], i: -1, max: 80, t: null };
function snapshot() {
  clearTimeout(HIST.t);
  HIST.t = setTimeout(() => {
    const s = JSON.stringify(designSlice());
    if (HIST.stack[HIST.i] === s) return;
    HIST.stack = HIST.stack.slice(0, HIST.i + 1);
    HIST.stack.push(s);
    if (HIST.stack.length > HIST.max) HIST.stack.shift();
    HIST.i = HIST.stack.length - 1;
  }, 450);
}
function restore(s) { Object.assign(ST, JSON.parse(s)); ST.ui.sel = null; UI.refreshAll(); commit(); }
function undo() { if (HIST.i > 0) { HIST.i--; restore(HIST.stack[HIST.i]); } }
function redo() { if (HIST.i < HIST.stack.length - 1) { HIST.i++; restore(HIST.stack[HIST.i]); } }

// ------------------------------------------------------------ layer snapping
function snapLayers(v) { const Lh = ST.print.layer; return Math.round(Math.max(Lh, Math.round(v / Lh) * Lh) * 1e4) / 1e4; }

// ------------------------------------------------------------ derived geometry (design frame)
// Slide local frame: (0,0) at the slide's left corner on the NOTCH edge, x along the slide, y toward the tab edge.
function tabSideOf(i) { return (ST.lanes[0].on && ST.lanes[1].on) ? (i === 0 ? 'top' : 'bottom') : ST.lanes[i].tab.side; }
function startK(l) { return l.startLeft ? Math.max(2, Math.round(l.N)) - 1 : 0; }
function laneGeom(i) {
  const Ln = ST.lanes[i], S = ST.slide, F = ST.fit;
  const N = Math.max(2, Math.round(Ln.N)), p = Ln.p;
  const stationOn = Ln.station.on || !Ln.gauge.on;          // at least one row
  const gaugeOn = Ln.gauge.on;
  const m = stationOn ? Math.max(0, Math.round(Ln.station.offset || 0)) : 0;
  const Ls = (N + m) * p;
  const flexZone = Ln.flex.t + Ln.flex.gap;
  const rows = [];
  if (gaugeOn) rows.push({ key: 'gauge', h: Ln.gauge.h });
  if (stationOn) rows.push({ key: 'station', h: Ln.station.h });
  const Ws = S.margin * 2 + flexZone + rows.reduce((a, r) => a + r.h, 0) + (rows.length - 1) * S.rowGap;
  const rowY = {};                                          // in the slide frame (y up = toward the tab edge)
  let y = Ws - S.margin;
  for (const r of rows) { rowY[r.key] = { y0: y - r.h, y1: y }; y -= r.h + S.rowGap; }
  const tabW = Ln.tab.w, tabTop = tabSideOf(i) === 'top';
  let xt = Ln.tab.at === 'end' ? Ls - tabW / 2 - 0.5 : Ln.tab.at === 'centre' ? Ls / 2 : (N - 1) * p;
  xt = Math.min(Ls - tabW / 2 - 0.5, Math.max(tabW / 2 + 0.5, xt));
  const Lf = Math.min(Ln.flex.L, Ls - 3);                   // beam length, root at the left end
  const xRoot = 1.0, xFree = xRoot + Lf;
  const rb = Math.min(0.7, (Ln.flex.t + Ln.flex.bump) / 2 - 0.02);
  const xBump = xFree - rb - 0.3;
  const Lc = Ls + (N - 1) * p + 2 * F.cx;                   // cavity length
  const Hc = Ws + 2 * F.cy;                                 // cavity height
  return { i, N, p, m, Ls, Ws, rows, rowY, flexZone, tabW, xt, tabTop, dir: tabTop ? 1 : -1, Lf, xRoot, xFree, rb, xBump, Lc, Hc, gaugeOn, stationOn };
}
// where lane i sits in the shell (design frame) and the slide's left corner at position k
function shellGeom() {
  const lanes = ST.lanes.map((l, i) => l.on ? laneGeom(i) : null).filter(Boolean);
  const F = ST.fit, Sh = ST.shell;
  const Lin = Math.max(...lanes.map(g => g.Lc));
  const Hin = lanes.reduce((a, g) => a + g.Hc, 0) + (lanes.length - 1) * Sh.midWall;
  let yTop = Hin / 2;
  for (const g of lanes) {
    g.cav = { x0: -g.Lc / 2, x1: g.Lc / 2, y0: yTop - g.Hc, y1: yTop };
    g.slideY = g.tabTop ? g.cav.y0 + F.cy : g.cav.y1 - F.cy;   // design y of the slide's notch edge (y=0 in the slide frame)
    g.dir = g.tabTop ? 1 : -1;                                 // slide frame y maps to design y = slideY + dir * y
    g.xLeft = k => g.cav.x0 + F.cx + (g.N - 1 - k) * g.p;
    g.Xg = g.xLeft(0);
    yTop -= g.Hc + Sh.midWall;
  }
  const wallEnd = requiredEndWall(Lin, Hin, lanes);
  const Wo = Lin + 2 * wallEnd, Ho = Hin + 2 * Sh.wall;
  const hc = snapLayers(ST.slide.ts + 2 * F.cz);
  const tf = snapLayers(Sh.tf);
  const coverT = coverThickness();
  const ts = snapLayers(ST.slide.ts);
  const tabT = Math.min(ts, snapLayers(ST.slide.tabT));
  let ribH = tabT < ts ? snapLayers(hc - F.cz - tabT - F.tabZ) : 0;
  if (ribH < ST.print.layer - 1e-6) ribH = 0;
  const keep = tabT < ts ? +(F.cz + ts - hc + ribH).toFixed(2) : 0;     // how far the slide body rises above the rib's underside
  // per lane: tab reach and slot
  for (const g of lanes) {
    const edgeY = g.tabTop ? Ho / 2 : -Ho / 2;
    const slideTabEdge = g.slideY + g.dir * g.Ws;
    g.tabReach = Math.abs(edgeY - slideTabEdge) + ST.lanes[g.i].tab.h;
    g.slot = { x0: g.xLeft(g.N - 1) + g.xt - g.tabW / 2 - F.tabSlack, x1: g.xLeft(0) + g.xt + g.tabW / 2 + F.tabSlack };
    // windows (design frame)
    g.cells = [];
    if (g.gaugeOn) {
      const r = g.rowY.gauge, Lz = ST.lanes[g.i];
      const ya = g.slideY + g.dir * r.y0, yb = g.slideY + g.dir * r.y1;
      for (let j = 0; j < g.N - 1; j++) g.cells.push({ x0: g.Xg + j * g.p + Lz.gauge.mullion / 2, x1: g.Xg + (j + 1) * g.p - Lz.gauge.mullion / 2, y0: Math.min(ya, yb) + Lz.gauge.inset, y1: Math.max(ya, yb) - Lz.gauge.inset });
    }
    if (g.stationOn) {
      const r = g.rowY.station, Lz = ST.lanes[g.i];
      const ya = g.slideY + g.dir * r.y0, yb = g.slideY + g.dir * r.y1;
      const w = g.p - Lz.station.mullion, h = Math.abs(yb - ya) - 2 * Lz.station.inset;
      g.win = { cx: g.Xg + (g.m + 0.5) * g.p, cy: (ya + yb) / 2, w, h, shape: Lz.station.win, d: Math.min(w, h) };
    }
  }
  const pegs = [];
  const pegY = ST.cover.pegN >= 2 ? Math.min(Hin / 4, Hin / 2 - 2.2) : 0;
  for (const sx of [-1, 1]) for (const sy of (ST.cover.pegN >= 2 ? [-1, 1] : [0])) pegs.push([sx * (Lin / 2 + wallEnd / 2), sy * pegY]);
  const mags = magnetPositions(Lin, Hin);
  return { lanes, Lin, Hin, wallEnd, Wo, Ho, hc, tf, coverT, pegs, mags, ts, tabT, ribH, keep, shellH: tf + hc, totalT: tf + hc + coverT };
}
function coverThickness() {
  const C = ST.cover, M = ST.magnets;
  let tc = C.tc;
  if (M.mode === 'glue') tc = Math.max(tc, M.t + 0.72);
  if (M.mode === 'sealed') tc = Math.max(tc, M.t + 1.44);
  return snapLayers(tc);
}
function magnetPositions(Lin, Hin) {
  const M = ST.magnets; if (M.mode === 'off') return [];
  const r = M.d / 2 + M.fit / 2;
  const mx = Math.max(0, Lin / 2 - r - 1.5), my = Math.max(0, Hin / 2 - r - 1.0);
  if (M.n <= 1) return [[0, 0]];
  if (M.n === 2) return [[-mx, 0], [mx, 0]];
  if (M.n === 3) return [[-mx, 0], [0, 0], [mx, 0]];
  return [[-mx * 0.8, -my], [mx * 0.8, -my], [-mx * 0.8, my], [mx * 0.8, my]];
}
// outline SDF (negative inside) for the shell in the design frame; extra x extent per side for the grid
function sdRRect(x, y, w, h, r) { const qx = Math.abs(x) - w / 2 + r, qy = Math.abs(y) - h / 2 + r; return Math.min(Math.max(qx, qy), 0) + Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) - r; }
function sdPoly(x, y, pts) {           // convex polygon, CCW: exact inside, near exact outside
  let d = -1e9;
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i], b = pts[(i + 1) % pts.length];
    const ex = b[0] - a[0], ey = b[1] - a[1], len = Math.hypot(ex, ey);
    const nx = ey / len, ny = -ex / len;                   // outward normal for CCW
    d = Math.max(d, nx * (x - a[0]) + ny * (y - a[1]));
  }
  return d;
}
function shellOutline(G) {
  const Sh = ST.shell, Wo = G.Wo, Ho = G.Ho, rc = Math.min(Sh.rc, Ho / 2 - 0.01, Wo / 2 - 0.01);
  const base = (x, y) => sdRRect(x, y, Wo, Ho, rc);
  let sdf = base, extL = 0, extR = 0;
  if (Sh.shape === 'battery') {
    const nw = Ho * 0.42, nh = Sh.nub;
    sdf = (x, y) => Math.min(base(x, y), sdRRect(x - (Wo / 2 + nh / 2 - 0.6), y, nh + 1.2, nw, Math.min(1, nw / 2 - 0.01)));
    extR = nh;
  } else if (Sh.shape === 'stadium') {
    const r = Ho / 2 - 0.01; sdf = (x, y) => sdRRect(x, y, Wo, Ho, r);
  } else if (Sh.shape === 'tag') {
    const pt = Ho * 0.45, pts = [[Wo / 2 - rc - 0.5, -Ho / 2], [Wo / 2 + pt, 0], [Wo / 2 - rc - 0.5, Ho / 2]];
    sdf = (x, y) => Math.min(base(x, y), sdPoly(x, y, pts));
    extR = pt;
  } else if (Sh.shape === 'hex') {
    const e = Ho / 2 * Math.tan(Math.PI / 6);
    const pts = [[-Wo / 2, -Ho / 2], [Wo / 2, -Ho / 2], [Wo / 2 + e, 0], [Wo / 2, Ho / 2], [-Wo / 2, Ho / 2], [-Wo / 2 - e, 0]];
    sdf = (x, y) => sdPoly(x, y, pts);
    extL = extR = e;
  } else if (Sh.shape === 'ticket') {
    const nr = 2.4, b2 = (x, y) => sdRRect(x, y, Wo, Ho, 0.8);
    sdf = (x, y) => { let d = b2(x, y); for (const sx of [-1, 1]) for (const sy of [-1, 1]) d = Math.max(d, -(Math.hypot(x - sx * Wo / 2, y - sy * Ho / 2) - nr)); return d; };
  }
  return { sdf, extL, extR };
}
// the shape's end walls must hold the cavity corners with 1 mm of solid; grow wallEnd until they do
function requiredEndWall(Lin, Hin, lanes) {
  const Sh = ST.shell;
  let we = Sh.wallEnd;
  for (let it = 0; it < 40; it++) {
    const G = { Wo: Lin + 2 * we, Ho: Hin + 2 * Sh.wall };
    const o = shellOutline(G);
    let ok = true;
    for (const g of lanes) for (const [x, y] of [[g.cav.x0, g.cav.y0], [g.cav.x1, g.cav.y0], [g.cav.x0, g.cav.y1], [g.cav.x1, g.cav.y1]]) if (o.sdf(x, y) > -1.0) ok = false;
    if (ok) return we;
    we += 0.5;
  }
  return we;
}

// ------------------------------------------------------------ glyph library (canvas, unit = mm, centred, y up handled by caller)
function facePart(c, s, sw, part, kind) {
  const ex = 0.20 * s, ey = 0.13 * s, er = Math.max(0.085 * s, 0.9 * sw);   // eye centre, eye dot radius
  const ar = Math.max(0.10 * s, 1.0 * sw);                                   // small arc radius (happy, closed, wink)
  c.lineWidth = sw; c.lineCap = 'round'; c.lineJoin = 'round';
  const dot = (x, y) => { c.beginPath(); c.arc(x, y, er, 0, Math.PI * 2); c.fill(); };
  if (part === 'eyes') {
    if (kind === 'dot') { dot(-ex, ey); dot(ex, ey); }
    else if (kind === 'happy') for (const x of [-ex, ex]) { c.beginPath(); c.arc(x, ey - ar * 0.5, ar, Math.PI * 0.15, Math.PI * 0.85); c.stroke(); }
    else if (kind === 'closed') for (const x of [-ex, ex]) { c.beginPath(); c.arc(x, ey + ar * 0.5, ar, Math.PI * 1.15, Math.PI * 1.85); c.stroke(); }
    else if (kind === 'x') { const h = Math.max(0.10 * s, 0.9 * sw); c.lineWidth = sw * 0.85; c.lineCap = 'butt'; for (const x of [-ex, ex]) { c.beginPath(); c.moveTo(x - h, ey - h); c.lineTo(x + h, ey + h); c.moveTo(x + h, ey - h); c.lineTo(x - h, ey + h); c.stroke(); } c.lineWidth = sw; c.lineCap = 'round'; }
    else if (kind === 'squint') { const h = Math.max(0.10 * s, 0.9 * sw); c.lineCap = 'butt'; for (const x of [-ex, ex]) { const d = x < 0 ? 1 : -1; c.beginPath(); c.moveTo(x - d * h * 0.7, ey + h * 0.7); c.lineTo(x + d * h * 0.5, ey); c.lineTo(x - d * h * 0.7, ey - h * 0.7); c.stroke(); } c.lineCap = 'round'; }
    else if (kind === 'tired') { const r = Math.max(0.10 * s, 1.0 * sw); for (const x of [-ex, ex]) { c.beginPath(); c.arc(x, ey, r, Math.PI, Math.PI * 2); c.closePath(); c.fill(); c.beginPath(); c.moveTo(x - r * 1.2, ey); c.lineTo(x + r * 1.2, ey); c.stroke(); } }
    else if (kind === 'big') { const r = Math.max(0.15 * s, 2 * sw); for (const x of [-ex, ex]) { c.beginPath(); c.arc(x, ey, r, 0, Math.PI * 2); c.stroke(); if (r - sw > 0.9 * sw) { c.beginPath(); c.arc(x, ey, Math.min(er, r - sw) * 0.8, 0, Math.PI * 2); c.fill(); } } }
    else if (kind === 'spiral') { const R = Math.max(0.15 * s, 2.2 * sw); for (const x of [-ex, ex]) { c.beginPath(); for (let t = 0; t <= Math.PI * 2.5; t += 0.15) { const r = 0.25 * sw + t / (Math.PI * 2.5) * R; const px = x + r * Math.cos(t), py = ey + r * Math.sin(t); t ? c.lineTo(px, py) : c.moveTo(px, py); } c.stroke(); } }
    else if (kind === 'wink') { dot(-ex, ey); c.beginPath(); c.arc(ex, ey - ar * 0.5, ar, Math.PI * 0.15, Math.PI * 0.85); c.stroke(); }
    else if (kind === 'heart') for (const x of [-ex, ex]) heartPath(c, x, ey + er * 0.2, Math.max(0.3 * s, 4 * sw)), c.fill();
    else if (kind === 'none') { }
  } else if (part === 'mouth') {
    const my = -0.17 * s, mw = Math.max(0.27 * s, 2.5 * sw);
    if (kind === 'smile') { c.beginPath(); c.arc(0, my + mw * 0.55, mw, Math.PI * 1.15, Math.PI * 1.85); c.stroke(); }
    else if (kind === 'grin') { c.beginPath(); c.arc(0, my + mw * 0.3, mw, Math.PI * 1.0, Math.PI * 2.0); c.closePath(); c.fill(); }
    else if (kind === 'flat') { c.beginPath(); c.moveTo(-mw * 0.8, my); c.lineTo(mw * 0.8, my); c.stroke(); }
    else if (kind === 'frown') { c.beginPath(); c.arc(0, my - mw * 0.75, mw, Math.PI * 0.15, Math.PI * 0.85); c.stroke(); }
    else if (kind === 'o') { c.beginPath(); c.arc(0, my, Math.max(mw * 0.45, 1.2 * sw), 0, Math.PI * 2); c.stroke(); }
    else if (kind === 'wavy') { c.beginPath(); for (let i = 0; i <= 16; i++) { const x = -mw * 0.8 + i / 16 * mw * 1.6; const y = my - 0.2 * sw + Math.sin(i / 16 * Math.PI * 3) * Math.max(mw * 0.16, 0.55 * sw); i ? c.lineTo(x, y) : c.moveTo(x, y); } c.stroke(); }
    else if (kind === 'tongue') { c.beginPath(); c.arc(0, my + mw * 0.3, mw, Math.PI * 1.0, Math.PI * 2.0); c.closePath(); c.fill(); c.beginPath(); c.arc(mw * 0.3, my - mw * 0.55, Math.max(mw * 0.32, 1.1 * sw), 0, Math.PI * 2); c.fill(); }
  } else if (part === 'brows') {
    const by = 0.31 * s, bw = Math.max(0.14 * s, 1.5 * sw);
    if (kind === 'angry') { c.beginPath(); c.moveTo(-ex - bw, by + bw * 0.5); c.lineTo(-ex + bw, by - bw * 0.3); c.moveTo(ex + bw, by + bw * 0.5); c.lineTo(ex - bw, by - bw * 0.3); c.stroke(); }
    else if (kind === 'sad') { c.beginPath(); c.moveTo(-ex - bw, by - bw * 0.3); c.lineTo(-ex + bw, by + bw * 0.4); c.moveTo(ex + bw, by - bw * 0.3); c.lineTo(ex - bw, by + bw * 0.4); c.stroke(); }
    else if (kind === 'flat') { c.beginPath(); c.moveTo(-ex - bw, by); c.lineTo(-ex + bw, by); c.moveTo(ex + bw, by); c.lineTo(ex - bw, by); c.stroke(); }
  }
}
function heartPath(c, x, y, s) { c.beginPath(); c.moveTo(x, y - s * 0.45); c.bezierCurveTo(x + s * 0.5, y - s * 0.05, x + s * 0.45, y + s * 0.45, x, y + s * 0.25); c.bezierCurveTo(x - s * 0.45, y + s * 0.45, x - s * 0.5, y - s * 0.05, x, y - s * 0.45); c.closePath(); }
const FACES = { grin: ['happy', 'grin', 'none'], smile: ['dot', 'smile', 'none'], meh: ['dot', 'flat', 'none'], frown: ['dot', 'frown', 'none'], tired: ['tired', 'flat', 'none'], dead: ['x', 'flat', 'none'],
  sleep: ['closed', 'o', 'none'], dizzy: ['squint', 'wavy', 'none'], spiral: ['spiral', 'wavy', 'none'], wink: ['wink', 'smile', 'none'], shock: ['big', 'o', 'none'], angry: ['dot', 'frown', 'angry'], sad: ['dot', 'frown', 'sad'], love: ['heart', 'smile', 'none'], cheeky: ['wink', 'tongue', 'none'] };
const EYES = ['dot', 'happy', 'closed', 'x', 'squint', 'tired', 'big', 'spiral', 'wink', 'heart', 'none'], MOUTHS = ['smile', 'grin', 'flat', 'frown', 'o', 'wavy', 'tongue', 'none'], BROWS = ['none', 'angry', 'sad', 'flat'];
let LOGO_PATHS = null;
function logoPaths() {
  if (LOGO_PATHS) return LOGO_PATHS;
  const ps = [...document.querySelectorAll('#hdr .mark path')];
  LOGO_PATHS = ps.map(p => ({ d: new Path2D(p.getAttribute('d')), t: (p.getAttribute('transform') || '').match(/[\d.]+/g).map(Number) }));
  return LOGO_PATHS;
}
const ICONS = {
  face(c, s, sw, Lr) {
    const f = FACES[Lr.face] || FACES.smile;
    const eyes = Lr.eyes && Lr.eyes !== 'auto' ? Lr.eyes : f[0], mouth = Lr.mouth && Lr.mouth !== 'auto' ? Lr.mouth : f[1], brows = Lr.brows && Lr.brows !== 'auto' ? Lr.brows : f[2];
    if (Lr.head === 'fill') {
      c.beginPath(); c.arc(0, 0, s / 2, 0, Math.PI * 2); c.fill();
      c.globalCompositeOperation = 'destination-out';
      facePart(c, s, sw, 'eyes', eyes); facePart(c, s, sw, 'mouth', mouth); facePart(c, s, sw, 'brows', brows);
      c.globalCompositeOperation = 'source-over';
      return;
    }
    if (Lr.head === 'ring') { c.lineWidth = sw; c.beginPath(); c.arc(0, 0, s / 2 - sw / 2, 0, Math.PI * 2); c.stroke(); }
    facePart(c, s, sw, 'eyes', eyes); facePart(c, s, sw, 'mouth', mouth); facePart(c, s, sw, 'brows', brows);
  },
  battery(c, s, sw, Lr) {
    const w = s, h = s * 0.55, f = Lr.fill == null ? 0.75 : Lr.fill;
    c.lineWidth = sw; c.strokeRect(-w / 2 + sw / 2, -h / 2 + sw / 2, w * 0.86 - sw, h - sw);
    c.fillRect(w / 2 - w * 0.14, -h * 0.2, w * 0.12, h * 0.4);
    const ix = -w / 2 + sw * 1.5, iw = (w * 0.86 - sw * 3) * f, ih = h - sw * 3;
    if (f > 0) c.fillRect(ix, -ih / 2, iw, ih);
  },
  bolt(c, s, sw) { const p = [[0.1, 0.5], [-0.3, -0.05], [-0.02, -0.05], [-0.1, -0.5], [0.3, 0.05], [0.02, 0.05]]; c.beginPath(); p.forEach(([x, y], i) => i ? c.lineTo(x * s, y * s) : c.moveTo(x * s, y * s)); c.closePath(); c.fill(); },
  spoon(c, s, sw) { c.lineWidth = sw * 1.3; c.beginPath(); c.ellipse(0, s * 0.28, s * 0.19, s * 0.22, 0, 0, Math.PI * 2); c.fill(); c.beginPath(); c.moveTo(0, s * 0.06); c.lineTo(0, -s * 0.48); c.stroke(); },
  pint(c, s, sw) { c.lineWidth = sw; const w = s * 0.55, h = s * 0.8; c.beginPath(); c.moveTo(-w / 2, h / 2); c.lineTo(-w / 2 + s * 0.05, -h / 2); c.lineTo(w / 2 - s * 0.05, -h / 2); c.lineTo(w / 2, h / 2); c.closePath(); c.stroke(); c.beginPath(); c.arc(w / 2 + s * 0.08, s * 0.05, s * 0.16, -Math.PI / 2, Math.PI / 2); c.stroke(); c.fillRect(-w / 2 + sw, -h / 2 + sw, w - 2 * sw, h * 0.32); },
  wine(c, s, sw) { c.lineWidth = sw; c.beginPath(); c.moveTo(-s * 0.3, s * 0.45); c.quadraticCurveTo(-s * 0.3, -s * 0.02, 0, -s * 0.05); c.quadraticCurveTo(s * 0.3, -s * 0.02, s * 0.3, s * 0.45); c.closePath(); c.fill(); c.beginPath(); c.moveTo(0, -s * 0.05); c.lineTo(0, -s * 0.4); c.moveTo(-s * 0.2, -s * 0.45); c.lineTo(s * 0.2, -s * 0.45); c.stroke(); },
  cocktail(c, s, sw) { c.lineWidth = sw; c.beginPath(); c.moveTo(-s * 0.42, s * 0.42); c.lineTo(s * 0.42, s * 0.42); c.lineTo(0, -s * 0.05); c.closePath(); c.fill(); c.beginPath(); c.moveTo(0, -s * 0.05); c.lineTo(0, -s * 0.4); c.moveTo(-s * 0.2, -s * 0.45); c.lineTo(s * 0.2, -s * 0.45); c.stroke(); },
  coffee(c, s, sw) { c.lineWidth = sw; c.beginPath(); c.moveTo(-s * 0.3, s * 0.1); c.lineTo(-s * 0.24, -s * 0.4); c.lineTo(s * 0.24, -s * 0.4); c.lineTo(s * 0.3, s * 0.1); c.closePath(); c.fill(); c.beginPath(); c.arc(s * 0.36, -s * 0.1, s * 0.14, -Math.PI / 2, Math.PI / 2); c.stroke(); for (const x of [-s * 0.12, s * 0.08]) { c.beginPath(); c.moveTo(x, s * 0.2); c.quadraticCurveTo(x + s * 0.08, s * 0.3, x, s * 0.42); c.stroke(); } },
  drop(c, s, sw) { c.beginPath(); c.moveTo(0, s * 0.5); c.bezierCurveTo(s * 0.32, s * 0.05, s * 0.32, -s * 0.2, 0, -s * 0.48); c.bezierCurveTo(-s * 0.32, -s * 0.2, -s * 0.32, s * 0.05, 0, s * 0.5); c.fill(); },
  hand(c, s, sw) {
    c.lineJoin = 'round'; const fw = s * 0.13;
    c.beginPath(); c.rect(-s * 0.24, -s * 0.45, s * 0.48, s * 0.5);
    [[-s * 0.24, 0.35], [-s * 0.08, 0.5], [s * 0.08, 0.45], [s * 0.24, 0.3]].forEach(([x, t]) => c.rect(x - fw / 2 - s * 0.005, 0, fw + s * 0.01, s * t));
    c.rect(-s * 0.42, -s * 0.3, s * 0.2, s * 0.13); c.fill();
    c.beginPath(); c.arc(-s * 0.36, -s * 0.24, s * 0.09, 0, Math.PI * 2); c.fill();
    c.beginPath(); c.arc(0, -s * 0.45, s * 0.24, 0, Math.PI); c.fill();
  },
  wave(c, s, sw) { c.save(); c.rotate(-0.35); ICONS.hand(c, s * 0.82, sw); c.restore(); c.lineWidth = sw; for (const r of [0.38, 0.5]) { c.beginPath(); c.arc(-s * 0.22, s * 0.1, s * r, Math.PI * 0.85, Math.PI * 1.25); c.stroke(); } },
  bubble(c, s, sw) { c.beginPath(); c.roundRect ? c.roundRect(-s * 0.48, -s * 0.28, s * 0.96, s * 0.62, s * 0.16) : c.rect(-s * 0.48, -s * 0.28, s * 0.96, s * 0.62); c.fill(); c.beginPath(); c.moveTo(-s * 0.3, -s * 0.24); c.lineTo(-s * 0.38, -s * 0.5); c.lineTo(-s * 0.1, -s * 0.26); c.closePath(); c.fill(); c.globalCompositeOperation = 'destination-out'; for (const x of [-0.24, 0, 0.24]) { c.beginPath(); c.arc(x * s, s * 0.03, s * 0.06, 0, Math.PI * 2); c.fill(); } c.globalCompositeOperation = 'source-over'; },
  heart(c, s, sw) { heartPath(c, 0, 0, s); c.fill(); },
  moon(c, s, sw) { c.beginPath(); c.arc(0, 0, s * 0.48, 0, Math.PI * 2); c.arc(s * 0.2, s * 0.08, s * 0.4, 0, Math.PI * 2, true); c.fill('evenodd'); },
  sun(c, s, sw) { c.lineWidth = sw; c.beginPath(); c.arc(0, 0, s * 0.22, 0, Math.PI * 2); c.fill(); for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; c.beginPath(); c.moveTo(Math.cos(a) * s * 0.32, Math.sin(a) * s * 0.32); c.lineTo(Math.cos(a) * s * 0.48, Math.sin(a) * s * 0.48); c.stroke(); } },
  check(c, s, sw) { c.lineWidth = sw * 1.4; c.lineCap = 'round'; c.lineJoin = 'round'; c.beginPath(); c.moveTo(-s * 0.42, s * 0.02); c.lineTo(-s * 0.12, -s * 0.32); c.lineTo(s * 0.45, s * 0.36); c.stroke(); },
  cross(c, s, sw) { c.lineWidth = sw * 1.4; c.lineCap = 'round'; c.beginPath(); c.moveTo(-s * 0.36, -s * 0.36); c.lineTo(s * 0.36, s * 0.36); c.moveTo(s * 0.36, -s * 0.36); c.lineTo(-s * 0.36, s * 0.36); c.stroke(); },
  skull(c, s, sw) { c.beginPath(); c.arc(0, s * 0.1, s * 0.38, 0, Math.PI * 2); c.rect(-s * 0.22, -s * 0.48, s * 0.44, s * 0.3); c.fill(); c.globalCompositeOperation = 'destination-out'; for (const x of [-0.15, 0.15]) { c.beginPath(); c.arc(x * s, s * 0.12, s * 0.1, 0, Math.PI * 2); c.fill(); } c.beginPath(); c.moveTo(0, -s * 0.05); c.lineTo(s * 0.06, -s * 0.16); c.lineTo(-s * 0.06, -s * 0.16); c.closePath(); c.fill(); for (const x of [-0.09, 0.03]) c.fillRect(x * s, -s * 0.48, s * 0.06, s * 0.14); c.globalCompositeOperation = 'source-over'; },
  star(c, s, sw) { c.beginPath(); for (let i = 0; i < 10; i++) { const r = i % 2 ? s * 0.2 : s * 0.5, a = Math.PI / 2 + i * Math.PI / 5; i ? c.lineTo(Math.cos(a) * r, Math.sin(a) * r) : c.moveTo(Math.cos(a) * r, Math.sin(a) * r); } c.closePath(); c.fill(); },
  arrow(c, s, sw) { c.lineWidth = sw * 1.3; c.lineCap = 'round'; c.lineJoin = 'round'; c.beginPath(); c.moveTo(-s * 0.45, 0); c.lineTo(s * 0.45, 0); c.moveTo(s * 0.15, s * 0.28); c.lineTo(s * 0.45, 0); c.lineTo(s * 0.15, -s * 0.28); c.stroke(); },
  tally(c, s, sw, Lr) { const n = Math.max(0, Math.round(Lr.n == null ? 3 : Lr.n)); c.lineWidth = sw; c.lineCap = 'round'; const g = s * 0.28; let x = -((Math.min(n, 4) - 1) * g) / 2; if (n === 0) { c.beginPath(); c.arc(0, 0, s * 0.3, 0, Math.PI * 2); c.stroke(); return; } for (let i = 0; i < Math.min(n, 4); i++) { c.beginPath(); c.moveTo(x + i * g, -s * 0.45); c.lineTo(x + i * g, s * 0.45); c.stroke(); } if (n >= 5) { c.beginPath(); c.moveTo(x - g * 0.6, -s * 0.35); c.lineTo(x + 3 * g + g * 0.6, s * 0.35); c.stroke(); } },
  zz(c, s, sw) { c.font = (s * 0.9) + 'px "Permanent Marker"'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.save(); c.scale(1, -1); c.fillText('zz', 0, 0); c.restore(); },
  logo(c, s, sw) { const ps = logoPaths(); c.save(); c.scale(s / 800, -s / 800); c.translate(-117 - 400, -103 - 400); for (const p of ps) { c.save(); c.translate(p.t[0], p.t[1]); c.fill(p.d); c.restore(); } c.restore(); }
};
const ICON_LIST = Object.keys(ICONS);

// ------------------------------------------------------------ surfaces
// surfaces: shell (front), cover (back, as read from behind), slide<i> (stations + cells)
function surfaceList() { const s = [{ key: 'shell', label: 'shell front' }]; ST.lanes.forEach((l, i) => { if (l.on) s.push({ key: 'slide' + i, label: 'slide ' + (i + 1) + ' (' + l.name + ')' }); }); s.push({ key: 'cover', label: 'cover back' }); return s; }
function surfaceLayers(key, station) {
  if (key === 'shell') return ST.art.shell;
  if (key === 'cover') return ST.art.cover;
  const i = +key.slice(5), l = ST.lanes[i];
  while (l.stations.length < Math.max(2, Math.round(l.N))) l.stations.push({ layers: [] });
  return l.stations[Math.min(station, l.stations.length - 1)].layers;
}
// where a layer's frame origin sits on its surface (design frame, mm)
function stationOrigin(key, k) {
  const i = +key.slice(5), g = laneGeom(i);
  const r = g.rowY.station || g.rowY.gauge;
  const dir = ST.lanes[i].tab.side === 'top' ? 1 : -1;
  return [(g.m + k + 0.5) * g.p - g.Ls / 2, dir * ((r.y0 + r.y1) / 2 - g.Ws / 2)];   // slide surface is centred on its nominal rect, design orientation
}

const IMG = new Map();
function imageFor(src) {
  if (IMG.has(src)) return IMG.get(src);
  const im = new Image(); im.onload = () => commit(); im.src = src; IMG.set(src, im);
  return im;
}
// paint one layer as an alpha mask on ctx (canvas covers extent mm, y up). origin = frame origin in surface coords.
function paintLayer(ctx, Lr, res, origin, part) {
  const W = ctx.canvas.width, H = ctx.canvas.height;
  ctx.save();
  ctx.translate(W / 2, H / 2);
  ctx.scale(res, -res);
  ctx.translate((origin ? origin[0] : 0) + (Lr.dx || 0), (origin ? origin[1] : 0) + (Lr.dy || 0));
  ctx.rotate((Lr.rot || 0) * Math.PI / 180);
  ctx.fillStyle = '#000'; ctx.strokeStyle = '#000';
  if (Lr.kind === 'shape') {
    const w = Lr.w, h = Lr.h, t = Lr.t;
    ctx.beginPath();
    if (Lr.shape === 'rect') ctx.rect(-w / 2, -h / 2, w, h);
    else if (Lr.shape === 'ellipse') ctx.ellipse(0, 0, w / 2, h / 2, 0, 0, Math.PI * 2);
    else if (Lr.shape === 'ring') { ctx.ellipse(0, 0, w / 2, h / 2, 0, 0, Math.PI * 2); ctx.ellipse(0, 0, Math.max(0.1, w / 2 - t), Math.max(0.1, h / 2 - t), 0, 0, Math.PI * 2, true); }
    else if (Lr.shape === 'frame') { ctx.rect(-w / 2, -h / 2, w, h); ctx.rect(-w / 2 + t, -h / 2 + t, w - 2 * t, h - 2 * t); }
    else if (Lr.shape === 'diamond') { ctx.moveTo(0, h / 2); ctx.lineTo(w / 2, 0); ctx.lineTo(0, -h / 2); ctx.lineTo(-w / 2, 0); ctx.closePath(); }
    else if (Lr.shape === 'chevrons') { for (let i = -1; i <= 1; i++) { const x = i * w * 0.4; ctx.moveTo(x - w * 0.16, -h / 2); ctx.lineTo(x, 0); ctx.lineTo(x - w * 0.16, h / 2); ctx.lineTo(x - w * 0.16 + t, h / 2); ctx.lineTo(x + t, 0); ctx.lineTo(x - w * 0.16 + t, -h / 2); ctx.closePath(); } }
    else if (Lr.shape === 'line') ctx.rect(-w / 2, -t / 2, w, t);
    else if (Lr.shape === 'ticks') { const n = Math.max(2, Math.round(h)); for (let i = 0; i < n; i++) ctx.rect(-w / 2 + i * (w - t) / (n - 1), -Lr.tickH / 2 || -1, t, Lr.tickH || 2); }
    ctx.fill('evenodd');
  } else if (Lr.kind === 'text') {
    ctx.scale(1, -1);
    ctx.font = (Lr.size * 1) + 'px "' + FONTS[Lr.font] + '"';
    ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
    const ls = Lr.ls || 0;
    const segs = String(Lr.text || '').split('|');
    const measure = s => { let w = 0; for (const ch of s) w += ctx.measureText(ch).width + ls; return w; };
    if (Lr.arc) {
      const r = Math.abs(Lr.arc), up = Lr.arc > 0, t = segs.join(''), total = measure(t);
      let a = -total / 2 / r;
      for (const ch of t) {
        const cw = ctx.measureText(ch).width + ls, mid = a + cw / 2 / r;
        ctx.save();
        if (up) { ctx.rotate(mid); ctx.translate(0, -r); } else { ctx.rotate(-mid); ctx.translate(0, r); }
        if (part === 0) ctx.fillText(ch, -cw / 2 + ls / 2, 0);
        ctx.restore();
        a += cw / r;
      }
    } else {
      const gap = segs.length > 1 ? (Lr.splitGap || 0) : 0, ws = segs.map(measure), total = ws.reduce((a, b) => a + b, 0) + gap * (segs.length - 1);
      let x = -total / 2;
      segs.forEach((s, i) => { if (i === part || (part === 0 && segs.length === 1)) { let xx = x; for (const ch of s) { ctx.fillText(ch, xx, 0); xx += ctx.measureText(ch).width + ls; } } x += ws[i] + gap; });
    }
  } else if (Lr.kind === 'glyph') {
    const fn = ICONS[Lr.glyph] || ICONS.face;
    fn(ctx, Lr.size, Math.max(0.3, Lr.stroke || 0.7), Lr);
  } else if (Lr.kind === 'image') {
    const im = imageFor(Lr.src);
    if (im.complete && im.naturalWidth) {
      const w = Lr.w, h = Lr.w * im.naturalHeight / im.naturalWidth;
      ctx.scale(1, -1); ctx.drawImage(im, -w / 2, -h / 2, w, h);
      ctx.restore(); ctx.save();
      const d = ctx.getImageData(0, 0, W, H), p = d.data, thr = (Lr.thr === undefined ? 0.5 : Lr.thr) * 255;
      for (let i = 0; i < p.length; i += 4) {
        const a = p[i + 3], lum = 0.299 * p[i] + 0.587 * p[i + 1] + 0.114 * p[i + 2];
        const on = a > 40 && (Lr.mode === 'silhouette' ? true : (Lr.invert ? lum > thr : lum < thr));
        p[i] = p[i + 1] = p[i + 2] = 0; p[i + 3] = on ? 255 : 0;
      }
      ctx.putImageData(d, 0, 0);
    }
  }
  ctx.restore();
}
// per layer hygiene on a binary mask (boost, min feature open, despeckle), then paint over region cells
function negLayer(Lr) { return Lr.kind === 'glyph' && ((Lr.glyph === 'face' && Lr.head === 'fill') || Lr.glyph === 'bubble' || Lr.glyph === 'skull' || Lr.glyph === 'moon'); }
function stampMask(labels, region, W, H, alpha, S, res, cutMask, neg) {
  const tmp = new Uint8Array(W * H);
  let raw = 0;
  for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) { const p = j * W + i, q = ((H - 1 - j) * W + i) * 4 + 3; if (alpha[q] > 127) { tmp[p] = 1; if (region[p]) raw++; } }
  if (!cutMask) {
    const boost = Math.round((ST.print.boost || 0) * res);
    const r = Math.max(0, Math.floor(ST.print.minF / 2 * res));
    const minCells = Math.round(0.35 * Math.PI * Math.pow(ST.print.minF / 2 * res, 2));
    if (neg) {
      // the visible features are the holes: boost the holes (erode the ink) and open the holes so nothing thinner than the nozzle is promised
      if (boost) RasterMesh.dilate(tmp, W, H, 0, boost, 1);
      RasterMesh.open(tmp, W, H, 0, r, 1);
    } else {
      if (boost) RasterMesh.dilate(tmp, W, H, 1, boost, 0);
      RasterMesh.open(tmp, W, H, 1, r, 0);
    }
    if (ST.print.despeckle) RasterMesh.despeckle(tmp, W, H, 1, minCells, 0);
  }
  let n = 0;
  for (let p = 0; p < W * H; p++) if (tmp[p] && region[p]) { if (cutMask) cutMask[p] = 1; else labels[p] = S; n++; }
  return [raw, n];
}
function addStat(stats, id, rk) { const s = stats[id] || (stats[id] = { raw: 0, kept: 0 }); s.raw += rk[0]; s.kept += rk[1]; }
function gridFor(extW, extH, res) {
  const W = Math.ceil(extW * res) + 2, H = Math.ceil(extH * res) + 2, px = 1 / res;
  return { W, H, px, x0: -W * px / 2, y0: -H * px / 2 };
}
function paintCanvas(W, H) { const cv = document.createElement('canvas'); cv.width = W; cv.height = H; return cv.getContext('2d', { willReadFrequently: true }); }

// ---- shell front: outline body, windows air, keep-out, art layers, cuts
function composeShell(res, G) {
  G = G || shellGeom();
  const o = shellOutline(G);
  const grid = gridFor(G.Wo + 2 * Math.max(o.extL, o.extR) + 2, G.Ho + 2, res);
  const { W, H, px, x0, y0 } = grid;
  const body = ST.colour.roles.shell, keep = ST.shell.keep;
  const base = new Uint8Array(W * H), region = new Uint8Array(W * H), winMask = new Uint8Array(W * H);
  const wins = [];
  for (const g of G.lanes) { for (const c of g.cells) wins.push({ kind: 'rect', ...c }); if (g.win) wins.push(g.win); }
  const inWin = (x, y, pad) => {
    for (const w of wins) {
      if (w.kind === 'rect') { if (x >= w.x0 - pad && x <= w.x1 + pad && y >= w.y0 - pad && y <= w.y1 + pad) return true; }
      else if (w.shape === 'round') { if (Math.hypot(x - w.cx, y - w.cy) <= w.d / 2 + pad) return true; }
      else if (w.shape === 'rrect') { if (sdRRect(x - w.cx, y - w.cy, w.w, w.h, Math.min(1.2, w.h / 2 - 0.05)) <= pad) return true; }
      else if (Math.abs(x - w.cx) <= w.w / 2 + pad && Math.abs(y - w.cy) <= w.h / 2 + pad) return true;
    }
    return false;
  };
  for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
    const x = x0 + (i + 0.5) * px, y = y0 + (j + 0.5) * px, p = j * W + i;
    const d = o.sdf(x, y);
    if (d > 0) continue;
    if (inWin(x, y, 0)) { winMask[p] = 1; continue; }
    base[p] = body;
    if (d <= -keep && !inWin(x, y, keep)) region[p] = 1;
  }
  const labels = base.slice(), cuts = new Uint8Array(W * H);
  const ctx = paintCanvas(W, H);
  const stats = {};
  for (const Lr of ST.art.shell) {
    if (Lr.mute) continue;
    const parts = (Lr.kind === 'text' && String(Lr.text).includes('|') && !Lr.arc) ? 2 : 1;
    for (let part = 0; part < parts; part++) {
      ctx.clearRect(0, 0, W, H); paintLayer(ctx, Lr, res, [0, 0], part);
      const S = part === 0 ? Lr.slot : (Lr.slot2 || Lr.slot);
      addStat(stats, Lr.id, stampMask(labels, region, W, H, ctx.getImageData(0, 0, W, H).data, S, res, Lr.cut ? cuts : null, negLayer(Lr)));
    }
  }
  colourGap(labels, W, H, body, res);
  for (let p = 0; p < W * H; p++) if (cuts[p]) { labels[p] = 0; base[p] = 0; }
  return Object.assign(grid, { labels, base, region, cuts, winMask, body, stats, G, sdf: o.sdf });
}
function colourGap(labels, W, H, body, res) {
  const g = Math.round(ST.print.gap * res); if (!g) return;
  for (let S = 1; S <= ST.colour.n; S++) if (S !== body) RasterMesh.gap(labels, W, H, S, g, body);
}
// ---- slide i: nominal rect + tab + bump, beam slot air; stations and cells as art
function composeSlide(i, res, G) {
  G = G || shellGeom();
  const g = G.lanes.find(l => l.i === i); if (!g) return null;
  const Ln = ST.lanes[i], Fx = Ln.flex, body = ST.colour.roles.slide[i], cellBlank = ST.colour.roles.cover;
  const extY = g.Ws + 2 * Math.max(g.tabReach, Fx.bump) + 2, extX = g.Ls + 2;
  const grid = gridFor(extX, extY, res);
  const { W, H, px, x0, y0 } = grid;
  // surface coords are the DESIGN orientation centred on the nominal rect. slide frame: xs = x + Ls/2, ys = dir * y + Ws/2 (y toward the tab)
  const dir = g.dir;
  const base = new Uint8Array(W * H), region = new Uint8Array(W * H), meta = new Uint8Array(W * H);   // meta 1 body, 2 beam/bump
  const Ls = g.Ls, Ws = g.Ws, t = Fx.t, gap = Fx.gap;
  const artRects = [];
  if (g.gaugeOn) artRects.push({ x0: 0, x1: Ls, y0: g.rowY.gauge.y0, y1: g.rowY.gauge.y1 });
  if (g.stationOn) artRects.push({ x0: g.m * g.p, x1: Ls, y0: g.rowY.station.y0, y1: g.rowY.station.y1 });
  for (let j = 0; j < H; j++) for (let i2 = 0; i2 < W; i2++) {
    const xs = x0 + (i2 + 0.5) * px + Ls / 2, ys = dir * (y0 + (j + 0.5) * px) + Ws / 2;   // slide frame
    const p = j * W + i2;
    let solid = false, beam = false;
    if (xs >= 0 && xs <= Ls && ys >= 0 && ys <= Ws) {
      solid = true;
      // beam slot: air from the root to past the free end
      if (xs >= g.xRoot && xs <= g.xFree + gap && ys >= t && ys <= t + gap) solid = false;
      if (xs >= g.xFree && xs <= g.xFree + gap && ys >= 0 && ys <= t + gap) solid = false;
      if (solid && xs >= g.xRoot && xs < g.xFree && ys < t) beam = true;
    }
    // tab: from the tab edge outward
    let tab = false;
    if (Math.abs(xs - g.xt) <= g.tabW / 2 && ys > Ws && ys <= Ws + g.tabReach) { solid = true; tab = true; }
    // bump: disc below the notch edge
    if (!solid && ys < 0 && Math.hypot(xs - g.xBump, ys - (g.rb - Fx.bump)) <= g.rb) { solid = true; beam = true; }
    if (ys >= 0 && ys < t && Math.hypot(xs - g.xBump, ys - (g.rb - Fx.bump)) <= g.rb && xs > g.xRoot) { solid = true; beam = true; }
    if (!solid) continue;
    base[p] = body; meta[p] = tab ? 3 : beam ? 2 : 1;
    for (const r of artRects) if (xs >= r.x0 + 0.3 && xs <= r.x1 - 0.3 && ys >= r.y0 + 0.3 && ys <= r.y1 - 0.3) region[p] = 1;
  }
  const labels = base.slice();
  // cells: colour block cells 0..N-2 then a blank cell in the cover colour so a drained window never shows white
  if (g.gaugeOn) {
    const r = g.rowY.gauge;
    for (let j = 0; j < H; j++) for (let i2 = 0; i2 < W; i2++) {
      const xs = x0 + (i2 + 0.5) * px + Ls / 2, ys = dir * (y0 + (j + 0.5) * px) + Ws / 2, p = j * W + i2;
      if (!region[p] || ys < r.y0 + 0.3 || ys > r.y1 - 0.3) continue;
      const c = Math.floor(xs / g.p);
      if (c < g.N - 1) labels[p] = Ln.gauge.cells[c] || 3; else labels[p] = cellBlank;
    }
  }
  const ctx = paintCanvas(W, H);
  const stats = {};
  if (g.stationOn) {
    for (let k = 0; k < g.N; k++) {
      const layers = surfaceLayers('slide' + i, k), org = stationOrigin('slide' + i, k);
      const r = g.rowY.station;
      // clip region to this station's rect so art never leaks into the neighbour
      const sx0 = (g.m + k) * g.p + 0.3 - Ls / 2, sx1 = (g.m + k + 1) * g.p - 0.3 - Ls / 2;
      const regK = new Uint8Array(W * H);
      for (let j = 0; j < H; j++) for (let i2 = 0; i2 < W; i2++) { const p = j * W + i2; if (!region[p]) continue; const xs = x0 + (i2 + 0.5) * px, ys = dir * (y0 + (j + 0.5) * px) + Ws / 2; if (xs >= sx0 && xs <= sx1 && ys >= r.y0 + 0.3 && ys <= r.y1 - 0.3) regK[p] = 1; }
      for (const Lr of layers) {
        if (Lr.mute) continue;
        const parts = (Lr.kind === 'text' && String(Lr.text).includes('|') && !Lr.arc) ? 2 : 1;
        for (let part = 0; part < parts; part++) {
          ctx.clearRect(0, 0, W, H); paintLayer(ctx, Lr, res, org, part);
          const S = part === 0 ? Lr.slot : (Lr.slot2 || Lr.slot);
          addStat(stats, Lr.id, stampMask(labels, regK, W, H, ctx.getImageData(0, 0, W, H).data, S, res, null, negLayer(Lr)));
        }
      }
    }
  }
  colourGap(labels, W, H, body, res);
  return Object.assign(grid, { labels, base, region, meta, body, stats, g, G });
}
// ---- cover: same outline as the shell, as read from behind (design x mirrored relative to the front), pockets and pegs handled in build
function composeCover(res, G) {
  G = G || shellGeom();
  const o = shellOutline(G);
  const grid = gridFor(G.Wo + 2 * Math.max(o.extL, o.extR) + 2, G.Ho + 2, res);
  const { W, H, px, x0, y0 } = grid;
  // as read from behind: the nub / point ends up on the left. sdf(-x, y)
  const body = ST.colour.roles.cover, keep = 0.8;
  const base = new Uint8Array(W * H), region = new Uint8Array(W * H);
  const holes = [...G.pegs.map(([x, y]) => ({ x: -x, y, r: ST.cover.pegD / 2 + 0.8 })), ...G.mags.map(([x, y]) => ({ x: -x, y, r: ST.magnets.d / 2 + ST.magnets.fit / 2 + 0.8 }))];
  for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
    const x = x0 + (i + 0.5) * px, y = y0 + (j + 0.5) * px, p = j * W + i;
    const d = o.sdf(-x, y);
    if (d > 0) continue;
    base[p] = body;
    let ok = d <= -keep;
    for (const h of holes) if (ok && Math.hypot(x - h.x, y - h.y) < h.r) ok = false;
    if (ok) region[p] = 1;
  }
  const labels = base.slice(), cuts = new Uint8Array(W * H);
  const ctx = paintCanvas(W, H);
  const stats = {};
  for (const Lr of ST.art.cover) {
    if (Lr.mute) continue;
    const parts = (Lr.kind === 'text' && String(Lr.text).includes('|') && !Lr.arc) ? 2 : 1;
    for (let part = 0; part < parts; part++) {
      ctx.clearRect(0, 0, W, H); paintLayer(ctx, Lr, res, [0, 0], part);
      const S = part === 0 ? Lr.slot : (Lr.slot2 || Lr.slot);
      addStat(stats, Lr.id, stampMask(labels, region, W, H, ctx.getImageData(0, 0, W, H).data, S, res, Lr.cut ? cuts : null, negLayer(Lr)));
    }
  }
  colourGap(labels, W, H, body, res);
  for (let p = 0; p < W * H; p++) if (cuts[p]) { labels[p] = 0; base[p] = 0; }
  return Object.assign(grid, { labels, base, region, cuts, body, stats, G, sdf: (x, y) => o.sdf(-x, y) });
}
function composeSurface(key, res, G) {
  if (key === 'shell') return composeShell(res, G);
  if (key === 'cover') return composeCover(res, G);
  return composeSlide(+key.slice(5), res, G);
}

// ------------------------------------------------------------ build: grids -> slabs -> meshes per part
const MODEL = { parts: null, dirty: true, building: false, queued: false, ms: 0, tris: 0, warnings: [], grids: null, G: null };
function wallGrid(G, front) {         // shell wall slab, design frame, same grid as the front
  const { W, H, px, x0, y0 } = front;
  const F = ST.fit, body = front.body;
  const out = new Uint8Array(W * H);
  const notches = [];
  for (const g of G.lanes) {
    const Fx = ST.lanes[g.i].flex, rn = g.rb + 0.1;
    const railY = g.slideY - g.dir * F.cy;                 // cavity edge on the notch side
    for (let k = 0; k < g.N; k++) notches.push({ x: g.xLeft(k) + g.xBump, y: railY + g.dir * (rn - Fx.notch), r: rn });
  }
  for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
    const x = x0 + (i + 0.5) * px, y = y0 + (j + 0.5) * px, p = j * W + i;
    if (!front.base[p] && !front.winMask[p]) continue;            // outside the outline (windows are inside)
    let solid = true;
    for (const g of G.lanes) {
      const c = g.cav;
      if (x >= c.x0 && x <= c.x1 && y >= c.y0 && y <= c.y1) solid = false;
      // tab slot: through the wall over the tab travel
      if (solid && x >= g.slot.x0 && x <= g.slot.x1 && (g.tabTop ? y > c.y1 : y < c.y0)) solid = false;
    }
    if (solid) for (const n of notches) if (Math.hypot(x - n.x, y - n.y) <= n.r) { solid = false; break; }
    if (solid) for (const [hx, hy] of G.pegs) if (Math.hypot(x - hx, y - hy) <= ST.cover.holeD / 2) { solid = false; break; }
    if (solid) out[p] = body;
  }
  return out;
}
function coverBand(G, cov, zMid, tc) { // cover print grid for a z band: pockets and peg slab
  const { W, H, px, x0, y0 } = cov;
  const M = ST.magnets, C = ST.cover;
  let out;
  if (zMid > tc) {                       // above the plate: pegs, and the keeper rib that fills the top of each tab slot
    out = new Uint8Array(W * H);
    const ribs = [];
    if (zMid < tc + G.ribH) for (const g of G.lanes) {
      const c = g.cav, w = ST.shell.wall;
      ribs.push({ x0: -g.slot.x1 + 0.15, x1: -g.slot.x0 - 0.15, y0: g.tabTop ? c.y1 + 0.15 : c.y0 - w + 0.15, y1: g.tabTop ? c.y1 + w - 0.15 : c.y0 - 0.15 });
    }
    for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
      const x = x0 + (i + 0.5) * px, y = y0 + (j + 0.5) * px;
      let on = false;
      if (zMid < tc + C.pegL) for (const [hx, hy] of G.pegs) if (Math.hypot(x + hx, y - hy) <= C.pegD / 2) { on = true; break; }
      if (!on) for (const r of ribs) if (x >= r.x0 && x <= r.x1 && y >= r.y0 && y <= r.y1 && cov.sdf(x, y) <= -0.4) { on = true; break; }
      if (on) out[j * W + i] = cov.body;
    }
    return out;
  }
  out = (zMid < ST.cover.inlay ? cov.labels : cov.base).slice();
  let pocket = false;
  if (M.mode === 'glue') pocket = zMid < M.t;
  if (M.mode === 'sealed') pocket = zMid > 0.72 && zMid < 0.72 + M.t;
  if (pocket) {
    const r = M.d / 2 + M.fit / 2;
    for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
      const x = x0 + (i + 0.5) * px, y = y0 + (j + 0.5) * px;
      for (const [mx, my] of G.mags) if (Math.hypot(x + mx, y - my) <= r) { out[j * W + i] = 0; break; }
    }
  }
  return out;
}
function stripTab(labels, meta) { const out = labels.slice(); for (let p = 0; p < out.length; p++) if (meta[p] === 3) out[p] = 0; return out; }
function meshPart(grid, slabs) {
  const vol = RasterMesh.volume(grid.W, grid.H, grid.px, grid.x0, grid.y0);
  for (const s of slabs) vol.addSlab(RasterMesh.mirrorX(s.labels, grid.W, grid.H), s.z0, s.z1);
  const fixed = vol.fixPinches();
  const meshes = vol.mesh();
  let tris = 0; for (const s in meshes) tris += meshes[s].tris;
  return { meshes, tris, fixed, z: slabs[slabs.length - 1].z1, grid };
}
function build() {
  const t0 = performance.now();
  const res = ST.print.res, warnings = [];
  const G = shellGeom();
  const Sh = ST.shell, Sl = ST.slide, C = ST.cover, M = ST.magnets;
  // shell
  const front = composeShell(res, G);
  const tf = G.tf; let inl = snapLayers(Sh.inlay);
  if (inl >= tf - 0.48) { inl = snapLayers(Math.max(ST.print.layer, tf - 0.72)); warnings.push('shell inlay clamped to leave a 0.72 core'); }
  const wall = wallGrid(G, front);
  const shellPart = meshPart(front, [{ labels: front.labels, z0: 0, z1: inl }, { labels: front.base, z0: inl, z1: tf }, { labels: wall, z0: tf, z1: tf + G.hc }]);
  shellPart.dims = { tf, inl, hc: G.hc };
  // slides
  const ts = snapLayers(Sl.ts); let inls = snapLayers(Sl.inlay);
  if (inls >= ts - 0.48) { inls = snapLayers(Math.max(ST.print.layer, ts - 0.72)); warnings.push('slide inlay clamped to leave a 0.72 core'); }
  const slides = {};
  const slideGrids = {};
  for (const g of G.lanes) {
    const sg = composeSlide(g.i, res, G);
    slideGrids['slide' + g.i] = sg;
    const noTab = new Uint8Array(sg.W * sg.H); for (let p = 0; p < noTab.length; p++) noTab[p] = sg.meta[p] === 3 ? 0 : sg.base[p];
    const zsl = [...new Set([0, inls, G.tabT, ts])].filter(z => z <= ts + 1e-6).sort((a, b) => a - b), sl = [];
    for (let q = 0; q < zsl.length - 1; q++) if (zsl[q + 1] - zsl[q] > 1e-6) { const zm = (zsl[q] + zsl[q + 1]) / 2; sl.push({ labels: zm < inls ? (zm > G.tabT ? stripTab(sg.labels, sg.meta) : sg.labels) : (zm > G.tabT ? noTab : sg.base), z0: zsl[q], z1: zsl[q + 1] }); }
    slides['slide' + g.i] = meshPart(sg, sl);
    slides['slide' + g.i].dims = { ts, inl: inls, tabT: G.tabT };
  }
  // cover
  const cov = composeCover(res, G);
  const tc = G.coverT; let inlc = snapLayers(C.inlay);
  if (inlc >= tc - 0.48) { inlc = snapLayers(Math.max(ST.print.layer, tc - 0.72)); if (ST.art.cover.length) warnings.push('cover inlay clamped'); }
  const zs = new Set([0, inlc, tc]);
  if (M.mode === 'glue') zs.add(snapLayers(M.t));
  if (M.mode === 'sealed') { zs.add(0.72); zs.add(snapLayers(0.72 + M.t)); }
  const pegL = snapLayers(C.pegL);
  zs.add(tc + pegL); if (G.ribH) zs.add(tc + G.ribH);
  const zTop = tc + Math.max(pegL, G.ribH);
  const zl = [...zs].filter(z => z <= zTop + 1e-6).sort((a, b) => a - b);
  const slabs = [];
  for (let i = 0; i < zl.length - 1; i++) if (zl[i + 1] - zl[i] > 1e-6) slabs.push({ labels: coverBand(G, cov, (zl[i] + zl[i + 1]) / 2, tc), z0: zl[i], z1: zl[i + 1] });
  const coverPart = meshPart(cov, slabs);
  coverPart.dims = { tc, inl: inlc, pegL, ribH: G.ribH };
  const parts = Object.assign({ shell: shellPart }, slides, { cover: coverPart });
  let tris = 0, fixed = 0; for (const k in parts) { tris += parts[k].tris; fixed += parts[k].fixed; }
  if (fixed > front.W * front.H * 0.002) warnings.push(fixed + ' pinch cells healed, art at the resolution limit');
  for (const g of G.lanes) {
    if (Math.abs(g.slot.x1) > G.Wo / 2 - Sh.rc - 0.5 || Math.abs(g.slot.x0) > G.Wo / 2 - Sh.rc - 0.5) warnings.push('lane ' + (g.i + 1) + ' tab slot runs into the corner radius');
    if (ST.lanes[g.i].tab.h < 1.2) warnings.push('lane ' + (g.i + 1) + ' tab barely stands proud');
    const rn = g.rb + 0.1, Fx = ST.lanes[g.i].flex;
    if (Fx.bump - ST.fit.cy > Fx.notch + 0.05) warnings.push('lane ' + (g.i + 1) + ' bump taller than clearance plus notch, it will never fully seat');
    if (g.win && g.win.d < 2) warnings.push('lane ' + (g.i + 1) + ' station window under 2 mm');
    void rn;
  }
  for (const [hx, hy] of G.pegs) if (front.sdf(hx + (hx > 0 ? 1 : -1) * (C.holeD / 2 + 0.5), hy) > 0) warnings.push('peg hole breaks the outline, raise end wall');
  MODEL.parts = parts; MODEL.tris = tris; MODEL.ms = performance.now() - t0; MODEL.warnings = warnings; MODEL.dirty = false;
  MODEL.G = G; MODEL.grids = Object.assign({ shell: front, cover: cov, wall }, slideGrids);
  MODEL.dims = { Wo: G.Wo, Ho: G.Ho, T: tf + G.hc + tc, tf, hc: G.hc, tc, ts, inl, inls, inlc, pegL, ribH: G.ribH, tabT: G.tabT, keep: G.keep, res, W: front.W, H: front.H };
  MODEL.check = runCheck(G, front, wall, slideGrids);
  for (const w of MODEL.check.warnings) warnings.push(w);
  if (MODEL.ms > 2500) warnings.push('build over 2.5 s, drop resolution');
  return parts;
}
// ------------------------------------------------------------ fit check: numbers plus a raster overlap sweep of each slide through its cavity
function runCheck(G, front, wall, slideGrids) {
  const F = ST.fit, out = { lanes: [], warnings: [] };
  const E = 2000;                                                  // PETG modulus, N/mm2
  for (const g of G.lanes) {
    const Fx = ST.lanes[g.i].flex, sg = slideGrids['slide' + g.i];
    const I = ST.slide.ts * Math.pow(Fx.t, 3) / 12;
    const defl = Math.max(0, Fx.bump - F.cy);
    const Fn = 3 * E * I * defl / Math.pow(g.Lf, 3);
    const mu = 0.3, push = Fn * (Math.SQRT1_2 + mu * Math.SQRT1_2) / (Math.SQRT1_2 - mu * Math.SQRT1_2);
    const strain = 3 * defl * Fx.t / (2 * g.Lf * g.Lf) * 100;
    const slack = Fx.notch - defl;
    // raster sweep: slide body cells (meta 1) vs wall cells, in the design frame, at half steps
    let worst = 0, worstK = 0;
    const { W, H, px, x0, y0 } = front;
    for (let k = 0; k <= g.N - 1; k += 0.5) {
      const ox = g.xLeft(k) + g.Ls / 2, oy = g.slideY + g.dir * g.Ws / 2;     // slide surface centre in design coords
      let n = 0;
      for (let j = 0; j < sg.H; j++) for (let i = 0; i < sg.W; i++) {
        const p = j * sg.W + i; if (sg.meta[p] !== 1) continue;
        const xs = sg.x0 + (i + 0.5) * sg.px, ys = sg.y0 + (j + 0.5) * sg.px;
        const x = ox + xs, y = oy + ys;
        const ii = Math.floor((x - x0) / px), jj = Math.floor((y - y0) / px);
        if (ii < 0 || jj < 0 || ii >= W || jj >= H) continue;
        if (wall[jj * W + ii]) n++;
      }
      if (n > worst) { worst = n; worstK = k; }
    }
    const lane = { i: g.i, name: ST.lanes[g.i].name, N: g.N, p: g.p, Ls: +g.Ls.toFixed(2), Ws: +g.Ws.toFixed(2), Lc: +g.Lc.toFixed(2), Hc: +g.Hc.toFixed(2), travel: +((g.N - 1) * g.p).toFixed(2),
      defl: +defl.toFixed(2), Fn: +Fn.toFixed(2), push: +push.toFixed(2), strain: +strain.toFixed(2), slack: +slack.toFixed(2), beam: g.Lf, overlapCells: worst, overlapK: worstK,
      win: g.win ? +g.win.d.toFixed(2) : null, winMargin: g.win ? +((g.p - g.win.w) / 2).toFixed(2) : null, tabReach: +g.tabReach.toFixed(2), zClear: +(G.hc - ST.slide.ts).toFixed(2) };
    if (worst) out.warnings.push('lane ' + (g.i + 1) + ': slide hits the shell at position ' + worstK + ' (' + worst + ' cells)');
    if (slack < 0) out.warnings.push('lane ' + (g.i + 1) + ': notch shallower than the bump deflection');
    if (strain > 3) out.warnings.push('lane ' + (g.i + 1) + ': flexure strain over 3 percent');
    if (push < 0.15) out.warnings.push('lane ' + (g.i + 1) + ': click under 0.15 N, thicken the beam');
    out.lanes.push(lane);
  }
  const shrinkHole = 0.15, growPeg = 0.1;
  out.peg = { d: ST.cover.pegD, hole: ST.cover.holeD, nominal: +(ST.cover.pegD - ST.cover.holeD).toFixed(2), printed: +((ST.cover.pegD + growPeg) - (ST.cover.holeD - shrinkHole)).toFixed(2) };
  if (out.peg.printed < 0) out.warnings.push('peg looser than the hole after FDM shrink, drop hole d');
  if (out.peg.printed > 0.35) out.warnings.push('peg press fit over 0.35 mm, it will split the wall');
  out.magnet = ST.magnets.mode === 'off' ? null : { pocket: +(ST.magnets.d + ST.magnets.fit).toFixed(2), floor: ST.magnets.mode === 'glue' ? +(G.coverT - ST.magnets.t).toFixed(2) : 0.72, pause: ST.magnets.mode === 'sealed' ? Math.round((0.72 + ST.magnets.t) / ST.print.layer) : null };
  out.keeper = { tabT: G.tabT, ribH: G.ribH, keep: G.keep, tabZ: +(G.hc - G.ribH - F.cz - G.tabT).toFixed(2) };
  if (!G.ribH) out.warnings.push('no keeper rib: the slide can lift out through the tab slot. thin the tab or thicken the walls');
  else if (G.keep < 0.24) out.warnings.push('keeper overlap under 0.24 mm, thin the tab');
  out.midWall = G.lanes.length > 1 ? +(ST.shell.midWall - 2 * Math.max(...G.lanes.map(g => ST.lanes[g.i].flex.notch))).toFixed(2) : null;
  if (out.midWall !== null && out.midWall < 0.8) out.warnings.push('mid wall under 0.8 mm at the notches');
  return out;
}

// COMMIT MODEL
let buildTimer = null;
function touch(delay) { UI.preview(delay); }
function commit() {
  MODEL.dirty = true; ST.rev++; snapshot(); UI.preview(0);
  if (!ST.print.auto) { UI.status(); return; }
  clearTimeout(buildTimer);
  buildTimer = setTimeout(runBuild, 320);
}
function runBuild() {
  if (MODEL.building) { MODEL.queued = true; return; }
  MODEL.building = true; UI.status('building');
  setTimeout(() => {
    try { build(); VIEW.update(); } catch (e) { console.error(e); MODEL.warnings = ['build failed: ' + e.message]; }
    MODEL.building = false; UI.status(); UI.preview(0); UI.readCheck && UI.readCheck();
    if (MODEL.queued) { MODEL.queued = false; runBuild(); }
  }, 0);
}
function ensureMesh() { if (MODEL.dirty || !MODEL.parts) { build(); VIEW.update(); UI.status(); } return MODEL.parts; }
BENCH.build = () => { build(); VIEW.update(); UI.status(); return MODEL; };
BENCH.state = () => ST;
BENCH.model = () => MODEL;
BENCH.check = () => MODEL.check;
BENCH.presets = PRESETS;
BENCH.geom = shellGeom;
