#!/usr/bin/env python3
"""smoke.py: headless Chromium harness for sash.html. python3 smoke.py out/sash.html out/smoke [--quick]"""
import base64, json, os, sys, time

def main(argv):
    html, out = argv[0], argv[1]
    quick = "--quick" in argv
    os.makedirs(out, exist_ok=True)
    from playwright.sync_api import sync_playwright
    url = "file://" + os.path.abspath(html)
    errors, fails = [], []
    settled = "BENCH.model().parts && !BENCH.model().dirty && !BENCH.model().building"
    with sync_playwright() as p:
        b = p.chromium.launch(args=["--use-gl=swiftshader", "--enable-webgl", "--ignore-gpu-blocklist"])
        pg = b.new_page(viewport={"width": 1280, "height": 800})
        pg.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
        pg.on("pageerror", lambda e: errors.append(str(e)))
        pg.goto(url)
        pg.wait_for_function("typeof BENCH !== 'undefined' && BENCH.ready", timeout=60000)
        pg.click("#wExample")
        pg.wait_for_function(settled, timeout=120000)
        m = pg.evaluate("({tris:BENCH.model().tris, ms:BENCH.model().ms, warnings:BENCH.model().warnings, dims:BENCH.model().dims, parts:Object.keys(BENCH.model().parts), check:BENCH.check()})")
        print("example build:", json.dumps(m, indent=1)[:3000])
        if m["warnings"]:
            fails.append("warnings on the worked example: %s" % m["warnings"])
        for l in m["check"]["lanes"]:
            if l["overlapCells"]:
                fails.append("lane %d slide binds: %s cells at %s" % (l["i"], l["overlapCells"], l["overlapK"]))
        pg.screenshot(path=os.path.join(out, "example-step0.png"))
        if quick:
            print("console errors:", errors)
            b.close(); return
        for s in range(5):
            pg.click('#steps button[data-step="%d"]' % s); time.sleep(0.4)
            pg.screenshot(path=os.path.join(out, "step-%d.png" % s))
        # views and part chips
        pg.click('#steps button[data-step="2"]')
        for v in ["exploded", "plate", "assembled"]:
            pg.click('#bar [data-view="%s"]' % v); time.sleep(0.4)
            pg.screenshot(path=os.path.join(out, "view-%s.png" % v))
        # ghost the shell
        pg.evaluate("document.querySelector('#partChips button').click()"); time.sleep(0.3)
        pg.screenshot(path=os.path.join(out, "view-ghost.png"))
        pg.evaluate("document.querySelector('#partChips button').click(); document.querySelector('#partChips button').click()")
        # pose scrub
        pg.evaluate("(() => { const r = document.querySelector('#poseChips input'); r.value = 3; r.dispatchEvent(new Event('input')); r.dispatchEvent(new Event('change')); })()"); time.sleep(0.3)
        pg.click('#steps button[data-step="0"]'); time.sleep(0.4)
        pg.screenshot(path=os.path.join(out, "pose-3.png"))
        # art step: select a slide surface, station 2, add a glyph, drive handles
        pg.click('#steps button[data-step="1"]'); time.sleep(0.3)
        pg.evaluate("document.querySelectorAll('#surfaces .chip')[1].click()"); time.sleep(0.3)
        pg.evaluate("document.querySelectorAll('#stationRow .chip')[1].click()"); time.sleep(0.3)
        pg.click('[data-add="glyph"]'); pg.wait_for_function(settled, timeout=120000)
        n0 = pg.evaluate("BENCH.state().lanes[0].stations[1].layers.length")
        h = pg.evaluate("UI.FE.handles && {corners: UI.FE.handles.corners, dot: UI.FE.handles.dot, centre: UI.FE.handles.centre}")
        print("handles:", h)
        if not h:
            fails.append("no handles for the added glyph")
        else:
            r = pg.evaluate("(() => { const r = document.querySelector('#face canvas').getBoundingClientRect(); return [r.left, r.top]; })()")
            # move
            cx, cy = h["centre"]
            pg.mouse.move(r[0] + cx, r[1] + cy); pg.mouse.down(); pg.mouse.move(r[0] + cx + 30, r[1] + cy - 20, steps=5); pg.mouse.up()
            pg.wait_for_function(settled, timeout=120000)
            L = pg.evaluate("BENCH.state().lanes[0].stations[1].layers.slice(-1)[0]")
            print("after move:", L["dx"], L["dy"])
            if L["dx"] == 0 and L["dy"] == 0:
                fails.append("drag did not move the layer")
            # rotate
            h = pg.evaluate("({dot: UI.FE.handles.dot, corners: UI.FE.handles.corners, centre: UI.FE.handles.centre})")
            dx, dy = h["dot"]
            pg.mouse.move(r[0] + dx, r[1] + dy); pg.mouse.down(); pg.mouse.move(r[0] + dx + 40, r[1] + dy + 40, steps=5); pg.mouse.up()
            pg.wait_for_function(settled, timeout=120000)
            L = pg.evaluate("BENCH.state().lanes[0].stations[1].layers.slice(-1)[0]")
            print("after rotate:", L["rot"])
            if L["rot"] == 0:
                fails.append("rotate handle did nothing")
            # scale
            h = pg.evaluate("({corners: UI.FE.handles.corners, centre: UI.FE.handles.centre})")
            c = h["corners"][2]; ce = h["centre"]
            pg.mouse.move(r[0] + c[0], r[1] + c[1]); pg.mouse.down(); pg.mouse.move(r[0] + c[0] + (c[0] - ce[0]) * 0.5, r[1] + c[1] + (c[1] - ce[1]) * 0.5, steps=5); pg.mouse.up()
            pg.wait_for_function(settled, timeout=120000)
            L2 = pg.evaluate("BENCH.state().lanes[0].stations[1].layers.slice(-1)[0]")
            print("after scale:", L2["size"])
            if L2["size"] == L["size"]:
                fails.append("scale handle did nothing")
            pg.screenshot(path=os.path.join(out, "art-handles.png"))
            pg.keyboard.press("Delete"); pg.wait_for_function(settled, timeout=120000)
            n1 = pg.evaluate("BENCH.state().lanes[0].stations[1].layers.length")
            if n1 != n0 - 1:
                fails.append("delete key did not remove the layer")
        # undo restores it
        pg.click("#bUndo"); pg.wait_for_function(settled, timeout=120000)
        # exports
        pg.click('#steps button[data-step="4"]')
        for kind, name in [("3mf", "example.3mf"), ("stl", "example-stl.zip"), ("json", "example.json"), ("card", "example-card.txt")]:
            t = time.time()
            b64 = pg.evaluate("BENCH.exportBytes('%s')" % kind)
            open(os.path.join(out, name), "wb").write(base64.b64decode(b64))
            print("exported", name, len(b64) * 3 // 4, "bytes in %.1f s" % (time.time() - t))
            if time.time() - t > 25:
                fails.append("%s export took over 25 s" % kind)
        txt = open(os.path.join(out, "example.json")).read()
        pg.evaluate("t => loadDesign(t)", txt)
        pg.wait_for_function(settled, timeout=120000)
        same = json.loads(txt)["state"] == json.loads(pg.evaluate("designJson()"))["state"]
        print("design json round trip identical:", same)
        if not same:
            a = json.loads(txt)["state"]; b2 = json.loads(pg.evaluate("designJson()"))["state"]
            for k in a:
                if a[k] != b2.get(k): print("  differs:", k)
            fails.append("design JSON does not round trip")
        # every preset builds clean and exports
        for k in pg.evaluate("Object.keys(BENCH.presets)"):
            pg.evaluate("k => { ST = BENCH.presets[k].make(); ST.sim.k = ST.lanes.map(startK); UI.refreshAll(); commit(); }", k)
            pg.wait_for_function(settled, timeout=120000)
            m = pg.evaluate("({warnings:BENCH.model().warnings, dims:BENCH.model().dims, tris:BENCH.model().tris, lanes:BENCH.check().lanes.map(l => [l.overlapCells, l.push, l.slack]), peg:BENCH.check().peg})")
            print("preset", k, json.dumps(m))
            if m["warnings"]:
                fails.append("preset %s warnings: %s" % (k, m["warnings"]))
            for l in m["lanes"]:
                if l[0]:
                    fails.append("preset %s slide binds" % k)
            pg.click('#steps button[data-step="0"]'); time.sleep(0.4)
            pg.screenshot(path=os.path.join(out, "preset-%s.png" % k))
            b64 = pg.evaluate("BENCH.exportBytes('3mf')")
            open(os.path.join(out, "preset-%s.3mf" % k), "wb").write(base64.b64decode(b64))
            b64 = pg.evaluate("BENCH.exportBytes('json')")
            open(os.path.join(out, "preset-%s.json" % k), "wb").write(base64.b64decode(b64))
        # blank start
        pg.click("#bGuide"); pg.click("#wBlank")
        pg.wait_for_function(settled, timeout=120000)
        print("blank parts:", pg.evaluate("Object.keys(BENCH.model().parts)"), "warnings", pg.evaluate("BENCH.model().warnings"))
        pg.screenshot(path=os.path.join(out, "blank.png"))
        for w in [390, 768, 1280]:
            pg.set_viewport_size({"width": w, "height": 800}); time.sleep(0.4)
            sw = pg.evaluate("document.documentElement.scrollWidth")
            print("width", w, "scrollWidth", sw)
            pg.screenshot(path=os.path.join(out, "width-%d.png" % w))
            if sw > w:
                fails.append("horizontal overflow at %d" % w)
        b.close()
    print("console errors:", errors[:20])
    if errors:
        fails.append("console errors")
    if fails:
        print("FAILURES"); [print("  -", f) for f in fails]; sys.exit(1)
    print("smoke passed")

if __name__ == "__main__":
    main(sys.argv[1:])
