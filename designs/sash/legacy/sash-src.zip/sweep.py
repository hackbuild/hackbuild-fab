import os, sys, json, base64, time
from playwright.sync_api import sync_playwright
url = "file://" + os.path.abspath("out/sash.html")
settled = "BENCH.model().parts && !BENCH.model().dirty && !BENCH.model().building"
cases = [
  ("N2 p4", "ST.lanes[0].N=2; ST.lanes[0].p=4; ST.lanes[0].stations=[{layers:[]},{layers:[]}]; ST.lanes[0].gauge.cells=[3];"),
  ("N12 p4", "ST.lanes[0].N=12; ST.lanes[0].p=4; ST.lanes[0].stations=Array.from({length:12},()=>({layers:[]})); ST.lanes[0].gauge.cells=Array(11).fill(3);"),
  ("N8 p16", "ST.lanes[0].N=8; ST.lanes[0].p=16; ST.lanes[0].stations=Array.from({length:8},()=>({layers:[]})); ST.lanes[0].gauge.cells=Array(7).fill(3);"),
  ("hex glue mags", "ST.shell.shape='hex'; ST.magnets.mode='glue'; ST.magnets.n=3;"),
  ("ticket sealed mags 4", "ST.shell.shape='ticket'; ST.magnets.mode='sealed'; ST.magnets.n=4; ST.magnets.d=8; ST.magnets.t=3;"),
  ("stadium tab bottom", "ST.shell.shape='stadium'; ST.lanes[0].tab.side='bottom';"),
  ("two lanes both top", "ST.lanes[1].on=true; ST.lanes[1].tab.side='top'; ST.lanes[1].N=4; ST.lanes[1].p=7; ST.lanes[1].stations=Array.from({length:4},()=>({layers:[]})); ST.lanes[1].gauge.on=true; ST.lanes[1].gauge.cells=[3,3,3];"),
  ("tight fits thin walls", "ST.fit.cx=0.1; ST.fit.cy=0.1; ST.fit.cz=0.1; ST.shell.wall=1.2; ST.shell.wallEnd=2.4; ST.shell.midWall=1.2;"),
  ("loose fits thick", "ST.fit.cx=1; ST.fit.cy=0.6; ST.fit.cz=0.6; ST.shell.wall=8; ST.shell.tf=4; ST.slide.ts=3; ST.cover.tc=4; ST.cover.pegL=2.4;"),
  ("big flex", "ST.lanes[0].flex={L:20,t:2,gap:1.2,bump:1,notch:1};"),
  ("tiny flex", "ST.lanes[0].flex={L:4,t:0.6,gap:0.35,bump:0.2,notch:0.1};"),
  ("no gauge no station", "ST.lanes[0].gauge.on=false; ST.lanes[0].station.on=false;"),
  ("station rect offset 3", "ST.lanes[0].station.win='rect'; ST.lanes[0].station.offset=3; ST.lanes[0].station.h=16;"),
  ("tab centre wide", "ST.lanes[0].tab.at='centre'; ST.lanes[0].tab.w=12; ST.lanes[0].tab.h=5;"),
  ("2 colours", "ST.colour.n=2; ST.colour.roles={shell:1,slide:[2,2],cover:2};"),
  ("res 14 layer 0.12", "ST.print.res=14; ST.print.layer=0.12;"),
  ("res 6 6 copies", "ST.print.res=6; ST.plate.count=6;"),
  ("rc 8 nub 6", "ST.shell.rc=8; ST.shell.nub=6; ST.shell.shape='battery';"),
  ("full thickness tab", "ST.slide.tabT=1.68;"),
  ("thin tab thick slide", "ST.slide.tabT=0.48; ST.slide.ts=2.4;"),
  ("count up lane", "ST.lanes[0].startLeft=true;"),
]
fails = []
with sync_playwright() as p:
    b = p.chromium.launch(args=["--use-gl=swiftshader", "--enable-webgl", "--ignore-gpu-blocklist"])
    pg = b.new_page(viewport={"width": 1280, "height": 800})
    errs = []
    pg.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto(url)
    pg.wait_for_function("typeof BENCH !== 'undefined' && BENCH.ready", timeout=60000)
    for name, js in cases:
        pg.evaluate("ST = BENCH.presets.battery.make(); ST.sim.k=[0,0]; " + js + " UI.refreshAll(); commit();")
        try:
            pg.wait_for_function(settled, timeout=180000)
        except Exception as e:
            fails.append(name + ": did not settle"); print(name, "TIMEOUT"); continue
        m = pg.evaluate("({keeper:BENCH.check().keeper, warnings:BENCH.model().warnings, dims:[BENCH.model().dims.Wo, BENCH.model().dims.Ho, BENCH.model().dims.T], tris:BENCH.model().tris, ms:Math.round(BENCH.model().ms), lanes:BENCH.check().lanes.map(l=>({ov:l.overlapCells, k:l.overlapK, push:l.push, strain:l.strain, slack:l.slack, z:l.zClear, win:l.win, mid:null})), peg:BENCH.check().peg.printed, mag:BENCH.check().magnet, mid:BENCH.check().midWall, cw:BENCH.check().warnings, fits:plateLayout().fits})")
        print(name, json.dumps(m))
        if any(l["ov"] for l in m["lanes"]): fails.append(name + ": slide binds")
        if errs: fails.append(name + ": console " + str(errs)); errs.clear()
        if name in ("ticket sealed mags 4", "two lanes both top", "N12 p4", "res 6 6 copies", "thin tab thick slide"):
            b64 = pg.evaluate("BENCH.exportBytes('3mf')")
            open("out/smoke/sweep-%s.3mf" % name.replace(" ", "_"), "wb").write(base64.b64decode(b64))
    b.close()
print("FAILS", fails)
