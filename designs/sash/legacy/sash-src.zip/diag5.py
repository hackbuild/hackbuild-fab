import os, sys, base64
from playwright.sync_api import sync_playwright
url = "file://" + os.path.abspath("out/sash.html")
settled = "BENCH.model().parts && !BENCH.model().dirty && !BENCH.model().building"
preset = sys.argv[1] if len(sys.argv) > 1 else 'battery'
with sync_playwright() as p:
    b = p.chromium.launch(args=["--use-gl=swiftshader", "--enable-webgl", "--ignore-gpu-blocklist"])
    pg = b.new_page(viewport={"width": 1280, "height": 800})
    errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto(url)
    pg.wait_for_function("typeof BENCH !== 'undefined' && BENCH.ready", timeout=60000)
    pg.evaluate("ST = BENCH.presets.%s.make(); ST.sim.k = ST.lanes.map(startK); UI.refreshAll(); commit();" % preset)
    pg.wait_for_function(settled, timeout=120000)
    d = pg.evaluate(r"""(() => {
      const G = MODEL.G, gs = MODEL.grids, f = gs.shell, S = 6;   // 6 screen px per raster cell = 60 px/mm
      const tiles = [];
      for (const g of G.lanes) for (let k = 0; k < g.N; k++) {
        const ks = ST.sim.k.slice(); ks[g.i] = k;
        const labels = compositeLabels(f, gs, G, ks);
        const cv = gridToCanvas(f, labels);
        const w = g.win; if (!w) continue;
        const pad = 1.5, x0 = Math.floor((w.cx - w.w / 2 - pad - f.x0) / f.px), x1 = Math.ceil((w.cx + w.w / 2 + pad - f.x0) / f.px);
        const yTop = w.cy + w.h / 2 + pad, yBot = w.cy - w.h / 2 - pad;
        const j0 = Math.floor((f.y0 + f.H * f.px - yTop) / f.px), j1 = Math.ceil((f.y0 + f.H * f.px - yBot) / f.px);
        tiles.push({ cv, x0, j0, w: x1 - x0, h: j1 - j0, label: 'lane ' + (g.i + 1) + ' pos ' + (g.i === 0 ? (ST.lanes[0].startLeft ? g.N - k : k + 1) : k + 1) });
      }
      const tw = Math.max(...tiles.map(t => t.w)) * S + 10, th = Math.max(...tiles.map(t => t.h)) * S + 24;
      const cols = Math.min(6, tiles.length), rows = Math.ceil(tiles.length / cols);
      const out = document.createElement('canvas'); out.width = cols * tw; out.height = rows * th;
      const c = out.getContext('2d'); c.fillStyle = '#333'; c.fillRect(0, 0, out.width, out.height); c.imageSmoothingEnabled = false;
      tiles.forEach((t, i) => { const X = (i % cols) * tw + 5, Y = Math.floor(i / cols) * th + 20; c.drawImage(t.cv, t.x0, t.j0, t.w, t.h, X, Y, t.w * S, t.h * S); c.fillStyle = '#a6e22e'; c.font = '13px monospace'; c.fillText(t.label, X, Y - 6); });
      return out.toDataURL('image/png');
    })()""")
    open("out/windows-%s.png" % preset, "wb").write(base64.b64decode(d.split(",")[1]))
    print("errors", errs)
    b.close()
