#!/usr/bin/env python3
"""Assemble boss.html: shell + inlined three, jszip, earcut, polygon-clipping, fonts, print-forge orca3mf.js, and the BOSS sources."""
import os, base64, glob, re
HERE = os.path.dirname(os.path.abspath(__file__))
NM = os.path.join(HERE, 'node_modules')
FONTS = [("Permanent Marker", "permanent-marker", "files/permanent-marker-latin-400-normal.woff2", 400),
         ("Special Elite", "special-elite", "files/special-elite-latin-400-normal.woff2", 400),
         ("VT323", "vt323", "files/vt323-latin-400-normal.woff2", 400),
         ("IBM Plex Mono", "ibm-plex-mono", "files/ibm-plex-mono-latin-400-normal.woff2", 400),
         ("IBM Plex Mono", "ibm-plex-mono", "files/ibm-plex-mono-latin-600-normal.woff2", 600)]
def rd(p): return open(p, encoding='utf-8').read()
shell = rd(os.path.join(HERE, 'src/shell.html'))
fontcss = ''
for fam, pkg, f, w in FONTS:
    p = os.path.join(NM, '@fontsource', pkg, f)
    if os.path.exists(p):
        b = base64.b64encode(open(p, 'rb').read()).decode()
        fontcss += "@font-face{font-family:'%s';font-style:normal;font-weight:%d;font-display:swap;src:url(data:font/woff2;base64,%s) format('woff2')}\n" % (fam, w, b)
shell = shell.replace('<style>', '<style>\n' + fontcss, 1)
libs = [os.path.join(NM, 'three/build/three.min.js'), os.path.join(NM, 'jszip/dist/jszip.min.js'), os.path.join(NM, 'earcut/dist/earcut.min.js'), os.path.join(NM, 'polygon-clipping/dist/polygon-clipping.umd.min.js')]
srcs = ['/mnt/skills/plugins/print-forge/assets/orca3mf.js'] + [os.path.join(HERE, 'src', n) for n in ['kernel.js', 'boss.js', 'parts.js', 'export.js', 'sim.js', 'app1.js', 'app2.js', 'app3.js']]
out = [shell]
for p in libs:
    code = rd(p)
    if not code.endswith('\n'): code += '\n'
    out.append('<script>/* %s */\n%s</script>\n' % (os.path.basename(p), code.replace('</script', '<\\/script')))
for p in srcs:
    out.append('<script>/* %s */\n%s\n</script>\n' % (os.path.basename(p), rd(p).replace('</script', '<\\/script')))
out.append('</body>\n</html>\n')
html = ''.join(out)
for bad in ['\u2014', '\u2013']:
    assert bad not in html, 'dash found'
open(os.path.join(HERE, 'out/boss.html'), 'w', encoding='utf-8').write(html)
print('boss.html', len(html) // 1024, 'KB')
