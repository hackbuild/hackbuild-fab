# OGEE R16 — mechanical 4x4 pin display

A 4x4 dot display with no electronics in the pixel: sixteen pins, each raised by
turning one row knob and one column knob together, latched mechanically, and
cleared by pulling one tab. Mechanically multiplexed, so 8 inputs address 16
pixels.

## Start here

| open this | for |
|---|---|
| `ogee16p.html` | the printed build, assembled and working. Knobs or servos |
| `ogee16m.html` | the minimal frame, so you can see the mechanism |
| `ogee16c.html` | an elastic skin over the face, real cloth physics |
| `ogee16-plate.html` | every printed part on the bed, with STL export |
| `ogee16-sheets.html` | every sheet part nested, with DXF export |

All five run from `file://`, no server, no network.

## What to make

The build you asked about last is MIXED: internals printed, body lasercut from
3mm. Both halves know about each other, and the slots that take a printed part are
sized differently from the ones that take a cut one.

| | |
|---|---|
| `ogee16-print-stl.zip` | every printed part |
| `ogee16-minimal-stl.zip` | the minimal frame, if you print the body too |
| `ogee16-cut.zip` | the lasercut sheets |
| `ogee16-pivot-pin.stl` | one pivot pin |
| `ogee16-pivot-pins-x32.stl` | all 32 on a plate |

## The notes

| | |
|---|---|
| `PRINT.md` | the printed build: fits, orientation, plates, assembly |
| `SHEETS.md` | the cut parts and the mixed-build fits |
| `MIN.md` | the minimal frame and how it was derived |
| `PINS.md` | the pivot pin, and the three versions that did not work |
| `CLOTH.md` | the cloth solver |
| `TIMES.md` | print time and how the fits land in PETG |
| `BUILD.md` | the original lasercut build |

## What checks it

`ogee16-source.zip` has all of it: the parametric OpenSCAD, the kinematics, the
page builders, and the checks. Run any of them.

| | |
|---|---|
| `audit.py` / `audit_print.py` | mesh interference, every pose, both builds |
| `fits.py` | every mating pair against what the printer actually makes |
| `check_drive.py` | that the cranks actually move the bars |
| `check_sweep.py` | swept volumes, because rotating parts need them |
| `check_servos.py` | servo envelopes against the frame and every part |
| `check_frame.py` | frame dimensions measured off the meshes |
| `orient.py` | scores all 24 print poses per part |
| `skeleton.py` | derives the minimal frame, checks it stays one piece |
| `printtime.py` | print time from real path lengths |
| `shots*.py` | drives each page in real chromium and asserts on it |

Current state: both audits 0 clashes, all fits in band, drive chains exact to
1e-15, no swept collisions, all nine servos clear, frame checks pass, all four
pages self-check clean in chromium.
