# OGEE R16-P with an elastic skin

`ogee16c.html`. The same machine, the same kinematics, with a stretched sheet over
the face. Write a pixel and the cap under it rises 7.6mm and tents the cloth.

## It is a real solve, not a drawn bump

| | |
|---|---|
| particles | 4225 (65 x 65, adjustable 33 to 97) |
| springs | 24702 |
| integration | Verlet, two substeps per frame at 1/120 |
| constraints | position based, relaxed 6 passes per step |
| pinned | all four edges, which is what a retaining frame does |

Three spring families, and you need all three. Structural springs on the
4-neighbours alone shear into nothing. Shear springs on the diagonals alone fold.
Bend springs, two apart, are what stop the sheet creasing to a point over a cap
instead of curving off it.

Position based constraints rather than explicit spring forces, because a sheet
stiff enough to look like fabric under tension will explode under explicit
integration at any sane timestep. Relaxation is unconditionally stable, and the
pass count is the stiffness knob.

## The colliders

The face plate is a floor at z 97. Each cap is a disc of radius 8 whose top rises
with its rod, refreshed every frame from the same `pinState` the rest of the sim
uses, so the skin is driven by the actual mechanism rather than by a copy of it.
The cap rim gets 1.2mm of rounding so the cloth curves off the edge instead of
hinging on it.

Collisions are resolved INSIDE the relaxation loop, not after it. Do it after and
the constraints pull the sheet back through the cap between passes, which looks
like the cloth flickering through the pins.

## Pre-tension is the thing worth playing with

The rest length of every spring is the grid spacing times the tension slider, so
below 1.0 the sheet is stretched before anything pushes on it. At 0.94 a set pixel
reads as a crisp bump. Take it to 1.00 and the sheet goes slack and the pattern
turns to mush; the pins are still moving exactly the same amount.

## Verified

| | |
|---|---|
| flat skin height | 0.25 mm across the whole face |
| with 8 pixels set | 7.60 mm, which is exactly the latch throw |
| peak height | 104.95 = cap top 104.60 plus the cloth's own 0.35 |
| particles below the face plate | 0 |
| motion after settling | 0.0000 mm per step |
| checker pattern | 8 of 8 latched |

That last pair matters: a solver that has quietly died looks exactly like one that
has settled, so the test drives a pattern and asserts the skin height CHANGES by
the throw. Flat 0.25 to 7.60 is the assertion.

## Modes

Solid gives you the object as you would see it, an opaque skin with the pattern
raised in it. Ghost body drops the case and the skin to translucent so you can see
the bars and links moving under the bumps. Wireframe shows the actual mesh, which
is the honest view of what is being solved. Cloth can be switched off entirely to
get the plain machine back.
