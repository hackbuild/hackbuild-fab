# Print time and how the fits land in PETG

0.24 layer, 0.42 line width, 3 walls, no brim, no raft, PETG, and otherwise a
stock profile for a 0.4 nozzle. Speeds taken conservatively at 40 outer wall,
55 inner, 90 solid infill, plus 18% for travel, acceleration and seams.

Estimated from the real per-layer path lengths by `source/printtime.py`, not from
volume over flow rate, because a skeletonised lattice is nearly all perimeter and
perimeters run at half the speed of solid infill. The slicer is still the
authority; expect it within about 15%.

## The body

| part | qty | cm2 | layers | each | total |
|---|---|---|---|---|---|
| base | 1 | 397.0 | 12 | 4.27h | 4.27h |
| X wall | 2 | 177.9 | 12 | 1.94h | 3.87h |
| Y wall | 2 | 175.6 | 12 | 1.92h | 3.83h |
| guide deck | 1 | 314.8 | 12 | 3.65h | 3.65h |
| face | 1 | 392.8 | 25 | 8.86h | 8.86h |
| slider plate | 1 | 292.1 | 12 | 3.18h | 3.18h |
| rail | 2 | 35.6 | 12 | 0.46h | 0.92h |
| FULL FRAME | | | | | 28.6h |
| MINIMAL FRAME | | | | | 10.8h |

985g of PETG for the full frame, 276g for the minimal one. Every frame part prints
FLAT, which is what the orientation scoring picked, so the layer count comes from
the 3mm thickness and not from the standing height. The face is the long pole at
nearly 9 hours because it is the only double-thickness part; the minimal face is
single layer and drops to 1.75.

Average flow works out at 7.5 mm3/s for the full frame and 5.6 for the minimal
one. The minimal one is slower per gram, which is the lattice: more perimeter, less
infill.

## How the fits land in PETG at 0.24

Different from the PLA numbers the design was banded on. PETG oozes and bulges, so
holes come out further under and outsides further over, and a coarser layer makes
the first perimeter of a small hole worse again. Call it 0.40 of lost clearance
rather than 0.25.

| fit | drawn | PLA 0.20 | PETG 0.24 | |
|---|---|---|---|---|
| crank shaft in its wall bore | 0.75 | 0.50 | 0.35 | fine |
| link turning on its pivot | 0.75 | 0.50 | 0.35 | fine |
| drive pin in the yoke slot | 0.75 | 0.50 | 0.35 | fine |
| slider plate in its rail | 0.75 | 0.50 | 0.35 | fine |
| frame tab in its slot | 0.35 | 0.10 | -0.05 | firm, taps together |
| knob on its shaft | 0.10 | -0.15 | -0.30 | tight |
| cap on the rod tenon | 0.15 | -0.10 | -0.25 | tight |

SLIDING FITS ARE FINE. 0.35 of real clearance is still a proper running fit. This
is the payoff from raising them: at the old 0.55 drawn they would have landed at
0.15 in PETG, which is exactly the tight you were already feeling in PLA.

THE FRAME TABS GO TO ZERO. At -0.05 they become a tap-together fit rather than a
push-together one. For a frame that is arguably right, but cut the coupon first
and check before committing eight hours to a base.

THE PRESSES GET TIGHT. -0.30 on the knob is a lot. PETG takes it better than PLA
would, because it yields instead of cracking, but expect to lean on them. If a
knob will not start, take FIT_PRESS from 0.10 to 0.20.

## The cut-slot fits, and kerf

Kerf does not change with print settings, so the laser side is unaffected: the
compensation still lands a cut slot on its drawn size at a 0.18 kerf. Only the
PRINTED half of those pairs moves.

| | slot | PLA | PETG |
|---|---|---|---|
| printed lug in the cut deck slot | 3.70 | 0.55 | 0.48 |
| printed rod in the cut face slot | 3.70 | 0.55 | 0.48 |
| printed cap in the cut pocket | 17.57 | 0.50 | 0.43 |

All comfortable. These have the most margin of anything in the machine, because
only one side of the pair loses anything.

## The one place PETG is better

The pivot pin. Its barb is 1.15 of interference in PLA and about 1.33 in PETG,
forced through behind a 3mm 20 degree cone. PETG is the right material for that:
it yields and swages the bore. PLA at that interference has a real chance of
splitting the lug instead.
