# OGEE R16 sheet parts

Open `ogee16-sheets.html`. Set your stock size and it nests, then exports one DXF
per sheet in millimetres with everything already positioned.

## What is here and what is not

You are printing the internals: bars, lugs, links, rods, caps, pivot pins, knobs,
crank shafts and cranks. Those are gone from this page. What remains is exactly
the set of parts whose job is to be flat anyway.

| part | qty | mm | outlines |
|---|---|---|---|
| base plate | 1 | 202 x 202 | 11 |
| X wall | 2 | 202 x 94 | 4 |
| Y wall | 2 | 202 x 94 | 10 |
| guide deck | 1 | 202 x 202 | 50 |
| face, lower layer | 1 | 202 x 202 | 17 |
| face, upper layer | 1 | 202 x 202 | 17 |
| slider plate | 1 | 174 x 174 | 18 |
| slider rail | 2 | 202 x 21 | 1 |
| row servo bracket | 1 | 148 x 40 | 13 |
| column servo bracket | 1 | 150 x 67 | 13 |
| slider servo shelf | 1 | 40 x 21 | 4 |
| slider servo rib | 2 | 18 x 66 | 1 |
| fit coupon | 1 | 124 x 54 | 16 |

17 pieces, 175 outlines. Two sheets of 600 x 400 at 81% and 52%, or one sheet of
1220 x 610, or four of 450 x 300. Anything too big for the stock you set is called
out in red rather than quietly dropped.

The outlines are the same geometry the interference audit and the fit checks ran
on, pulled out of the DXFs rather than redrawn. Inner outlines are cut as well as
outer ones, so every slot and bore comes through.

## The mixed build

Because the internals are printed and the body is cut, the two have to agree at
their interfaces, and they do: the printed bar assemblies carry 3mm lugs that pass
through the deck's 3mm slots, the printed rods run in the face's rod slots, and
the printed caps sit in the upper face's pockets. Those are the same numbers on
both sides, from the same parameter file.

One thing this page found: the lasercut slider servo shelf was 24mm wide, sized
off the tower ribs, for a servo flange that spans 32.2. The window ran clean off
the edge of the part and there was nothing left to screw into. It is sized off the
servo now, 40 x 21.

## Two DXF notes

OpenSCAD writes DXF as loose LINE segments, not polylines, so the outlines have to
be stitched back into loops before they can be nested or re-emitted. That is what
`build_sheets.py` does: index every endpoint on a rounded key, then walk segment
to segment until each loop closes.

And the export writes both the closed FLAG and an explicitly repeated first
vertex. Readers disagree about the flag, and a reader that ignores it leaves a gap
in every outline, which a cutter will happily plunge straight through. Verified by
reloading every exported sheet: 191 outlines across two sheets, none geometrically
open, all inside the sheet and its margin.

## The slots that take printed parts

These were sized for a lasercut lug and they should not have been, because the two
errors go in opposite directions. Kerf compensation lands a cut slot on its drawn
size. A printed feature comes out OVER its drawn size, about 0.15. So a printed
3.0 lug in the old 3.40 slot had 0.25 of real clearance, at the very bottom of a
sliding fit, with nothing left over for a kerf that is not quite what you measured.

There is a separate fit for them now, FIT_PSLIP = FIT_SLIP + PRINT_OVER:

| cut slot | printed part | slot | real clearance |
|---|---|---|---|
| deck lug slot, across | 3mm lug | 3.55 | 0.40 |
| deck lug slot, along | 12mm lug | 12.55 | 0.40 |
| deck drive lug window | 17.5mm lug | 18.05 | 0.40 |
| lower face rod slot | 3mm rod | 3.55 | 0.40 |
| slider plate rod slot | 3mm rod | 3.55 | 0.40 |
| upper face cap pocket | 16mm cap | 17.43 | 0.50 |

Laser-to-laser joints are untouched: tabs stay at 0.15, the rail groove and the
bracket slots stay as they were. Only the slots that a printed part passes through
moved.

The cap pocket is the one I then had to pull back. At FIT_SLIP + PRINT_OVER it came
out at 0.60 of real clearance, which is a visible rattle on the one part of the
machine you actually look at, so it is 0.35 + PRINT_OVER for 0.50.

`source/fits.py` carries these as their own class, PSLIDE, because the loss model
for a cut slot taking a printed part is not the model for either on its own.

## Before you cut

Cut the coupon first and check the tab fit. Kerf is not compensated here: the
outlines are nominal and the joints are drawn with 0.15 of clearance on tabs and
0.55 where a printed part slides through, which suits a kerf around 0.18. If yours
is much wider the tabs will come out loose rather than tight, and the sliding slots
will come out slightly looser still, which is the harmless direction.
