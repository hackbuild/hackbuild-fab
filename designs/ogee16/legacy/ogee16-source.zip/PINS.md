# Pivot pins

`ogee16-pivot-pin.stl` is the part. `ogee16-pivot-pins-x32.stl` is all 32 on one
plate, heads down, 10mm off the bed edges.

The original pin with the slot filled in. Nothing else changed: same 6.0 head,
same 2.65 shank, same 3.8 barb, same 3.0 lead-in cone.

| | |
|---|---|
| head | 6.0 x 1.5 |
| shank | 2.65 x 6.28, the link turns on this |
| ledge | 3.8 x 0.4 |
| cone | 3.8 down to 1.6 over 3.0, a 20 degree half angle |
| overall | 11.18 long, 0.10 cm3 |

The cone is what does the work and it is why the slot was never load bearing. It
is long and shallow, so it starts by hand and wedges its way through, swaging the
lug bore as it goes. The slot only existed to let the barb collapse to the shank
diameter, and at this size it does not need to. Filling it removes the two 0.73mm
legs that made the part unprintable and changes nothing about how the joint works.

`fits.py` bands the barb on interference rather than clearance, and its band is
deliberately wide, because what makes a large interference workable is the LEAD-IN
and not the interference itself. A long shallow cone wedges in where a short steep
one just stops. This one is 1.15 of interference behind 3mm of 20 degree taper.

## Printing

| | |
|---|---|
| bed contact | 28.2 mm2, the head |
| overhang | 5.8 mm2, the ledge under the barb |
| all 32 | 3.17 cm3 on a 90 x 42 patch |

Head down, no supports. The 5.8mm2 is the annular step behind the barb, which
bridges over 0.6mm and needs nothing. Give it enough perimeters that the 2.65
shank is solid rather than hollow: 3 or more at 0.4 lines, or 100% infill, since
the whole pin is a tenth of a cm3.

## Assembly

Round bore end of the link onto the column lug, slotted end onto the row lug, then
push a pin through each from the outside until the ledge clears the back of the
lug. To remove one, push it back out from the tip.
