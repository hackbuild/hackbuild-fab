# OGEE R16-M, minimal frame

`ogee16m.html` is the sim. The mechanism, kinematics, bars, links, rods, caps,
pins, knobs and cranks are all unchanged. Only the frame is different.

## How it was made

Not redrawn. Each plate was SKELETONISED from its own profile by
`source/skeleton.py`: keep a 4mm band around the outside, a 2.6mm collar around
EVERY hole, and a thin lattice on the bar lines, and open everything else.

Working from the profile's own geometry rather than from a list of features means
nothing can be forgotten. Every slot, bore and tab survives with material around
it, so a minimal part assembles exactly like the full one. Same joints, same
guides, same fits. It is the same part with the middle of the empty areas removed.

| part | full | minimal | kept |
|---|---|---|---|
| base | 135.2 cm3 | 32.3 | 28% |
| guide deck | 94.3 | 38.7 | 42% |
| face | 226.6 | 32.6 | 28% |
| slider plate | 87.9 | 28.3 | 33% |
| each wall | 52.4 | 12.4 | 24% |
| each rail | 10.6 | 8.7 | 83% |
| WHOLE FRAME | 775.8 | 198.5 | 26% |

The deck stays the densest at 42% and that is inherent: it carries a slot for
every lug on every bar, so there is not much of it that is empty in the first
place. The rail barely changes because it was already just a strip.

## The column bar seats

Worth calling out because it nearly shipped missing. The column bars sit 17mm
higher than the row bars and land on eight bosses that rise off the base to
CB_Z. Those bosses are 3D, and `skeleton.py` works on the 2D PROFILE, so
skeletonising quietly threw them away and left the column bars resting on nothing.

The minimal base carries them again, plus a pad under each one, because the
lattice rib they land on is only 4.4mm wide. Minimal base is 51.4 cm3 rather than
32.3 with the seats back, still a fifth of the full 135.

That is the one thing this skeletonising approach cannot see: it preserves
everything in the outline perfectly and is blind to anything that was never in the
outline. Worth checking by eye against the full part's z range, which is how this
turned up: full base 0 to 20, minimal base 0 to 3.

## The knob hubs

The knob bores carry a hub, a boss projecting inward, so the bearing is 8mm rather
than 3 and there is 4mm of material round the bore rather than 2.6.

On a skeletonised wall that needs care: the collar the skeleton keeps around a
hole backed only 66% of the hub's footprint, so its outer rim would have been
fused to whatever lattice happened to cross. The knob bores are given a full 22mm
pad instead, which is 3mm past the hub all round. The wall goes from 24% to 30% of
its full material, which is what that costs.

### And the bores were not there at all

Worth spelling out, because every other check passed while this was wrong. The
knob bores are a PRINTED-variant feature: they live in the printed wall profile,
not in the lasercut one that `skeleton.py` reads. So the skeletonised wall came
out SOLID behind every hub, 9.5mm of plate exactly where the shaft has to pass,
with a hub bolted to the front of it.

The bores are cut through skeleton and hub together now. `check_frame.py` rays
straight down each shaft axis and requires it to exit clean: 4 of 4 on all four
walls. MATERIAL BEING PRESENT IS NOT THE SAME AS A HOLE BEING THERE, and the hub
test I added last round only measured the former.

## Two deliberate differences

THE FACE IS ONE LAYER. The full face is two: a lower layer with the rod slots and
an upper one with the cap pockets. Here only the lower layer exists, so the caps
sit 3mm proud at rest instead of flush. That is the point: you can see the rods.
The pixel still rises the same 7.6mm when it sets, so it reads as more contrast,
not less.

NO SERVO MOUNTS. This frame is knob-drive only, so the bracket slots and the latch
tower slots that the full base and deck carry are gone with them. If you ever want
servos on it, use the full frame.

## What held it together

`skeleton.py` checks that every minimal part is ONE connected piece, and it had to,
because the first pass broke three of them: a corner of the base and a tab on each
wall were left as loose islands. Rather than guess where to put a web, it now takes
the smallest loose piece, finds the shortest line from it to the rest, and lays a
web along that line clipped to the original profile, so a weld can only ever add
material the full part already had.

Then a second trap: a weld found that way can meet its neighbour at a TANGENCY.
One piece in 2D, but the 0.05 print shrink pulls it apart and the base came out as
six bodies. Closing and reopening the outline by 0.35 turns every tangency into
real overlap before the shrink sees it. All nine parts are now single watertight
bodies.

## Verified

Same suite as the full build: printed audit 4 poses 0 clashes, all fits in band,
checker latches 8 of 8, tab pull drops all, knob-to-crank drift 0, assembly stepper
monotonic, sim self-check clean.
