# OGEE R16

A 4x4 mechanical pin display, built to the part set in the Fusion screenshots:
flat bar strips with mortises, raked lugs standing in them, dogbone links pinned
at both ends, notched rods hanging through a plate with a shaped cap on top.

New in R16
----------
- Back to INLINE stations, DIAG = 0. The 45 degree yaw put the whole cell on the
  diagonal, and with it the rod's foot slot, so the latch plate had to release
  along the diagonal normal. The tray now slides straight along +Y again.
- The yaw was the only thing forcing the pivot span out to 13. It is back to 9,
  the link is back to 29.6 long and the row slot to 2.60. Everything the yaw
  cost is refunded; the geometry is R13's, with R14's caps and R15's checks.
- The station angle is still a parameter. ROW_BAR_Y and COL_BAR_X are written
  generally as C*sin(DIAG) + YOFF*cos(DIAG) and -C*cos(DIAG) + YOFF*sin(DIAG),
  and the cell transform is translate(pixel) then rotateZ(DIAG), so setting
  DIAG back to 45 restores the yawed build. Note that the plate then releases
  diagonally again, which is the thing you did not want.
- The sim is in the hack.build theme now, built like the TANG one: three.js is
  inlined so the page opens straight off disk with no network at all, with
  40 lines of hand-rolled orbit controls since r128 ships none. Paper chrome,
  VT323 on full-bleed ink panel heads, 3px block shadows on controls, pink graph
  rule on the void stage, pink for the row train, slime for the column train,
  amber for the links, cream for the rods.
- Kept: per-part and per-group show/hide, three render modes, four cap shapes.

## Verified numbers

Re-run `source/kin.py` and `source/audit.py` to reproduce all of these.

| | |
|---|---|
| sheet | 3.00 mm, bars are two laminated layers |
| pixel pitch | 34 mm |
| overall box | 208 x 208 x 97 mm |
| bar stroke | 9.000 mm |
| rise, one bar driven | 4.249 mm |
| rise, both bars driven | 9.000 mm |
| latch threshold | 7.600 mm |
| margin, one bar (must NOT latch) | 0.775 mm |
| margin, both bars (must latch) | 1.400 mm |
| notch shelf engagement | 0.925 mm of a 1.450 mm lateral budget |
| tactile rod throw | 7.6 mm |
| row slot used at full tilt | 2.125 of 2.600 mm |
| bar sag at the far station | 0.168 mm |
| rod return force vs friction | 0.0176 N vs 0.0094 N, ratio 1.86 |
| peak crank torque | 16.1 gf.cm against an SG90's 1800 |
| clear pull | 37.1 gf.cm |
| mesh interference audit | 7 poses, 0 clashes |
| sim kinematics vs CAD kinematics | 128 placements, 0 mismatches |
| link bores vs lug pivots, in the sim | 3.6e-15 mm worst case |
| lug yaw | 45 deg across the bar |
| cut sheets | 3 of 600 x 400, 183 pieces, 27 parts |

The bars have to be two laminated layers. One 3mm strip, lifted at one end,
droops 0.95mm at the far station, which is more than the entire half select
margin. Two layers takes it to 0.168mm and gives the lug tenons a 6mm mortise
instead of a 3mm one.

## Bill of materials

183 pieces, 27 distinct parts, 3 sheets of 600 x 400 mm.

| part | qty | size mm | notes |
|---|---|---|---|
| base | 1 | 202 x 202 |  |
| face | 1 | 202 x 202 | lower, rod apertures |
| face2_circle | 1 | 202 x 202 | upper, cap apertures, one per shape |
| deck | 1 | 202 x 202 | 32 lug slots plus the end lug slots, no channels |
| latch | 1 | 174 x 174 | slides 3mm in +Y |
| wallx | 2 | 202 x 94 |  |
| wally | 2 | 202 x 94 |  |
| rail | 2 | 202 x 21 | latch plate slideway |
| rowbar | 8 | 162 x 12 | two laminated layers per bar |
| colbar | 8 | 12 x 162 | two laminated layers per bar |
| rowlug | 16 | 12 x 51 | the tall one, off a bar at z 3 |
| collug | 16 | 12 x 34 | the short one, off a bar at z 20 |
| link | 16 | 30 x 15 | dogbone with the crown |
| rod | 16 | 11 x 48 | notched, tenon on top for the cap |
| cap_circle | 16 | 16 x 16 | one per rod, cut in the shape you picked |
| rowdrive | 4 | 16 x 38 | carries the yoke slot, and guides |
| coldrive | 4 | 16 x 48 | carries the yoke slot |
| rowguide | 4 | 12 x 38 | far end of the bar |
| colguide | 8 | 12 x 38 | two per column bar |
| svbracket_row | 1 | 148 x 40 | one plate carries all four |
| svbracket_col | 1 | 150 x 62 | one plate carries all four |
| latchbracket | 1 | 30 x 23 |  |
| latchrib | 2 | 20 x 66 |  |
| crank | 8 | 15 x 11 |  |
| latchcrank | 1 | 15 x 11 |  |
| washer | 41 | 8 x 8 | pivot keeper, cemented on |
| coupon | 1 | 124 x 54 | cut this first |

Bought: 9x SG90 with horn and screws. About 500mm of 3mm rod: 32 lengths of 11mm for the
pivots, 8 of 12mm and 1 of 14mm for the crank pins. Acrylic cement.

## The pivots are bought rod, and that is not a shortcut

A link pivots about an axis normal to its own sheet, so the axle runs between two
parallel plates. You cannot cut a round axle from flat sheet along that axis, and
a rectangular prism is not a journal: a 3mm square shaft in a 4.44mm round bore
has a contact radius that swings from 1.500 on the flat to 2.121 on the corner,
so the pivot centre wanders 0.6mm as it turns. That is 7% of the stroke injected
straight onto the quantity the machine measures.

So each pivot is a 12mm length of 3mm rod, pressed and cemented into the lug's
2.90 bore, with the link running on it at 3.20 and a cut washer cemented on the
free end. Acrylic rod matches the sheet and solvent welds; steel or brass dowel
works as well if you would rather glue.

## Cut it in this order

1. Cut `coupon` only, in the real sheet, on the real machine.
2. Check every feature on it. It carries one of each fit class in the machine: a
   slip slot, a lap slot, the tenon mortise, the 2.90 press bore, the 3.20
   running bore, a lug slot, a tab slot, a loose tab, a tight tenon, the SG90
   body cutout and the horn screw pattern.
3. Set `KERF` in `source/cutfiles.py` from what you measure and regenerate. Do
   not change the part geometry. Kerf is a machine property.
4. Cut the three sheets.

## Assemble it in this order

The viewer has an assembly stepper that walks each of these.

1. Base flat, four walls in, square it.
2. Both servo brackets and the two latch tower ribs into their base slots, then
   the latch bracket on top of the ribs. Nine servos in with their own screws.
   No cranks yet.
3. Laminate the bars: two strips each, mortises aligned, cemented.
4. Four row bars straight onto the base. They rest on it, and that landing is
   the hard stop, so nothing holds a preload.
5. Sixteen row lugs, four row drive lugs and four row guide lugs. Tenons down
   through the mortises, shoulders on the bar face, cemented.
6. Guide deck down over the wall tabs and over every lug. From here the deck is
   what keeps the bars square, so if it is not seated the machine will not work.
   The two end lugs on each bar are the tight ones; the pivot lugs just pass.
7. Four column bars. Their own drive and guide lugs run down to the base and
   that is what they land on. Then sixteen column lugs.
8. Sixteen links. Round bore end onto the column lug, slotted end onto the row
   lug. 11mm of 3mm rod through each, washer cemented on the outside. Do not
   try to close the slot up: that slot is the pivot separation changing as the
   two bars differ, and it needs 2.125 of its 2.60.
9. Latch rails into the Y walls, latch plate through both. Check it slides its
   full 3mm along +Y by hand before anything else goes on top.
10. Sixteen rods, each dropped through a latch plate slot with its notch on the
    +Y side and its foot slot straddling its link crown.
11. Lower face plate onto the wall tops.
12. Upper face plate onto the lower one, apertures over the rods, cemented.
13. Sixteen caps, mortised onto the rod tenons, sitting flush in the apertures.
14. Cranks onto the servo horns last, every servo already at rest, so each crank
    pin lands in its yoke slot at the low end of the swing.

## Open items, stated plainly

- A latched rod is held by a 1.0mm shelf. Pressing down on the tip only seats it
  harder, but a deliberate sideways poke of about 1mm releases it. Every lateral
  lock fails for the same reason: the displacement that cams the notch in is the
  same one that lets it out.
- The rod's lateral return is gravity down a 40 degree ramp against 0.0154 N of
  rod weight, with 1.86x margin over friction on acrylic. Real, but not large.
  Bench test one rod, one link and the latch plate before cutting sixteen.
- Gravity return means face up only.
- SG90 dimensions are published figures, not a measured unit. Clones vary. The
  coupon carries the body cutout and the horn screw pattern for this reason.
- The crank has a 5.2mm spline clearance hole and two 1.8mm holes at 4.5mm either
  side. Measure your horn and edit `HORN_SCREW_P` if it does not match.
- One bug in this line of work survived every numeric check twice and is worth
  knowing about if you edit the viewer: a mesh exported carrying its own world
  offset will be rotated by three.js about the mesh origin, not about its pivot,
  so the link swings about a point 48mm below its pins and looks perfectly
  correct at zero tilt. `buildCheck()` now walks the transform the renderer
  actually applies and asserts both bores land on the two lug pivots, at five
  different bar states. Worst error is 3.6e-15 mm.
- The sim decides a latch ONCE, from geometry at full stroke, at the moment the
  command is given. The sweep after it is only the picture. Deciding it from
  whichever frames happened to render loses pixels: under software GL two frames
  fired in a 700ms sweep and nothing latched at all. For the same reason a new
  command is never refused because an old animation has not finished.
- Two things the extended audit found after the first R16 build, both from
  parts that had never been checked. The lightening holes I had put in the bars
  bit 0.6mm into every lug mortise; a bar that must not sag has no business
  being lightened, so they are gone. And the crank plane always sits over its
  own bar's centreline, so its lowest point has to clear that bar at FULL
  STROKE, not at rest: the row shaft went 20 to 27.5 and the column shaft 37 to
  44.5, which buys 1.04mm at each. The column crank now has to cross the deck to
  do it, so the deck opens up there and the column bars get a second guide lug
  at y 51 to replace the guiding the drive slot used to do.
- One guide lug per ROW bar, two per column bar. The drive lug's deck slot is 16.4 for a 16mm
  lug, which is the same 0.4 clearance as a tight slot, so it guides as well as
  the guide lug does. Two tight stations per bar is enough for x, y and yaw, and
  a second guide had nowhere to sit that was clear of the row bars, the column
  lugs and the links all at once.
- Two placement bugs this pass, both worth knowing about. An edit pushed
  `DRIVE_Y = 126;` behind a `//` comment on a shared line, so OpenSCAD evaluated
  undef and parked all four column drive lugs at the origin with no error at
  all. `render.py` now asserts every required constant in params.scad is
  actually defined. And the viewer was adding the pivot lugs' own +/-C offset a
  second time on top of the offset already baked into their meshes, which put
  every lug 9.2mm out. There is now a checker that transforms every viewer
  part's bounding box into world coordinates and matches it against the audited
  placement; it reports zero mismatches.
- The connectedness check caught a wall-to-wall tab sitting at z=100 on a wall
  that is only 91 tall, which cut two floating rectangles off the Y walls. If
  you change WALL_TOP, check TAB_Z against it.
- The interference audit covers seven static poses. It is a strong check and it
  found two real errors this pass, but it is not a swept volume proof. Move the
  mechanism by hand once before fitting the face plate.

## Files

```
ogee16.html            the simulator, one file, opens from disk
out/cut/sheet1-3.svg   kerf compensated, nested, ready to cut
out/cut/*.dxf          same geometry as DXF
source/params.scad     every dimension, in dependency order
source/ogee16.scad     every cut profile and its assembly placement
source/kin.py          the kinematics, and the only source of truth for them
source/audit.py        mesh level interference audit
source/cutfiles.py     connectedness check, kerf compensation, nesting
source/render.py       rebuilds all DXF and STL
source/build_viewer.py rebuilds ogee16.html
source/check_viewer.py proves the sim's maths equals the CAD's maths
```

To change anything, edit `params.scad`, then:

```
python3 render.py && python3 kin.py && python3 audit.py \
  && python3 cutfiles.py && python3 build_viewer.py && python3 check_viewer.py
```

If `audit.py` reports a clash, `cutfiles.py` reports a severed profile, or
`check_viewer.py` reports a mismatch, the change is not finished.
