# OGEE R16-P, printed and hand driven

Same machine, same verified kinematics, rebuilt for a FlashForge Creator 5 Pro
(256 x 256 x 256) and turned by hand instead of by servo.

Open `ogee16-plate.html`. It is a 3D stage: the real meshes standing on a 256
bed drawn to scale, with the height cage, a 32mm rule and a tab per plate.
Orbit it, drop parts off the plates by clicking a row, change the gap, then
export one STL per plate with everything already positioned so it drops into
Orca at 0,0 with nothing to arrange. Or export any single part on its own.
Three.js is inlined, so it opens straight off disk with no network.

The tray, the face, the deck and the latch plate each get a plate to themselves,
because they are 202 square and nothing useful shares a bed with them. Everything
else goes through MaxRects best-short-side-fit and may be turned 90 degrees,
which costs nothing since all of these print flat anyway.

The gap is what actually decides plate count, so each tab shows its fill and
there is an auto gap button. At 6mm the 88 small parts need 74520 mm2 of padded
footprint against 62500 usable and genuinely cannot share a bed; at 3mm they fit
one plate at 71% fill. Auto gap finds the largest gap that still hits the
minimum, which here is 3mm and 5 plates.

## What got combined, and why

A laser only makes flat parts, so every joint in the cut version is a tab and the
machine is 183 pieces. A printer does not care:

| combined into one part | was |
|---|---|
| row bar + its 4 pivot lugs + drive lug + guide lug | 11 pieces and 12 mortises |
| column bar, same | 11 pieces |
| face: lower and upper layers, with a stepped cap pocket | 2 pieces |

| pivot pin with a printed head | pin + cemented washer |

Two parts added rather than combined: the latch pull knob, and the cap, which I
had fused to the rod and have now split back out (see below).

183 pieces becomes 99, and the only fasteners left are the pins.

The frame is NOT combined. A one-piece tray was tried and rejected: 350 cm3, one
very long print with no recovery if it fails, and it eats a whole bed. So the
base, the four walls and the two rails stay separate flat plates and tab together
exactly as the cut version does, which also means they print with no supports and
you can replace one if it warps.

They do get one change for printing: every frame profile is shrunk 0.075 all
round, which thins each tab and widens each slot in a single operation, giving
0.15 total on every mating face. The four walls are now four distinct parts
rather than two of each, because the +X wall carries the row knob bores, the +Y
wall the column knob bores, and the -X wall the latch tab slot.

## The assembly sim

`ogee16p.html` is the printed build assembled and working. Same page shell and
same kinematics as the laser sim, but every solid in it is one of the STLs off
the build plate rather than a cut profile. Turn the knobs with the sliders, or
click a pixel and it turns that row knob and that column knob together, which is
the two handed move you would actually make. Pull the tab to clear.

It has an explode slider and a ten step assembly stepper, with a play button
that walks the build. The step order is forced in exactly one place: the row
cranks sit at z 27.5, under the deck, and the column cranks at 44.5, over it, so
the row shafts have to go in before the deck and the column shafts after it.

It self-checks on load, and one of those checks earned its place immediately:
every pivot pin has to span its link bore and reach into its lug. The pins were
standing vertically instead of lying along the pivot axis, because the registry
zeroed each part's rotation and the frame loop then applied that zero. Both sims
now capture whatever rotation a part already has when it is registered, which is
the same fix the latch crank needed for its position.

The rest of the self-check: link bores landing on their lug pivots at four bar
states, the half and full select thresholds, and that each knob's angle equals
its own crank's. That last one caught nothing, but the link did: the link prints
flat on the bed and assembles standing on edge, and the sim was using the print
orientation, so all sixteen were lying on their backs. It is the only part in
the machine whose print orientation is not its assembly orientation, and there
are now two exports of it for that reason.

## Driving it by hand

Each of the eight bars keeps the crank the servo used to turn. The crank and its
shaft print as one piece; the shaft passes out through a bore in the wall and a
knurled knob presses onto the D at the end. The crank geometry is untouched, so
the 9mm stroke and the 7.6mm latch throw are the ones already verified.

Turn a row knob and a column knob together and that pixel latches. Turn either
one alone and its rod lifts 4.249mm, well short of the 7.6mm it needs, and drops
back when you let go. That half-and-half is the whole trick and you can feel it.

The latch plate grows a finger tab that comes out through a slot in the -X wall.
Push it 3mm and every set pixel drops at once.

Nothing holds the knobs at a position, so writing a pixel is a two-handed move:
both knobs over, then both back. If you want one-handed writing, the place to add
a detent is the knob boss against the wall, not the mechanism.

## Print orientation

Every part's pose was chosen by `source/orient.py`, which scores all 24
axis-aligned poses on bed contact, overhang area steeper than 45 degrees, and
height, in that order. Bed contact first because a part that lifts is a failed
print; overhang second because it is support and a bad surface; height last
because it is only time.

Four parts came out wrong by eye and the tool caught them:

| part | as drawn | reoriented |
|---|---|---|
| rod + cap | 16.7 mm2 on the bed, 192 mm2 overhanging | flipped cap down: 201 and 5 |
| crank shaft | 4.5 mm2, a line where a lying cylinder touches, 333 overhanging | stood on its crank: 98 and 22 |
| link | 65 mm2, 40 overhanging | laid flat: 304 and 0 |
| knob | 524 mm2, 55 overhanging | flipped: 565 and 14 |

And one was a design problem wearing an orientation problem's clothes. The
column bar's drive and guide lugs ran to the floor, because in the cut version
that is what the bar lands on. That makes the assembly unprintable in EVERY pose:
it stands on three little feet with the bar 17mm in the air, 120 mm2 of contact
against 1891 of overhang, and the best of 24 poses is still only 124. So the feet
are cut off at the bar's underside and the stops moved onto the base as eight
printed bosses. It now prints exactly like the row bar, flat on its own 162x12
face: 1956 mm2 and 55.

Nothing in the machine is tipped off an axis and nothing needs support.

## Bars stay lugs-up, and here is why

You asked for them on their side. I measured it before doing it and it is
strictly worse, so I have left them standing and here are the numbers:

| row bar pose | bed contact | overhang | height |
|---|---|---|---|
| lugs up | 1944 mm2 | 55 | 51 mm |
| on its side | 96 mm2 | 3150 | 16 mm |

The height does drop from 51 to 16, but the print becomes almost entirely
support. The reason is that the lug sheet sits ON the bar's centreline, not
flush with one of its faces, so laid on its side the bar's own edge is the low
point and all six lugs float about 5.5mm up, cantilevered 45mm out.

The only thing that would make a side-lay work is moving the lug flush with a bar
face, which means shifting the bar 5.5mm in Y. That is a mechanism change, not a
print setting: it moves ROW_BAR_Y and everything indexed off it. Worth doing if
print height ever becomes the binding constraint; it is not at 51mm in a 256 cube.

## Plate grouping

| plate | pieces | fill | tallest |
|---|---|---|---|
| base | 1 | 73% | 20 mm |
| face | 1 | 73% | 6 |
| guide deck | 1 | 73% | 3 |
| latch plate | 1 | 59% | 3 |
| each of the 4 walls | 1 | 34% | 3 |
| rails | 2 | 15% | 3 |
| row bars | 4 | 19% | 51 |
| column bars | 4 | 19% | 34 |
| links | 16 | 13% | 3 |
| rods | 16 | 7% | 48 |
| row shafts / column shafts | 4 each | 1% | 47 |
| knobs | 8 | 12% | 10 |
| latch pull | 1 | 0% | 12 |
| pivot pins | 32 | 2% | 11 |
| crank drive pins | 8 | | 9.5 |


One part type per plate, eighteen plates. More plates, but each is a single print
profile: one set of settings, one failure mode, and you can reprint a whole family
without disturbing anything else. Fill is measured against the usable area, which
is inset 10mm from the bed edge on all four sides, so a part is never sitting on
the skirt line.

## Print notes

- Bars print lugs-up, straight off the plate, no supports. The pivot bores are
  horizontal 3mm holes and bridge fine.
- The tray prints open side up. 350 cm3 and by far the longest print here.
- Running clearances are 0.30 rather than the laser version's 0.40 slip fit.
- Pivot pins are SOLID STEPPED PRESS PINS, head down, 6.5 x 8.8. Head bears on
  the link, the 2.65 free section runs in the link's bore, the 2.85 section
  presses into the lug. One push per joint, no washer and no cement. To remove
  one, push it back out from the tip.
- The cap shape is baked into the rod now. Re-run `render_print.py` with a
  different `shape` to get square, hex or triangle instead of circle.

## The face apertures, and why the cap came back off the rod

You were right that something was wrong there, though not quite what it looked
like. The apertures ARE stepped on purpose: the lower layer is a 3.4 x 13.2 rod
slot, the upper is an 18.12 cap pocket. That step is load bearing. The lower slot
is what guides the top of the rod, and without it the rod is only constrained by
the latch plate slot 14mm below and can lean.

What was actually broken was the consequence. The cap is 16 across and cannot
pass down through a 3.4mm slot, so with rod and cap fused into one part the face
plate could never go on after the rods: the only way in was to drop a capped rod
blind through an 18mm hole onto a link crown 40mm below.

So the cap is a separate part again. The rod goes in from inside where you can
see what it is landing on, the face goes on, and the caps press onto the tenons
from the top. 16 more pieces, and the swappable cap shape comes back as a bonus.
The rod alone also prints far better: laid on its face it is 434 mm2 of bed
contact, nothing overhanging, and 3mm tall instead of 48.

## Servos, or knobs

The frame does not change. The servo brackets and the latch tower tab into slots
the base and the deck already carry, so one tray takes either drive, and with
knobs fitted those slots simply sit empty. The crank is the same crank: with
knobs it is one end of the knob shaft, with servos it is a separate disc on the
horn at exactly the same plane and the same angles.

Both pages have a knobs/servos toggle. On the build plate it swaps which parts
are in the bill: 115 pieces for knobs, 112 for servos. In the assembly sim it
swaps which drive you are looking at, and the pixel buttons work identically
either way because nothing about the mechanism changed.

Servo drive adds: 2 servo brackets, the latch bracket and 2 tower ribs, 8 cranks
and 1 latch crank, plus 9 SG90s and 2 PCA9685s of your own. Knob drive adds:
8 crank shafts, 8 knobs, 1 latch pull.

THE LATCH CRANK HAD NO PIN. Nothing connected it to the plate at all: the crank
tracked the plate's drive slot perfectly on paper, dy = 2.2e-16, and there was
simply no part in between. It gets the same pressed pin as the bar cranks, so
nine drive pins now, eight bars and the latch. `check_drive.py` covers this chain
too, 4.38mm to each slot end.

## The latch servo, in the corner with the others

It used to sit alone in the middle of the -Y edge on a tower that reached the
floor. It is now in the one genuinely empty pocket at plate-drive height, the
corner between row servo 3 and column servo 3:

| what is there | |
|---|---|
| row servos | x 131.5..154, in y bands ending at 117 |
| column servos | y 131.5..154, in x bands ending at 104 |
| row bracket | x 134.1..137.1, z 3..40 |
| column bracket | y 134.1..137.1, z 3..66 |
| +X rail | x 136..139, z 70..91 |
| the pocket | x 104..134, y 118..131, z 41..70 |

And it is still over the latch plate, which reaches x 140 and y 140, so the crank
can drive it there.

x = 124 is not a preference, it is the only window. The printed servo BODY has to
clear column servo 3, which ends at x 104.4, so LSV_X > 123.3. And the LASERCUT
crank plus its keeper washer has to clear the +X rail at 136, so LSV_X < 125. Both
builds share the parameter, and 124 is what satisfies them.

The servo is turned 90 degrees so its long axis runs along X, which is what makes
it fit the pocket's 13mm of Y at all.

The HAND pull tab did not move with it. It stays on the -Y corner where a hand can
reach it, on its own parameter, which it should always have had.

### How it is mounted

| | |
|---|---|
| bracket | x -16..21, y -29..-7, z 37..66.4, 6.11 cm3 |
| stands on | the deck at z 40, so it is 23.4 tall |
| feet | four 3 x 10 tabs into deck slots |
| flange screws | x -11.4 and +16.4 |
| walls | x -12.0 and +16.0 |
| screw to wall | 0.6 and 0.4 mm |

The load goes servo case, flange screws, shelf, both walls in compression, feet,
deck, wall slots, frame. Because the screws sit within half a millimetre of the
walls, nothing is cantilevered: the shelf's 4 and 5mm overhangs at the ends carry
nothing. And the load itself is small, about 0.4 N at the pin from sixteen rod
returns plus plate friction, which through a 6mm crank is 2.5 gf.cm against an
SG90's 1800.

### Clearances

Nothing collides, but "nothing collides" is not the useful answer: a 2mm gap
reads as contact in a render and a 2mm gap is what you argue about. So
`check_servos.py` reports the closest approach of every servo to every part, not
just a pass or fail.

| servo | nearest part | gap |
|---|---|---|
| column flanges | deck | 2.40 mm |
| column bodies | deck | 2.66 |
| row bodies and flanges | deck | 3.40 |
| latch body | column bar 0, all bars up | 5.40 |
| latch flange | column bar 0 | 6.77 |

Two things moved to get there. The latch servo went from y -20 to -17: at -20 its
body was 2.40 from the column 0 guide lug, which is clear and looks like contact.
At -17 it is 5.40 from the bar, 12.90 from the wall and 6.00 from the column
pivot lugs, which is about as balanced as that pocket gets. And the column shafts
went to z 48.5, a millimetre past what the deck strictly needed, because 1.40 was
the same kind of technically-fine-looks-wrong gap.

### Sweeps

Every other check here samples STATES: bars at rest, bars up, plate pulled. That
is correct for the bars, which only translate, so the extremes bound everything
between. It is wrong for the CRANKS, which rotate. An arc is not bounded by its
endpoints: a pin can be clear at both ends of the stroke and foul something in
the middle, and its head sweeps a ring no endpoint test ever visits.

`source/check_sweep.py` rotates each crank through 25 steps, unions the swept
solid, and tests that against every part and every servo case. It found the same
mistake nine times over: EVERY PIN HEAD SWEPT INTO ITS OWN SERVO. On the latch
crank the pin points up at the plate so its head points down at the case, 0.5mm
above it. On the eight bar cranks the head points outboard, which is exactly
where the servo is, and there it was not close but 577 mm3 of genuine overlap
each.

Every head is recessed into a counterbore in its crank now, flush with the face,
so the gap the servo horn sits in stays empty. One pin type still, nine of them.

| swept crank | nearest servo case |
|---|---|
| latch | 2.10 mm |
| all eight bar cranks | 3.02 mm |

### Collisions

`check_servos.py` now boxes all nine servos, body and flange, against every part
mesh at rest, all bars up, and clear pull, skipping only the bracket each one is
bolted to and the crank it turns. That found a real one: THE COLUMN SERVO FLANGES
WERE CLIPPING THE DECK, 27 mm3 each, in every state. The flange is 32.2 long
against a 25 wide deck cutout, so its corners caught the edge, 1.6mm deep. Rather
than cut more out of the deck, which would have left 0.8mm between adjacent
cutouts, the column shafts moved from z 44.5 to 47.5. The flange now sits at 41.4
and clears outright, and the crank still has 4.04mm to the driven bar.

## The knob bores are hubs, and the shafts are captured

A bore is not a bearing. The wall bore let the shaft turn and did nothing to hold
it in: pull a knob and the shaft walked 29mm before anything stopped it, taking
the crank clean out of its yoke. And 3mm of plate on an 8mm shaft is L/D 0.375,
which on the skeletonised wall was a 2.6mm ring of material with a knob levering
on it.

Each bore now carries a HUB, a boss projecting inward, on both the full and the
minimal walls:

| | |
|---|---|
| bearing length | 8.00 mm, L/D 1.00, was 0.375 |
| material round the bore | 4.0 mm, was 2.6 on the minimal wall |
| collar outer face | x 157.5 |
| hub | 158.0 to 163.0 |
| wall | 163.0 to 166.0 |
| knob inner face | 166.0 |
| end float | 0.50 mm |

Both walls still print flat with the hubs standing up, zero overhang: 17510 and
17396 mm2 of bed contact on the full walls, 5196 and 5383 on the minimal ones.

AND THE HUB IS BONDED TO SOLID PLATE, not to whatever lattice happened to cross
it. On the skeletonised wall the 2.6mm collar the skeleton keeps around a hole
backed only 66% of a 16mm hub's footprint, leaving its outer rim fused to
webs. The knob bores get a full 22mm pad now, so the hub sits entirely on plate
with 3mm to spare all round, and its root has a 1.5mm fillet which prints as a
self-supporting cone in the hub-up pose.

`check_frame.py` samples 24 points on a ring just inside each hub's rim, at the
plate's mid-thickness, and requires every one to be inside the wall. 96 of 96 on
both the full and the minimal wall.

## Three things this turned up

THE MINIMAL WALLS WERE 3MM INBOARD of the full ones. The +X and +Y minimal walls
used one placement expression and the full ones another, so the hub had no
consistent plane to attach to. Both sit at 163 to 166 now, and the shaft was
extended to reach past the wall's OUTER face rather than its inner one.

OPENSCAD RENDERS AN UNKNOWN MODULE AS NOTHING AND STILL EXITS 0. Two edits adding
the collar and the hub silently did nothing at all. `render_print.py` now fails a
part if OpenSCAD reports ignoring anything, and that guard immediately caught the
next mistake: OpenSCAD cannot take a module as a parameter.

CLOSE A PROFILE BY LESS THAN ITS JOINT CLEARANCE. The +Y wall's base tabs were
being severed by the 0.05 print shrink, the same tangency trap the skeleton hit.
Closing the outline first fixes it, but at 0.25 the close FILLED THE INTERLOCK
NOTCHES, which are 0.15, and every wall started colliding with its neighbours at
the corners. 0.10 bridges the tangency and leaves the joints open.

## The shafts are captured, not just bored

The wall bore lets the shaft turn but does nothing to hold it in. Pull a knob and
the shaft walks 29mm before anything stops it, which takes the crank clean out of
its yoke.

There is a collar on the shaft now, sitting 0.5 inboard of the wall's inner face,
so the wall is trapped between the collar and the knob:

| | |
|---|---|
| collar outer face | x 159.5 |
| wall | 160.0 to 163.0 |
| knob inner face | 163.0 |
| end float | 0.50 mm |

The collar is 11 across on an 8 shaft and never has to pass through the 8.75 bore,
because the shaft goes in from INSIDE and only its plain end comes out. Its
underside is a 45 degree cone, so it prints unsupported on a shaft standing on its
crank: 96.9 mm2 of bed contact and 24.3 overhanging, barely changed.

Clearances inside: 18.9 to the row servo bracket, 26.0 to the bar end, 4.0 under
the deck. The sims assert the capture rather than just drawing it.

## The frame, measured

`source/check_frame.py` measures the frame parts off the actual meshes rather
than off the source that drew them. Everything passes now, but it found one real
error, and it was in the lasercut build too:

THE CAP POCKET WAS TOO SMALL. The rod cams 0.925mm sideways getting its lug over
the plate edge, and the cap goes with it, but the aperture was sized on CAP_FIT
alone and left 0.300 per side. The cap jams on the rim at the end of its travel.
The aperture is now CAP_D + CAP_FIT + CAM and offset half the cam in Y, so both
ends of the travel clear by the same 0.300. CAM is a named parameter now instead
of a number buried in the kinematics.

Everything else checks out: interior 196 square, walls 3.00 thick topping out at
93.92 (91 plus the face tabs, less the 0.075 print shrink), rails spanning the
full 201.85 interior with their slot floor exactly at LP_Z, the column stop
bosses topping out at exactly CB_Z, all four knob bores breaking each wall's
section into five pieces at shaft height and the wall solid again below, and all
16 pixel centres ray-cast clean through both face layers.

## Verified

| | |
|---|---|
| every part inside 256 x 256 x 256 | yes |
| every part watertight | yes |
| printed assembly interference audit | 4 poses, 0 clashes |
| plate packing | 99 of 99 placed, 0 overlaps, 0 out of bounds |
| big flats alone | 4 solo plates |
| frame | 7 separate plates, not one tray |
| 3D page in chromium | no errors, no h-scroll, meshes on the bed |
| exported STL round trip | reloaded and measured, in bounds, origin at the gap |
| plates at auto gap (3mm) | 5, small parts all on one at 71% |
| exported plate re-measured | 88 bodies, all watertight after the 90 degree turns |

The printed audit is separate from the laser one. Different parts and different
clearances, so it does not carry over.
